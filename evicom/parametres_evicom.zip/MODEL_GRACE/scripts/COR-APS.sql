﻿begin transaction;

/* maj orange */
update t_cable set cb_prop='OR033001001581' where cb_prop='OR91000000000003';
update t_ebp set bp_prop='OR033001001581' where bp_prop='OR91000000000003';
update t_ptech set pt_prop='OR033001001581' where pt_prop='OR91000000000003';
update t_ltech set lt_prop='OR033001001581' where lt_prop='OR91000000000003';
update t_sitetech set st_prop='OR033001001581' where st_prop='OR91000000000003';

/* maj enedis */
update t_cable set cb_prop='OR033002000000' where cb_prop='OR91000000000004';
update t_ebp set bp_prop='OR033002000000' where bp_prop='OR91000000000004';
update t_ptech set pt_prop='OR033002000000' where pt_prop='OR91000000000004';
update t_ltech set lt_prop='OR033002000000' where lt_prop='OR91000000000004';
update t_sitetech set st_prop='OR033002000000' where st_prop='OR91000000000004';

/*maj client*/
update t_cable set cb_prop='OR033001002010' where cb_prop='OR91000000000002' or cb_prop='OR91000000000001';
update t_ebp set bp_prop='OR033001002010' where bp_prop='OR91000000000002' or bp_prop='OR91000000000001';
update t_ptech set pt_prop='OR033001002010' where pt_prop='OR91000000000002' or pt_prop='OR91000000000001';
update t_ltech set lt_prop='OR033001002010' where lt_prop='OR91000000000002' or lt_prop='OR91000000000001';
update t_sitetech set st_prop='OR033001002010' where st_prop='OR91000000000002' or st_prop='OR91000000000001';

/*maj indertemine*/
update t_cable set cb_prop='OR000000000000' where cb_prop='OR91000000000006' ;
update t_ebp set bp_prop='OR000000000000' where bp_prop='OR91000000000006' ;
update t_ptech set pt_prop='OR000000000000' where pt_prop='OR91000000000006' ;
update t_ltech set lt_prop='OR000000000000' where lt_prop='OR91000000000006' ;
update t_sitetech set st_prop='OR000000000000' where st_prop='OR91000000000006';


/* gest */
update t_ptech set pt_gest=pt_prop;
update t_cable set cb_gest=cb_prop;


/* etiquettes */
update t_ltech set lt_etiquet = lt_codeext;
update t_ltech set lt_codeext = null;
update t_ptech set pt_etiquet = pt_codeext;
update t_ptech set pt_codeext =null;
update t_ebp set bp_etiquet = bp_codeext;
update t_ebp set bp_codeext = null;
update t_cable set cb_etiquet = cb_codeext;



/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_ban_id=null;
update t_adresse set ad_y_ban=null;
update t_adresse set ad_x_ban=null;
update t_adresse set ad_prio = '0';
update t_adresse set ad_ietat = 'CI';
update t_adresse set ad_typzone = '3';
update t_adresse set ad_geolsrc = 'ORTO';
update t_adresse set ad_racc = '7' where ad_racc = '' ;
/*update t_adresse set ad_imneuf = '0' where ad_racc = '' ;
 update t_adresse set ad_imneuf = '0' where ad_itypeim  = '' ;*/
update t_adresse set ad_iaccgst = '0' where ad_itypeim  = '' ;
update t_adresse set ad_itypeim  = 'P' where ad_itypeim  = '' ;



/* batcode SRO et NRO */
update t_adresse set ad_batcode= 'NA19EHS1000000001' where ad_batcode = 'SHL_19011_ARNA' ;
update t_adresse set ad_batcode= 'NA19EHS1000000002' where ad_batcode = 'SHL_19015_AYEN' ;
update t_adresse set ad_batcode= 'NA19EHS1000000003' where ad_batcode = 'SHL_19242_SAIN' ;
update t_adresse set ad_batcode= 'NA19EHS1000000004' where ad_batcode = 'SHL_19072_DONZ' ;
update t_adresse set ad_batcode= 'NA19EHS1000000005' where ad_batcode = 'SHL_19094_JUIL' ;
update t_adresse set ad_batcode= 'NA19EHS1000000006' where ad_batcode = 'SHL_19191_ZUJE' ;
update t_adresse set ad_batcode= 'NA19EHS1000000007' where ad_batcode = 'SHL_19121_LUBE' ;
update t_adresse set ad_batcode= 'NA19EHS1000000008' where ad_batcode = 'SHL_19147_NESP' ;
update t_adresse set ad_batcode= 'NA19EHS1000000009' where ad_batcode = 'SHL_19153_OBJA' ;
update t_adresse set ad_batcode= 'NA19EHS1000000010' where ad_batcode = 'SHL_19162_PERP' ;
update t_adresse set ad_batcode= 'NA19EHS1000000011' where ad_batcode = 'SHL_19216_ZYME' ;
update t_adresse set ad_batcode= 'NA19EHS1000000012' where ad_batcode = 'SHL_19250_SALO' ;
update t_adresse set ad_batcode= 'NA19EHS1000000013' where ad_batcode = 'SHL_19276_UZER' ;
update t_adresse set ad_batcode= 'NA19EHS1000000014' where ad_batcode = 'SHL_19285_VIGE' ;
update t_adresse set ad_batcode= 'NA19EHS1000000015' where ad_batcode = 'SHL_19030_BRIG' ;
update t_adresse set ad_batcode= 'NA19EHS2000000001' where ad_batcode = 'ADR_19022_CALV' ;
update t_adresse set ad_batcode= 'NA19EHS2000000002' where ad_batcode = 'ADR_19121_PRAD' ;
update t_adresse set ad_batcode= 'NA19EHS2000000003' where ad_batcode = 'ADR_19060_GOPA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000004' where ad_batcode = 'ADR_19254_MEDI' ;
update t_adresse set ad_batcode= 'NA19EHS2000000005' where ad_batcode = 'ADR_19230_DEPA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000006' where ad_batcode = 'ADR_19276_FECE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000007' where ad_batcode = 'ADR_19059_KIMY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000008' where ad_batcode = 'ADR_19270_POFU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000009' where ad_batcode = 'ADR_19094_MIRA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000010' where ad_batcode = 'ADR_19094_CEFA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000011' where ad_batcode = 'ADR_19035_PLAC' ;
update t_adresse set ad_batcode= 'NA19EHS2000000012' where ad_batcode = 'ADR_19196_ORME' ;
update t_adresse set ad_batcode= 'NA19EHS2000000013' where ad_batcode = 'ADR_19288_POST' ;
update t_adresse set ad_batcode= 'NA19EHS2000000014' where ad_batcode = 'ADR_19239_VIEI' ;
update t_adresse set ad_batcode= 'NA19EHS2000000015' where ad_batcode = 'ADR_19182_ROBE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000016' where ad_batcode = 'ADR_19182_CEVE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000017' where ad_batcode = 'ADR_19229_DOCT' ;
update t_adresse set ad_batcode= 'NA19EHS2000000018' where ad_batcode = 'ADR_19129_FOIR' ;
update t_adresse set ad_batcode= 'NA19EHS2000000019' where ad_batcode = 'ADR_19250_SEXA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000020' where ad_batcode = 'SHL_19216_ZANE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000021' where ad_batcode = 'SHL_19121_FOXO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000022' where ad_batcode = 'ADR_19121_SUPU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000023' where ad_batcode = 'ADR_19248_CHAT' ;
update t_adresse set ad_batcode= 'NA19EHS2000000024' where ad_batcode = 'ADR_19079_SAGN' ;
update t_adresse set ad_batcode= 'NA19EHS2000000025' where ad_batcode = 'ADR_19011_VIEU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000026' where ad_batcode = 'ADR_19276_RAYM' ;
update t_adresse set ad_batcode= 'NA19EHS2000000027' where ad_batcode = 'SHL_19276_MURI' ;
update t_adresse set ad_batcode= 'NA19EHS2000000028' where ad_batcode = 'ADR_19243_LUNO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000029' where ad_batcode = 'ADR_19243_FARU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000030' where ad_batcode = 'SHL_19285_VIGE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000031' where ad_batcode = 'ADR_19285_MOVO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000032' where ad_batcode = 'ADR_19154_FOMB' ;
update t_adresse set ad_batcode= 'NA19EHS2000000033' where ad_batcode = 'SHL_19162_COTE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000034' where ad_batcode = 'ADR_19162_DEVY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000035' where ad_batcode = 'ADR_19188_HAHY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000036' where ad_batcode = 'ADR_19178_ARDO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000037' where ad_batcode = 'SHL_19015_RYTU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000038' where ad_batcode = 'NA_19015_FAHU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000039' where ad_batcode = 'ADR_19151_BIPY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000040' where ad_batcode = 'ADR_19289_PROD' ;
update t_adresse set ad_batcode= 'NA19EHS2000000041' where ad_batcode = 'SHL_19030_PIZA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000042' where ad_batcode = 'ADR_19229_HYHI' ;
update t_adresse set ad_batcode= 'NA19EHS2000000043' where ad_batcode = 'ADR_19117_PERR' ;
update t_adresse set ad_batcode= 'NA19EHS2000000044' where ad_batcode = 'ADR_19117_TIXE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000045' where ad_batcode = 'SHL_19147_FOVO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000046' where ad_batcode = 'SHL_19121_CIBY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000047' where ad_batcode = 'SHL_19011_XAPA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000048' where ad_batcode = 'ADR_19276_ALEX' ;
update t_adresse set ad_batcode= 'NA19EHS2000000049' where ad_batcode = 'ADR_19288_CEYR' ;
update t_adresse set ad_batcode= 'NA19EHS2000000050' where ad_batcode = 'ADR_19234_DAZY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000051' where ad_batcode = 'ADR_19153_JULE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000052' where ad_batcode = 'SHL_19153_HUSA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000053' where ad_batcode = 'ADR_19153_HENR' ;
update t_adresse set ad_batcode= 'NA19EHS2000000054' where ad_batcode = 'ADR_19153_NANU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000055' where ad_batcode = 'SHL_19153_DEHA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000056' where ad_batcode = 'ADR_19153_NAVO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000057' where ad_batcode = 'ADR_19072_FUCO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000058' where ad_batcode = 'ADR_19072_FOYE' ;
update t_adresse set ad_batcode= 'NA19EHS2000000059' where ad_batcode = 'SHL_19072_RUMA' ;
update t_adresse set ad_batcode= 'NA19EHS2000000060' where ad_batcode = 'ADR_19229_VICT' ;
update t_adresse set ad_batcode= 'NA19EHS2000000061' where ad_batcode = 'ADR_19229_ORIM' ;
update t_adresse set ad_batcode= 'NA19EHS2000000062' where ad_batcode = 'ADR_19229_BEKO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000063' where ad_batcode = 'ADR_19107_MIKY' ;
update t_adresse set ad_batcode= 'NA19EHS2000000064' where ad_batcode = 'ADR_19107_DOTI' ;
update t_adresse set ad_batcode= 'NA19EHS2000000065' where ad_batcode = 'SHL_19191_CUVU' ;
update t_adresse set ad_batcode= 'NA19EHS2000000066' where ad_batcode = 'ADR_19153_MOLI' ;
update t_adresse set ad_batcode= 'NA19EHS2000000067' where ad_batcode = 'ADR_19286_NABO' ;
update t_adresse set ad_batcode= 'NA19EHS2000000068' where ad_batcode = 'ADR_19093_RAMO' ;




/*t_ebp*/
update t_ebp set bp_statut='AVP';
update t_ebp set bp_gest = bp_prop ;
update t_ebp set bp_proptyp = 'CST';
update t_ebp set bp_ca_nb = null;

/* DELETE FROM t_ebp 
WHERE rowid NOT IN (
    SELECT MAX(rowid) 
    FROM t_ebp
    GROUP BY bp_sf_code )
and bp_typelog='PTO'; */


/*t_ptech*/
update t_ptech set pt_statut='AVP';
update t_ptech set pt_a_haut = '8' where pt_typephy = 'A';
update t_ptech set pt_a_haut = null where pt_avct = 'E';
update t_ptech set pt_secu = '0' where pt_avct = 'C' and pt_typephy = 'C';

/*t_ltech*/
update t_ltech set lt_statut='AVP';
update t_ltech set lt_prop ='OR033001002010';
update t_ltech set lt_gest ='OR033001002010';
update t_ltech set lt_proptyp ='CST';

/*update t_ltech set lt_elec = '0' where lt_st_code in (select st_code from t_sitetech where st_typelog='SRO');
update t_ltech set lt_elec = '1' where lt_st_code in (select st_code from t_sitetech where st_typelog='NRO'); */
update t_ltech set lt_elec= (case
	when (select st_typelog from t_sitetech where st_code=lt_st_code)='NRO' then 1
	else 0 end);



update t_ltech set lt_clim = 'SANS' where lt_st_code in (select st_code from t_sitetech where st_typelog='SRO');
update t_ltech set lt_clim = 'CLIM' where lt_st_code in (select st_code from t_sitetech where st_typelog='NRO');


/*t_sitetech*/
update t_sitetech set st_statut='AVP';
update t_sitetech set st_prop ='OR033001002010';
update t_sitetech set st_gest ='OR033001002010';
update t_sitetech set st_proptyp ='CST';
update t_sitetech set st_nom =st_codeext;

/*t_noeud */
update t_noeud set nd_geolqlt=null;
update t_noeud set nd_codeext=null;

update t_noeud set nd_r3_code='SHL_19011_XAPA' where nd_r2_code='SHL_19011_ARNA' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19011_VIEU' where nd_r2_code='SHL_19011_ARNA' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19059_KIMY' where nd_r2_code='SHL_19011_ARNA' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19243_LUNO' where nd_r2_code='SHL_19011_ARNA' and nd_r3_code='04';
update t_noeud set nd_r3_code='ADR_19243_FARU' where nd_r2_code='SHL_19011_ARNA' and nd_r3_code='05';
update t_noeud set nd_r3_code='ADR_19270_POFU' where nd_r2_code='SHL_19011_ARNA' and nd_r3_code='06';
update t_noeud set nd_r3_code='ADR_19239_VIEI' where nd_r2_code='SHL_19015_AYEN' and nd_r3_code='01';
update t_noeud set nd_r3_code='SHL_19015_RYTU' where nd_r2_code='SHL_19015_AYEN' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_19015_FAHU' where nd_r2_code='SHL_19015_AYEN' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19286_NABO' where nd_r2_code='SHL_19242_SAIN' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19288_POST' where nd_r2_code='SHL_19242_SAIN' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19288_CEYR' where nd_r2_code='SHL_19242_SAIN' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19072_FUCO' where nd_r2_code='SHL_19072_DONZ' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19072_FOYE' where nd_r2_code='SHL_19072_DONZ' and nd_r3_code='02';
update t_noeud set nd_r3_code='SHL_19072_RUMA' where nd_r2_code='SHL_19072_DONZ' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19094_MIRA' where nd_r2_code='SHL_19094_JUIL' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19094_CEFA' where nd_r2_code='SHL_19094_JUIL' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19035_PLAC' where nd_r2_code='SHL_19094_JUIL' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19229_VICT' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19229_ORIM' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19229_BEKO' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19229_HYHI' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='04';
update t_noeud set nd_r3_code='ADR_19107_MIKY' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='05';
update t_noeud set nd_r3_code='ADR_19107_DOTI' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='06';
update t_noeud set nd_r3_code='SHL_19191_CUVU' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='07';
update t_noeud set nd_r3_code='ADR_19229_DOCT' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='08';
update t_noeud set nd_r3_code='ADR_19117_PERR' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='09';
update t_noeud set nd_r3_code='ADR_19117_TIXE' where nd_r2_code='SHL_19191_ZUJE' and nd_r3_code='10';
update t_noeud set nd_r3_code='SHL_19121_CIBY' where nd_r2_code='SHL_19121_LUBE' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19121_PRAD' where nd_r2_code='SHL_19121_LUBE' and nd_r3_code='02';
update t_noeud set nd_r3_code='SHL_19121_FOXO' where nd_r2_code='SHL_19121_LUBE' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19121_SUPU' where nd_r2_code='SHL_19121_LUBE' and nd_r3_code='04';
update t_noeud set nd_r3_code='ADR_19230_DEPA' where nd_r2_code='SHL_19121_LUBE' and nd_r3_code='05';
update t_noeud set nd_r3_code='ADR_19093_RAMO' where nd_r2_code='SHL_19147_NESP' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19153_MOLI' where nd_r2_code='SHL_19147_NESP' and nd_r3_code='02';
update t_noeud set nd_r3_code='SHL_19147_FOVO' where nd_r2_code='SHL_19147_NESP' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19196_ORME' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19153_JULE' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='02';
update t_noeud set nd_r3_code='SHL_19153_HUSA' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19153_HENR' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='04';
update t_noeud set nd_r3_code='ADR_19153_NANU' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='05';
update t_noeud set nd_r3_code='SHL_19153_DEHA' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='06';
update t_noeud set nd_r3_code='ADR_19182_ROBE' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='07';
update t_noeud set nd_r3_code='ADR_19182_CEVE' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='08';
update t_noeud set nd_r3_code='ADR_19153_NAVO' where nd_r2_code='SHL_19153_OBJA' and nd_r3_code='09';
update t_noeud set nd_r3_code='SHL_19162_COTE' where nd_r2_code='SHL_19162_PERP' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19162_DEVY' where nd_r2_code='SHL_19162_PERP' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19188_HAHY' where nd_r2_code='SHL_19162_PERP' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19234_DAZY' where nd_r2_code='SHL_19162_PERP' and nd_r3_code='04';
update t_noeud set nd_r3_code='ADR_19178_ARDO' where nd_r2_code='SHL_19162_PERP' and nd_r3_code='05';
update t_noeud set nd_r3_code='SHL_19216_ZANE' where nd_r2_code='SHL_19216_ZYME' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19254_MEDI' where nd_r2_code='SHL_19216_ZYME' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19129_FOIR' where nd_r2_code='SHL_19250_SALO' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19022_CALV' where nd_r2_code='SHL_19250_SALO' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19250_SEXA' where nd_r2_code='SHL_19250_SALO' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19248_CHAT' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19060_GOPA' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19079_SAGN' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19276_ALEX' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='04';
update t_noeud set nd_r3_code='ADR_19276_RAYM' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='05';
update t_noeud set nd_r3_code='SHL_19276_MURI' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='06';
update t_noeud set nd_r3_code='ADR_19276_FECE' where nd_r2_code='SHL_19276_UZER' and nd_r3_code='07';
update t_noeud set nd_r3_code='SHL_19285_VIGE' where nd_r2_code='SHL_19285_VIGE' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19285_MOVO' where nd_r2_code='SHL_19285_VIGE' and nd_r3_code='02';
update t_noeud set nd_r3_code='ADR_19154_FOMB' where nd_r2_code='SHL_19285_VIGE' and nd_r3_code='03';
update t_noeud set nd_r3_code='ADR_19151_BIPY' where nd_r2_code='SHL_19030_BRIG' and nd_r3_code='01';
update t_noeud set nd_r3_code='ADR_19289_PROD' where nd_r2_code='SHL_19030_BRIG' and nd_r3_code='02';
update t_noeud set nd_r3_code='SHL_19030_PIZA' where nd_r2_code='SHL_19030_BRIG' and nd_r3_code='03';
update t_noeud set nd_r3_code=NULL where nd_r3_code='00';

/*t_cableline*/
update t_cableline set cl_geolqlt=null;
delete from t_cableline where st_length (geom) = 0;
update t_cableline set cl_long = st_length (geom) where cl_long = 0;

/*t_cheminement*/
update t_cheminement set cm_r1_code = '19';
update t_cheminement set cm_statut='AVP';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;

update t_cheminement set cm_gest_do = NULL;

update t_cheminement set cm_prop_do = (case 
when cm_prop_do = '19' then  'OR033001002010' 
when cm_prop_do = 'ORANGE' then 'OR033001001581'
when cm_prop_do = 'ENEDIS' then 'OR033002000000'
when cm_prop_do = 'PRIVE' then 'OR033002100041'
when cm_prop_do = 'RIP1G' then 'OR033001002010' 
end);


update t_cheminement set cm_etat=null;



/*update t_zpbo set zp_capamax=null;*/

/* t_znro */
update t_znro set zn_nrotype = 'PON';
update t_znro set zn_etat = 'DP';
update t_znro set zn_r2_code = zn_nroref;

/*t_zsro*/
/*update t_zsro set zs_capamax=null;*/
/*update t_zsro set zs_nblogmt=null;*/
update t_zsro set zs_etatpm = 'EC';
update t_zsro set zs_typeemp = 'ADR';
update t_zsro set zs_typeing = 'mono';
update t_zsro set zs_actif = '0';
update t_zsro set zs_r3_code = zs_refpm;


/* t_zpbo */
update t_zpbo set zp_r3_code='SHL_19011_XAPA' where zp_r2_code='SHL_19011_ARNA' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19011_VIEU' where zp_r2_code='SHL_19011_ARNA' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19059_KIMY' where zp_r2_code='SHL_19011_ARNA' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19243_LUNO' where zp_r2_code='SHL_19011_ARNA' and zp_r3_code='04';
update t_zpbo set zp_r3_code='ADR_19243_FARU' where zp_r2_code='SHL_19011_ARNA' and zp_r3_code='05';
update t_zpbo set zp_r3_code='ADR_19270_POFU' where zp_r2_code='SHL_19011_ARNA' and zp_r3_code='06';
update t_zpbo set zp_r3_code='ADR_19239_VIEI' where zp_r2_code='SHL_19015_AYEN' and zp_r3_code='01';
update t_zpbo set zp_r3_code='SHL_19015_RYTU' where zp_r2_code='SHL_19015_AYEN' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_19015_FAHU' where zp_r2_code='SHL_19015_AYEN' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19286_NABO' where zp_r2_code='SHL_19242_SAIN' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19288_POST' where zp_r2_code='SHL_19242_SAIN' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19288_CEYR' where zp_r2_code='SHL_19242_SAIN' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19072_FUCO' where zp_r2_code='SHL_19072_DONZ' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19072_FOYE' where zp_r2_code='SHL_19072_DONZ' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SHL_19072_RUMA' where zp_r2_code='SHL_19072_DONZ' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19094_MIRA' where zp_r2_code='SHL_19094_JUIL' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19094_CEFA' where zp_r2_code='SHL_19094_JUIL' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19035_PLAC' where zp_r2_code='SHL_19094_JUIL' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19229_VICT' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19229_ORIM' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19229_BEKO' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19229_HYHI' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='04';
update t_zpbo set zp_r3_code='ADR_19107_MIKY' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='05';
update t_zpbo set zp_r3_code='ADR_19107_DOTI' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='06';
update t_zpbo set zp_r3_code='SHL_19191_CUVU' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='07';
update t_zpbo set zp_r3_code='ADR_19229_DOCT' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='08';
update t_zpbo set zp_r3_code='ADR_19117_PERR' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='09';
update t_zpbo set zp_r3_code='ADR_19117_TIXE' where zp_r2_code='SHL_19191_ZUJE' and zp_r3_code='10';
update t_zpbo set zp_r3_code='SHL_19121_CIBY' where zp_r2_code='SHL_19121_LUBE' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19121_PRAD' where zp_r2_code='SHL_19121_LUBE' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SHL_19121_FOXO' where zp_r2_code='SHL_19121_LUBE' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19121_SUPU' where zp_r2_code='SHL_19121_LUBE' and zp_r3_code='04';
update t_zpbo set zp_r3_code='ADR_19230_DEPA' where zp_r2_code='SHL_19121_LUBE' and zp_r3_code='05';
update t_zpbo set zp_r3_code='ADR_19093_RAMO' where zp_r2_code='SHL_19147_NESP' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19153_MOLI' where zp_r2_code='SHL_19147_NESP' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SHL_19147_FOVO' where zp_r2_code='SHL_19147_NESP' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19196_ORME' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19153_JULE' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SHL_19153_HUSA' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19153_HENR' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='04';
update t_zpbo set zp_r3_code='ADR_19153_NANU' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='05';
update t_zpbo set zp_r3_code='SHL_19153_DEHA' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='06';
update t_zpbo set zp_r3_code='ADR_19182_ROBE' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='07';
update t_zpbo set zp_r3_code='ADR_19182_CEVE' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='08';
update t_zpbo set zp_r3_code='ADR_19153_NAVO' where zp_r2_code='SHL_19153_OBJA' and zp_r3_code='09';
update t_zpbo set zp_r3_code='SHL_19162_COTE' where zp_r2_code='SHL_19162_PERP' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19162_DEVY' where zp_r2_code='SHL_19162_PERP' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19188_HAHY' where zp_r2_code='SHL_19162_PERP' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19234_DAZY' where zp_r2_code='SHL_19162_PERP' and zp_r3_code='04';
update t_zpbo set zp_r3_code='ADR_19178_ARDO' where zp_r2_code='SHL_19162_PERP' and zp_r3_code='05';
update t_zpbo set zp_r3_code='SHL_19216_ZANE' where zp_r2_code='SHL_19216_ZYME' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19254_MEDI' where zp_r2_code='SHL_19216_ZYME' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19129_FOIR' where zp_r2_code='SHL_19250_SALO' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19022_CALV' where zp_r2_code='SHL_19250_SALO' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19250_SEXA' where zp_r2_code='SHL_19250_SALO' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19248_CHAT' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19060_GOPA' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19079_SAGN' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19276_ALEX' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='04';
update t_zpbo set zp_r3_code='ADR_19276_RAYM' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='05';
update t_zpbo set zp_r3_code='SHL_19276_MURI' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='06';
update t_zpbo set zp_r3_code='ADR_19276_FECE' where zp_r2_code='SHL_19276_UZER' and zp_r3_code='07';
update t_zpbo set zp_r3_code='SHL_19285_VIGE' where zp_r2_code='SHL_19285_VIGE' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19285_MOVO' where zp_r2_code='SHL_19285_VIGE' and zp_r3_code='02';
update t_zpbo set zp_r3_code='ADR_19154_FOMB' where zp_r2_code='SHL_19285_VIGE' and zp_r3_code='03';
update t_zpbo set zp_r3_code='ADR_19151_BIPY' where zp_r2_code='SHL_19030_BRIG' and zp_r3_code='01';
update t_zpbo set zp_r3_code='ADR_19289_PROD' where zp_r2_code='SHL_19030_BRIG' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SHL_19030_PIZA' where zp_r2_code='SHL_19030_BRIG' and zp_r3_code='03';



/*t_cable*/
update t_cable set cb_modulo=12 where cb_capafo>72 and cb_typelog='DI';
update t_cable set cb_modulo=6 where cb_capafo<96 and cb_typelog='DI';
update t_cable set cb_modulo=12 where cb_typelog='TR' OR cb_typelog='CO';
update t_cable set cb_modulo=2 where cb_typelog='RA';
update t_cable set cb_proptyp = 'CST';

update t_cable set cb_statut='AVP';
update t_cable set cb_etat=null;

update t_cable set cb_r3_code='' where cb_typelog='TR';
update t_cable set cb_r3_code='' where cb_typelog='CO';

/*update t_cable set cb_rf_code='RF033000000309' where cb_typelog='RA';*/
update t_cable set cb_capafo='2' where cb_capafo='1';

update t_cable set cb_r3_code='SHL_19011_XAPA' where cb_r2_code='SHL_19011_ARNA' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19011_VIEU' where cb_r2_code='SHL_19011_ARNA' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19059_KIMY' where cb_r2_code='SHL_19011_ARNA' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19243_LUNO' where cb_r2_code='SHL_19011_ARNA' and cb_r3_code='04';
update t_cable set cb_r3_code='ADR_19243_FARU' where cb_r2_code='SHL_19011_ARNA' and cb_r3_code='05';
update t_cable set cb_r3_code='ADR_19270_POFU' where cb_r2_code='SHL_19011_ARNA' and cb_r3_code='06';
update t_cable set cb_r3_code='ADR_19239_VIEI' where cb_r2_code='SHL_19015_AYEN' and cb_r3_code='01';
update t_cable set cb_r3_code='SHL_19015_RYTU' where cb_r2_code='SHL_19015_AYEN' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_19015_FAHU' where cb_r2_code='SHL_19015_AYEN' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19286_NABO' where cb_r2_code='SHL_19242_SAIN' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19288_POST' where cb_r2_code='SHL_19242_SAIN' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19288_CEYR' where cb_r2_code='SHL_19242_SAIN' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19072_FUCO' where cb_r2_code='SHL_19072_DONZ' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19072_FOYE' where cb_r2_code='SHL_19072_DONZ' and cb_r3_code='02';
update t_cable set cb_r3_code='SHL_19072_RUMA' where cb_r2_code='SHL_19072_DONZ' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19094_MIRA' where cb_r2_code='SHL_19094_JUIL' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19094_CEFA' where cb_r2_code='SHL_19094_JUIL' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19035_PLAC' where cb_r2_code='SHL_19094_JUIL' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19229_VICT' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19229_ORIM' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19229_BEKO' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19229_HYHI' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='04';
update t_cable set cb_r3_code='ADR_19107_MIKY' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='05';
update t_cable set cb_r3_code='ADR_19107_DOTI' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='06';
update t_cable set cb_r3_code='SHL_19191_CUVU' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='07';
update t_cable set cb_r3_code='ADR_19229_DOCT' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='08';
update t_cable set cb_r3_code='ADR_19117_PERR' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='09';
update t_cable set cb_r3_code='ADR_19117_TIXE' where cb_r2_code='SHL_19191_ZUJE' and cb_r3_code='10';
update t_cable set cb_r3_code='SHL_19121_CIBY' where cb_r2_code='SHL_19121_LUBE' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19121_PRAD' where cb_r2_code='SHL_19121_LUBE' and cb_r3_code='02';
update t_cable set cb_r3_code='SHL_19121_FOXO' where cb_r2_code='SHL_19121_LUBE' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19121_SUPU' where cb_r2_code='SHL_19121_LUBE' and cb_r3_code='04';
update t_cable set cb_r3_code='ADR_19230_DEPA' where cb_r2_code='SHL_19121_LUBE' and cb_r3_code='05';
update t_cable set cb_r3_code='ADR_19093_RAMO' where cb_r2_code='SHL_19147_NESP' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19153_MOLI' where cb_r2_code='SHL_19147_NESP' and cb_r3_code='02';
update t_cable set cb_r3_code='SHL_19147_FOVO' where cb_r2_code='SHL_19147_NESP' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19196_ORME' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19153_JULE' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='02';
update t_cable set cb_r3_code='SHL_19153_HUSA' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19153_HENR' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='04';
update t_cable set cb_r3_code='ADR_19153_NANU' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='05';
update t_cable set cb_r3_code='SHL_19153_DEHA' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='06';
update t_cable set cb_r3_code='ADR_19182_ROBE' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='07';
update t_cable set cb_r3_code='ADR_19182_CEVE' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='08';
update t_cable set cb_r3_code='ADR_19153_NAVO' where cb_r2_code='SHL_19153_OBJA' and cb_r3_code='09';
update t_cable set cb_r3_code='SHL_19162_COTE' where cb_r2_code='SHL_19162_PERP' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19162_DEVY' where cb_r2_code='SHL_19162_PERP' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19188_HAHY' where cb_r2_code='SHL_19162_PERP' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19234_DAZY' where cb_r2_code='SHL_19162_PERP' and cb_r3_code='04';
update t_cable set cb_r3_code='ADR_19178_ARDO' where cb_r2_code='SHL_19162_PERP' and cb_r3_code='05';
update t_cable set cb_r3_code='SHL_19216_ZANE' where cb_r2_code='SHL_19216_ZYME' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19254_MEDI' where cb_r2_code='SHL_19216_ZYME' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19129_FOIR' where cb_r2_code='SHL_19250_SALO' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19022_CALV' where cb_r2_code='SHL_19250_SALO' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19250_SEXA' where cb_r2_code='SHL_19250_SALO' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19248_CHAT' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19060_GOPA' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19079_SAGN' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19276_ALEX' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='04';
update t_cable set cb_r3_code='ADR_19276_RAYM' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='05';
update t_cable set cb_r3_code='SHL_19276_MURI' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='06';
update t_cable set cb_r3_code='ADR_19276_FECE' where cb_r2_code='SHL_19276_UZER' and cb_r3_code='07';
update t_cable set cb_r3_code='SHL_19285_VIGE' where cb_r2_code='SHL_19285_VIGE' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19285_MOVO' where cb_r2_code='SHL_19285_VIGE' and cb_r3_code='02';
update t_cable set cb_r3_code='ADR_19154_FOMB' where cb_r2_code='SHL_19285_VIGE' and cb_r3_code='03';
update t_cable set cb_r3_code='ADR_19151_BIPY' where cb_r2_code='SHL_19030_BRIG' and cb_r3_code='01';
update t_cable set cb_r3_code='ADR_19289_PROD' where cb_r2_code='SHL_19030_BRIG' and cb_r3_code='02';
update t_cable set cb_r3_code='SHL_19030_PIZA' where cb_r2_code='SHL_19030_BRIG' and cb_r3_code='03';




/*t_conduite*/
update t_conduite set cd_statut = 'AVP';
update t_conduite set cd_r1_code = null ;
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR033001002010' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR033001002010' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);


update t_conduite set cd_type = 'NC' where cd_avct='E';
update t_conduite set cd_type='PEHD' where cd_type= 'PVC';
update t_conduite set cd_dia_int= '33' where cd_type= 'PEHD';
update t_conduite set cd_dia_ext= '40' where cd_type= 'PEHD';


update t_conduite set cd_r1_code=null;
update t_conduite set cd_proptyp=null;
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;

/* t_baie */
update t_baie set ba_codeext=null;
update t_baie set ba_prop='OR033001002010';
update t_baie set ba_gest='OR033001002010';
update t_baie set ba_proptyp='CST';
update t_baie set ba_type='BAIE';
update t_baie set ba_etiquet =(select lt_etiquet from  t_ltech where ba_lt_code= lt_code) || ba_etiquet;

/* t_tiroir */
update t_tiroir set ti_prop='OR033001002010';
update t_tiroir set ti_type='TIROIR';
update t_tiroir set ti_placemt = ti_etiquet;
update t_tiroir set ti_etiquet=( select ba_etiquet from t_baie where ti_ba_code=ba_code) ||'_'|| ti_etiquet;
update t_tiroir set ti_taille = '3';
update t_tiroir set ti_rf_code = 'RF033000000254';

/* t_fibre */
update t_fibre set fo_proptyp='CST';

update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='DI');
update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='RA');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='TR');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='CO');

/* t_position 
update t_position set ps_preaff = (case 
when ps_comment = 'ABONNE' then  'ABONNE'
end);
update t_position set ps_cs_code = NULL where ps_fonct = 'CO';

delete from t_position where ps_fonct=''; */

/* t_ropt */
DELETE FROM t_ropt; 


/* no PTO 
delete from t_cable_patch201 where cb_bp2 in (select BP_CODE from t_ebp where bp_typelog='PTO');
delete from t_ebp where bp_typelog='PTO'; */

/* t_cassette 
delete from t_cassette_patch201 where cs_ti_code is null;
update t_cassette set cs_bp_code= null where cs_code in ( select cs_code from t_cassette_patch201);
delete from t_cassette_patch201;
delete from t_cassette where cs_bp_code is null;
update t_cassette set cs_face= 'A';*/


/*sup SRO NRO t_cable_patche*/
update t_cable_patch201 set cb_bp1 = NULL where cb_bp1 in (select bp_code from t_ebp where bp_typelog='SRO' or bp_typelog='NRO');
update t_cable_patch201 set cb_bp2 = NULL where cb_bp2 in (select bp_code from t_ebp where bp_typelog='SRO' or bp_typelog='NRO');

/* sup SRO et NRO dans t_ebp */
delete from t_ebp where bp_typelog='SRO';
delete from t_ebp where bp_typelog='NRO';

 


/* t_love*/

delete from t_love where lv_long = '0';

/* t_suf*/
update t_suf set sf_comment = 'Futur prise' where sf_ad_code in ( select ad_code from t_adresse where ad_imneuf='0');


/* champs a vider */
update t_adresse set ad_typzone=null;
update t_baie set ba_creadat=null;
update t_ebp set bp_creadat=null;
update t_cable set cb_creadat=null;
update t_cab_cond set cc_creadat=null;
update t_conduite set cd_creadat=null;
update t_conduite set cd_r2_code=null;
update t_cableline set cl_creadat=null;
update t_cableline set cl_long=null;
update t_cheminement set cm_creadat=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_geolqlt=null;
update t_cheminement set cm_geolsrc=null;
update t_cheminement set cm_gest_do=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_long=null;
update t_cassette set cs_creadat=null;
update t_cassette set cs_nb_pas=null;
update t_cond_chem set dm_creadat=null;
update t_fibre set fo_color=null;
update t_fibre set fo_creadat=null;
update t_fibre set fo_proptyp=null;
update t_fibre set fo_reper=null;
update t_ltech set lt_creadat=null;
update t_ltech set lt_dateins=null;
update t_ltech set lt_datemes=null;
update t_ltech set lt_proptyp=null;
update t_love set lv_creadat=null;
update t_noeud set nd_creadat=null;
update t_noeud set nd_geolqlt=null;
update t_position set ps_creadat=null;
update t_ptech set pt_creadat=null;
update t_suf set sf_creadat=null;
update t_sitetech set st_codeext=null;
update t_sitetech set st_creadat=null;
update t_sitetech set st_etat=null;
update t_tiroir set ti_creadat=null;
update t_znro set zn_creadat=null;
update t_znro set zn_nrotype=null;
update t_zpbo set zp_creadat=null;
update t_zsro set zs_creadat=null;
update t_zsro set zs_nbcolmt=null;
update t_zsro set zs_typeing=null;
update t_cable set cb_codeext = null;

/* Maj l_tech_patch_201 pour sro et nro */
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in (select lt_code from t_ltech_patch201);


/* collecte mutualis dans distri transport */

update t_cheminement set cm_typelog='CT' where cm_typelog='CO';
update t_cheminement set cm_typelog='CX' where cm_typelog='CD';
update t_cable set cb_typelog='CT' where cb_typelog='CO';

end transaction;