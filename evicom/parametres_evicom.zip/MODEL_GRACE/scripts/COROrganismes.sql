begin transaction;
/* maj orange */
update t_cable set cb_prop='OR033001001581' where cb_prop='OR91000000000003';
update t_ebp set bp_prop='OR033001001581' where bp_prop='OR91000000000003';
update t_ptech set pt_prop='OR033001001581' where pt_prop='OR91000000000003';
update t_ltech set lt_prop='OR033001001581' where lt_prop='OR91000000000003';
update t_sitetech set st_prop='OR033001001581' where st_prop='OR91000000000003';

/* maj enedis */
update t_cable set cb_prop='OR033002000000' where cb_prop='OR91000000000004';
update t_ebp set bp_prop='OR033002000000' where bp_prop='OR91000000000004';
update t_ptech set pt_prop='OR033002000000' where pt_prop='OR91000000000004';
update t_ltech set lt_prop='OR033002000000' where lt_prop='OR91000000000004';
update t_sitetech set st_prop='OR033002000000' where st_prop='OR91000000000004';

/*maj client*/
update t_cable set cb_prop='OR033001002010' where cb_prop='OR91000000000002' or cb_prop='OR91000000000001';
update t_ebp set bp_prop='OR033001002010' where bp_prop='OR91000000000002' or bp_prop='OR91000000000001';
update t_ptech set pt_prop='OR033001002010' where pt_prop='OR91000000000002' or pt_prop='OR91000000000001';
update t_ltech set lt_prop='OR033001002010' where lt_prop='OR91000000000002' or lt_prop='OR91000000000001';
update t_sitetech set st_prop='OR033001002010' where st_prop='OR91000000000002' or st_prop='OR91000000000001';

/*maj indertemine*/
update t_cable set cb_prop='OR033002100042' where cb_prop='OR91000000000006' ;
update t_ebp set bp_prop='OR033002100042' where bp_prop='OR91000000000006' ;
update t_ptech set pt_prop='OR033002100042' where pt_prop='OR91000000000006' ;
update t_ltech set lt_prop='OR033002100042' where lt_prop='OR91000000000006' ;
update t_sitetech set st_prop='OOR033002100042' where st_prop='OR91000000000006';


/* gest */
update t_ptech set pt_gest=pt_prop;
update t_cable set cb_gest=cb_prop;

/* t_ptech */
update t_ptech set pt_prop=null;
update t_ptech set pt_prop='0' where pt_gest='OR033001002010' ;


End transaction;
