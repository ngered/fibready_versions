﻿begin transaction;

/*t_adresse*/
--update t_adresse set ad_ietat='DE'; --améliorer pour différencier selon le statut des adresses

/* t_noeud */
update t_noeud set nd_dtclass='A' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C'); -- classe A pour le GC à créer: classe de précision
update t_noeud set nd_geolqlt=0.4 where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C'); -- 0.4 pour le GC à créer: précision du positionnement de l'objet
update t_noeud set nd_geolmod='DETC' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C'); -- mode d'implantation de l'objet ATTENTION A VERIFIER (LTRO: levé durant la pose; LVIS: levé après la pose; DETC: levé avec détection)


/*t_cable*/
update t_cable set cb_etiquet = cb_codeext;--étiquette équivalente au codeext
update t_cable set cb_proptyp= 'CST';--par défaut CST
update t_cable set cb_etat='OK';--OK par défaut
update t_cable set cb_datemes = DATE('NOW') where cb_statut = 'REC' and (cb_datemes='' or cb_datemes=null);--prend la date du DOE
update t_cable set cb_avct ='E' where cb_statut='REC';--passe à E en DOE
--update t_cable set cb_capafo = '2' where cb_capafo = '1';

/*t_cableline*/
update t_cableline set cl_geolmod = 'INDT'; --A REVOIR infos à faire remonter du terrain

/*t_cheminement*/
update t_cheminement set cm_r4_code=null; --MCD: à ne plus remplir
--update t_cheminement set cm_prop_do=null;
update t_cheminement set cm_geolmod = (case 
when cm_avct = 'C' and cm_typ_imp = '7' THEN 'DETC'
when cm_avct = 'C' and cm_typ_imp = '0' THEN 'DETC'
else 'INDT'
end); -- REGLE A CONFIRMER INDT pour les cheminements n'appartenant pas au département
update t_cheminement set cm_datemes= DATE('NOW') where cm_avct ='C' and cm_statut = 'REC' and cm_datemes='';--date de mise en service = date du jour de la DOE pour le GC à créer
update t_cheminement set cm_etat='OK' where cm_avct = 'C'and cm_typ_imp = '7' and cm_statut='REC'; --neuf donc OK pour le GC à créer
update t_cheminement set cm_fildtec= 1 where cm_avct = 'C' and cm_typ_imp = '7'; --plynox pour le GC à créer
update t_cheminement set cm_dtclass='A' where cm_avct = 'C' and cm_typ_imp = '7';--pour le GC à créer
update t_cheminement set cm_geolqlt=0.4 where cm_avct = 'C' and cm_typ_imp = '7';--pour le GC à créer
update t_cheminement set cm_avct = 'C' where cm_statut='REC';--une fois toutes les mise à jour faites sur le GC à créer, passer le GC à existant pour les éléments au statut REC
--update t_cheminement set cm_gest_do = ( case 
--when cm_gest_do = 'ERDF' THEN 'OR34000000000001'
--when cm_gest_do = 'ORANGE' THEN 'OR34000000000002'
--when cm_gest_do = 'PRIVE' THEN 'OR34000000000394'
--when cm_gest_do = 'DSP' THEN 'OR34000000000395'
--end
--);

/*t_conduite*/

--update t_conduite set cd_user= ; à confirmer
update t_conduite set cd_prop = 'OR34000000000395' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='C';--proriétaire=HERAULT THD pour tout ce qui est à construire
update t_conduite set cd_prop = 'OR34000000000002' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=7 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=0);--ORANGE pour les conduites de type 7 existantes ou pour l'aérien ORANGE
update t_conduite set cd_prop = 'OR34000000000001' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=1;--ENEDIS pour l'aérien ERDF
update t_conduite set cd_prop = 'OR34000000000394' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--PRIVE pour les facades et le cheminement immeuble	
update t_conduite set cd_user='OR34000000000395' ; --utilisateur du fourreau est la DSP A VERIFIER
--update t_conduite set cd_statut=(select cm_statut from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même staut que le cheminement
update t_conduite set cd_etat = 'OK' where cd_statut='REC';--ok pour bon état par défaut: MCD
update t_conduite set cd_datemes = DATE('NOW') where cd_statut = 'REC' and (cd_datemes=''or cd_datemes=null);--date de la DOE
--update t_conduite set cd_gest=null;
update t_conduite set cd_nbcable=null;--pas demandé dans le MCD
update t_conduite set cd_type = 'NC' where cd_avct= 'E';--cd_type nécessaire uniquement pour le GC à créer

/*t_ebp*/
update t_ebp set bp_etiquet = bp_codeext where bp_typelog<>'PTO';--etiquette = codeext de la BPE par défaut
update t_ebp set bp_etat = 'OK';--OK car on ne pose que du neuf
update t_ebp set bp_datemes = DATE('NOW') where bp_statut='REC' and bp_datemes='' and bp_typelog='PBO' ;--date de livraison de la DOE uniquement pour les PBO
update t_ebp set bp_avct = 'E' where bp_statut ='REC';--passe à E pour le statut DOE
update t_ebp set bp_nb_pas = null; --vide pour tous les éléments grace à t_reference
--update t_ebp set bp_prop = 'OR34000000000395' where bp_prop = 'OR91000000000001';

/* t_ptech */
update t_ptech set pt_gest_do='A REMPLIR' where pt_avct='C' and pt_gest_do='';--A REMPLIR manuellement avec le gestionnaire de la voie là où il y a la mention A REMPLIR --A DEVELOPPER: utiliser les DE pour remplir ce cham^p
update t_ptech set pt_datemes = DATE('NOW') where pt_statut = 'REC' and (pt_datemes='' or pt_datemes=null);--mise à jour du champ pt_datemes avec la date de la DOE si ce champ est vide, pas encore mis en service
update t_ptech set pt_etat = 'OK' where pt_prop='OR34000000000395';--OK pour les points techniques à créer, appartenant à la DSP
update t_ptech set pt_datemes=DATE('NOW') where pt_statut='REC' and ( pt_datemes='' or pt_datemes=null ); --date de la DOE pour les éléments qui passent en REC
--update t_ptech set pt_typelog = 'T' where pt_code in (select bp_pt_code from t_ebp where bp_typelog='BPE');
update t_ptech set pt_detec = 0 where pt_avct='C' and pt_typephy='C'; --pas de boitier pour plynox par défaut dans les chambres à créer
update t_ptech set pt_occp='1.1' where pt_avct='C' and pt_typephy='C' and pt_code in (select bp_pt_code from t_ebp where bp_typelog='BPE');--par défaut = NON VIDE EXPLOITABLE car chambre neuve de la DSP
update t_ptech set pt_occp='0' where pt_avct='C' and pt_typephy='C' and pt_code not in (select bp_pt_code from t_ebp where bp_typelog='BPE');--par défaut VIDE pour les chambres de la DSP sans BPE
update t_ptech set pt_secu='0' where pt_avct='C' and pt_typephy='C';--0 ou 1  A REMPLIR avec 1 pour les chambres sécurisées de la DSP
--update t_ptech set pt_prop = (case 
--when pt_avct = 'E' and pt_typephy = 'C' then 'OR34000000000002'
--when pt_avct = 'E' and pt_typephy = 'C' then 'A REMPLIR'
--when pt_acvt = 'C' then 'OR34000000000395'
--end);
--update t_ptech set pt_gest =

/* t_ltech */
--update t_ltech set lt_etiquet=lt_codeext; --voir règles d'étiquetage
--update t_ltech set lt_prop = (select st_prop from t_sitetech where lt_st_code = st_code);
--update t_ltech set lt_gest = (select st_gest from t_sitetech where lt_st_code = st_code);
update t_ltech set lt_proptyp = 'CST' where lt_st_code in (select st_code from t_sitetech where st_typelog='NRO' OR st_typelog = 'SRO'); --CST pour le NRO et le SRO
update t_ltech set lt_proptyp = 'OCC' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');--OCC pour les immeubles
update t_ltech set lt_local ='A REMPLIR' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT'); -- A REMPLIR pour les immeubles: positionnement de la BPI
--update t_ltech set lt_elec = 1 where lt_st_code in (select st_code from t_sitetech where st_typelog = 'NRO');--ELECTRICITE présente au NRO
--update t_ltech set lt_elec = 0 where lt_st_code in (select st_code from t_sitetech where st_typelog <> 'NRO');--Pas d'éléctricité
--update t_ltech set lt_clim = 1 where lt_st_code in (select st_code from t_sitetech where st_typelog = 'NRO');--CLIMATISATION au NRO
--update t_ltech set lt_clim = 0 where lt_st_code in (select st_code from t_sitetech where st_typelog <> 'NRO');--Pas de climatisation
--update t_ltech set lt_occp='1.1'; --1.1 par défaut
update t_ltech set lt_elec =null; --MCD: non demandée
update t_ltech set lt_clim =null; --MCD: non demandée
update t_ltech set lt_occp =null; --MCD: non demandée
update t_ltech set lt_statut = (select bp_statut from t_ebp,t_ltech where bp_lt_code = lt_code);--même statut que l'EBP où est le ltech
update t_ltech set lt_etat='OK' where lt_statut='REC';--etat à OK par défaut quand statut est à REC car on pose du neuf
--update t_ltech set lt_datemes = DATE('NOW') where lt_statut = 'REC' and lt_datemes='';--prend la dat du jour la première fois que le statut passe à REC

/* t_sitetech */
update t_sitetech set st_proptyp='OCC'; --OCCUPATION par défaut
update t_sitetech set st_etat='OK';--OK par défaut
update t_sitetech set st_statut = (select lt_statut from t_ltech where lt_st_code = st_code ); --même statut que le ltech qui le porte
--update t_sitetech set st_datemes =DATE('NOW') where st_statut = 'REC' and st_datemes=''; --lorsque datemes est vide, et que le statut est passé à REC, le champ prend la date du jour, si non vide, il garde la date précédente
--update t_sitetech set st_avct = 'C' where st_statut='AVP' or st_statut='PRO' OR st_typelog='NRO'; --C pour à créer pour le NRO et sitetech pas en REC
--update t_sitetech set st_avct = 'E' where st_statut='REC' and st_typelog!='NRO'; --E pour existant quand le sitetech est en statut REC
--update t_sitetech set st_avct = 'E' where st_typelog = 'NRO' and st_codeext=(select zn_r2_code from t_znro where zn_etatlpm = 'DP');--passe à E pour le NRO quand le NRO est 100% déployé
update t_sitetech set st_avct=null;--MCD: non demandé

/* t_suf */
update t_suf set sf_racco = 'RB' where sf_ad_code in (select ad_code from t_adresse where ad_isole = 0);--pour raccordable (liaison PM-PBO)
update t_suf set sf_racco = 'RD' where sf_ad_code in (select ad_code from t_adresse where ad_isole = 1);--pour raccordable sur demande

/* t_zsro */
update t_zsro set zs_refpm=zs_r3_code; --équivalent à st_codeext pour les SRO
update t_zsro set zs_etatpm='DP'; -- passage à DP par défaut DOE
update t_zsro set zs_typeing ='MONO';--MONO par défaut 


/*t_znro*/
--update t_znro set zn_etatlpm=null;--MCD: pas demandée
update t_znro set zn_etat='DP';--MCD: valeur par défaut DP car uniquement en DOE
--update t_znro set zn_nrotype='PON-PTP';

/*t_baie*/
update t_baie set ba_user = 'OR34000000000395'; -- Herault THD par défaut
update t_baie set ba_proptyp='CST'; --construction par défaut
update t_baie set ba_statut = (select lt_statut from t_ltech where ba_lt_code = lt_code); --même staut que le local technique
update t_baie set ba_etat= 'OK' where ba_statut='REC'; -- OK par défaut car neuf quand statut est REC
update t_baie set ba_etat= 'NC' where ba_statut<>'REC'; --NC quand le statut n'est pas encore à REC
update t_baie set ba_type ='BAIE'; -- BAIE par défaut
update t_baie set  ba_rf_code = (select case 
when zs_nblogmt <= 460 then  'RF34000000000003'
when zs_nblogmt > 460 then  'RF34000000000004'
when zs_nblogmt=0 then null
end
from t_zsro, t_baie, t_ltech, t_sitetech
where zs_nd_code= st_nd_code and st_code = lt_st_code and ba_lt_code = lt_code);--référence de la baie selon nombre de logement dans la zsro
update t_baie set ba_rf_code='RF34000000000001' where ba_lt_code in (select lt_code from t_ltech, t_sitetech where st_code=lt_st_code and st_typelog='NRO'); --reference de la baie pour le baie du NRO
 update t_baie set ba_nb_u = (case
									when ba_rf_code ='RF34000000000003'  then 28
									when ba_rf_code='RF34000000000004' then 40
									when ba_rf_code='RF34000000000001' then 42
								end); --nbre de u selon la reference de la baie
update t_baie set ba_codeext= 'HT-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code)|| '-02';--increment du lt_codeext avec le prefixe HT-ARM- et le suffixe 02 pour baie 2 ATTENTION POUR BAIES DU NRO
update t_baie set ba_etiquet = ba_codeext;--par défaut l'étiquette de la baie est le codeext de la baie
update t_baie set ba_prop=(select st_prop from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code);--même propriétaire que le site technique
update t_baie set ba_gest=(select st_gest from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code); --même gestionnaire que le site technique

/* t_tiroir */
delete from t_tiroir where ti_ba_code='' or ti_ba_code=null;--supprimer les tiroirs qui ne correspondent pas à une baie
update t_tiroir set ti_codeext= 'HT-TIR-' || (select substr(ba_codeext,8,8) from t_baie where ti_ba_code = ba_code)||'-'||SUBSTR('00' || ti_etiquet,-2);--tiroir prend l'increment de la baie + numéro du tiroir
update t_tiroir set ti_prop= (select ba_prop from t_baie where ti_ba_code = ba_code);--propriétaire du tiroir = propriétaire de la baie
update t_tiroir set ti_etat = 'OK'; --on pose du neuf donc OK
--update t_tiroir set ti_type = 'TIROIR';
update t_tiroir set ti_taille ='3'; --3 par défaut: A corriger quand on aura tiroir de transport sur 2 U (utiliser la reference)

/*t_cassette*/
delete from t_cassette_patch201 where cs_ti_code not in (select ti_code from t_tiroir);--supprime le cs_ti_code pour les tiroirs non existants 
update t_cassette set cs_face =null;--MCD: ne pas remplir
--update t_cassette set cs_num=null;--MCD: ne pas remplir
update t_cassette set cs_type=null;--MCD: ne pas remplir
update t_cassette set cs_bp_code=null where cs_code in (select cs_code from t_cassette_patch201 where cs_ti_code not null);--vider les bp_code des cassettes dans les NRO et SRO
--update t_cassette set cs_nb_pas=12;--A VERIFIER: 12 positions quelque soit la cassette

/* t_fibre */
update t_fibre set fo_nincab = null;--pas demandé dans le MCD
update t_fibre set fo_type = 'G657A2';--par défaut
update t_fibre set fo_color = null;--pas demandé MCD
update t_fibre set fo_reper = null;--pas demandé MCD

/*t_position*/
 update t_position set ps_type = 'SFU' where ps_fonct = 'EP';--ps_type depend de ps_fonct
 update t_position set ps_type = 'CSA' where ps_fonct = 'CO';--ps_type depend de ps_fonct

/* t_love */ --table à remplir
end transaction;

begin transaction;
update t_tiroir set ti_etiquet= ti_codeext;--tiquette du tiroir = codeext du tiroir en attente régles étiquettage 
end transaction;