﻿begin transaction;
/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);

/*t_ebp*/
update t_ebp set bp_statut='AVP';

/*t_ptech*/
update t_ptech set pt_statut='AVP';

/*t_ltech*/
update t_ltech set lt_statut='AVP';

/*t_sitetech*/
update t_sitetech set st_statut='AVP';

/*t_noeud */
update t_noeud set nd_geolqlt=null;


/*t_cableline*/
update t_cableline set cl_geolqlt=null;

/*t_cheminement*/
update t_cheminement set cm_statut='AVP';
update t_cheminement set cm_compo='';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;
update t_cheminement set cm_statut='AVP';

update t_cheminement set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR033001002010' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);--barbara
update t_cheminement set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR033001002010' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);--barbara


/*update t_zpbo set zp_capamax=null;*/

/*t_zsro*/
/*update t_zsro set zs_capamax=null;*/
update t_zsro set zs_nblogmt=null;


/*t_cable*/

update t_cable set cb_statut='AVP';
end transaction;

/*t_conduite*/
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR033001002010' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);--barbara
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR033001002010' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);--barbara





