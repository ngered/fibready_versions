﻿begin transaction;

/*t_adresse*/
--update t_adresse set ad_ietat='CI';--ad_ietat par defaut valeur CIBLE en APD
update t_adresse set ad_typzone=3; --ad_typzone =3 par défaut APD/DOE
update t_adresse set ad_ietat='CI';

/*t_ptech*/
--update t_ptech set pt_statut = 'PRO'; --en attente d'une gestion des statuts, PRO par défaut en APD 
update t_ptech set pt_rf_code = null; --champ à ne pas remplir (MCD)

/*t_ebp*/
--update t_ebp set bp_statut = 'PRO';--en attente d'une gestion des statuts en DE, PRO par défaut en APD


update t_ebp set bp_codeext = '' where bp_typelog = 'PTO';
update t_ebp set bp_etiquet = bp_codeext;
update t_ebp set bp_statut = 'PRO';


/*t_cable*/
update t_cable set cb_codeext=null where cb_typelog = 'RA';
update t_cable set cb_etiquet=cb_codeext;
update t_cable set cb_statut='PRO';


/*t_sitetech*/
update t_sitetech set st_statut='PRO';--statut normalement dans DE, en attendant: PRO par défaut pour l'APD
--update t_sitetech set st_typephy='' where st_typephy = 'BAT';

/*t_ltech*/
--update t_ltech set lt_codeext=(select replace(st_codeext,'HT-TEC','HT-LT') || '-0'|| (select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code);--compte le nombre de Ltech sur le sitetech
--update t_ltech set lt_etiquet=lt_codeext;--lt_etiquet=lt_codeext en attente régle étiquettage
update t_ltech set lt_statut=(select st_statut from t_sitetech where lt_st_code=st_code);--satut du ltech = statut du sitetech correspondant
update t_ltech set lt_etat='NC'; --lt_etat= NC par défaut, rien n'est encore posé
update t_ltech set lt_prop= (select st_prop from t_sitetech where lt_st_code=st_code);--même propriétaire que sitetech
update t_ltech set lt_gest= (select st_gest from t_sitetech where lt_st_code=st_code);--même gestionnaire que sitetech
update t_ltech set lt_etiquet = lt_codeext;
update t_ltech set lt_etat = 'OK';

/*t_noeud*/
update t_noeud set nd_coderat=nd_r3_code;
update t_noeud set nd_coderat=nd_r2_code where nd_r3_code='';
update t_noeud set nd_type_ep='OPT';



/*t_cheminement*/
--update t_cheminement set cm_statut='PRO';--doit etre issus de DE; en attendant PRO par défaut en APD
update t_cheminement set cm_nature='TEL';

/*t_cond_chem*/
--update t_cond_chem set dm_creadat = DATE('NOW') ; --formatage de la date

/*t_conduite*/
update t_conduite set cd_r4_code=null;--MCD: à ne pas remplir
update t_conduite set cd_avct=(select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même avancement que le cheminement la comportant
update t_conduite set cd_statut=(select cm_statut from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même statut que le cheminement
update t_conduite set cd_prop = 'OR34000000000395' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='C';--proriétaire=HERAULT THD pour tout ce qui est à construire
update t_conduite set cd_prop = 'OR34000000000002' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=7 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=0);--ORANGE pour les conduites de type 7 existantes ou pour l'aérien ORANGE
update t_conduite set cd_prop = 'OR34000000000001' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=1;--ENEDIS pour l'aérien ERDF
update t_conduite set cd_prop = 'OR34000000000394' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--PRIVE pour les facades et le cheminement immeuble	
	--update t_conduite set cd_gest=null;
update t_conduite set cd_type = 'NC' where cd_avct= 'E';--cd_type nécessaire uniquement pour le GC à créer
update t_conduite set cd_nbcable=null;--vider la colonne cd_nbcable non demandée
update t_conduite set cd_long=cast(replace(cast(cd_long as varchar),',','.') as varchar);--formatage du champ longueur
--update t_conduite set cd_creadat = DATE('NOW'); --formatage de la date

/*zsro*/
--update t_zsro set zs_etatpm='EC'; --zs_etatpm passe à la valeur EC par défaut en APD

/*t_znro*/
update t_znro set zn_nroref =null;--vide la colonne nroref non demandée
update t_znro set zn_etat =null; --zn_etat = vide pour APD
update t_znro set zn_etatlpm = null;--MCD: pas demandé
update t_znro set zn_nrotype='PON';
update t_znro set zn_etat='EC';

/*t_baie*/
--les deux requetes qui suivent se retrouvent en DOE
update t_baie set ba_codeext= 'HT-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code)|| '-' || substr('0' || ba_etiquet,-2);--increment du lt_codeext avec le prefixe HT-ARM- et le suffixe de l'étiquette de la baie02
update t_baie set ba_etiquet = ba_codeext;--par défaut l'étiquette de la baie est le codeext de la baie
update t_baie set ba_statut = (select lt_statut from t_ltech where ba_lt_code = lt_code); --même staut que le local technique
update t_baie set ba_prop=(select st_prop from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code);--même propriétaire que le site technique
update t_baie set ba_gest=(select st_gest from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code); --même gestionnaire que le site technique

/*t_tiroir*/
delete from t_tiroir where ti_ba_code='' or ti_ba_code=null;--supprimer les tiroirs qui ne correspondent pas à une baie
update t_tiroir set ti_codeext= 'HT-TIR-' || (select substr(ba_codeext,8,8) from t_baie where ti_ba_code = ba_code)||'-'||substr('0' || ti_etiquet,-2);--tiroir prend l'increment de la baie + numéro du tiroir
update t_tiroir set ti_etiquet= ti_codeext;--etiquette du tiroir = codeext du tiroir en attente régles étiquettage 
update t_tiroir set ti_prop= (select ba_prop from t_baie where ti_ba_code = ba_code);--propriétaire du tiroir = propriétaire de la baie

/*t_cassette*/
--update t_cassette set cs_nb_pas=12;--A VERIFIER: 12 positions quelque soit la cassette
update t_cassette set cs_face=null; --vide la colonne cs_face non demandée
update t_cassette_patch201 set cs_ti_code=null where cs_ti_code not in (select ti_code from t_tiroir);--vide la colonne cs_ti_code pour les tiroirs qui n'en sont pas
update t_cassette set cs_bp_code=null where cs_code in (select cs_code from t_cassette_patch201 where cs_ti_code not null);--vider les bp_code des cassettes dans les NRO et SRO

/*t_cable*/
--update t_cable set cb_statut='PRO'; --en attente de la gestion des statuts en DE: PRO par défaut en APD
--update t_cable set cb_capafo = '2' where cb_capafo = '1';



/* champs a vider */

delete from t_ropt;

update t_adresse set ad_nblhab=null;
update t_adresse set ad_nbprpro=null;
update t_noeud set nd_voie=null;
update t_zsro set zs_actif=null;
update t_sitetech set st_avct=null;
update t_ebp set bp_ca_nb=null;


end transaction;

begin transaction;
/*t_ebp*/
delete from t_ebp where bp_typelog in ('NRO','SRO'); --retirer les points ebp des NRO/SRO
end transaction;	

