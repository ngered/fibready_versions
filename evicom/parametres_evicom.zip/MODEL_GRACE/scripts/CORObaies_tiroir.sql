PRAGMA foreign_keys = false;
delete from t_tiroir where ti_ba_code is null or ti_ba_code='';
delete from t_cassette_patch201 where cs_ti_code not in(select ti_code from t_tiroir);
PRAGMA foreign_keys =true;

