﻿update t_cable set cb_codeext=cb_etiquet;

update t_cable set cb_lgreel=
(select TRON_LNG_BPE from NOEUDS where cab_codext=cb_codeext);