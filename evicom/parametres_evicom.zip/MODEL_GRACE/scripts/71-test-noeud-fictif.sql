﻿begin transaction;

update t_noeud set nd_type ='SP' where nd_codeext = 'SP';
update t_noeud set nd_codeext= null where nd_codeext = 'SP';
delete from t_ptech where pt_codeext= 'SP';

end transaction;