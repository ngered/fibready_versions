﻿begin transaction;

/*E2000_DOE*/


/* maj enedis */

update t_ptech set pt_prop='OR000000000008' where pt_prop='OR91000000000004';

/*maj client*/

update t_ptech set pt_prop='OR000000000007' where pt_prop='OR91000000000002' or pt_prop='OR91000000000001';


/*maj indertemine*/

update t_ptech set pt_prop='OR000000000007' where pt_prop='OR91000000000006' ;




/*prop-gest*/
update t_sitetech set st_prop = 'OR000000000007';
update t_sitetech set st_gest = 'OR000000000007';
update t_baie set ba_prop = 'OR000000000007';
update t_baie set ba_gest = 'OR000000000007';
update t_tiroir set ti_prop = 'OR000000000007';
update t_ebp set bp_prop = 'OR000000000007';
update t_ebp set bp_gest = 'OR000000000007';
update t_cable set cb_prop= 'OR000000000007';
update t_cable set cb_gest= 'OR000000000007';
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR000000000007' end);
update t_ltech set lt_gest='OR000000000007' where lt_codeext='NRO-1' 
or  lt_codeext='NRO-2'
or lt_codeext='SRO-1-01HM'
or lt_codeext='SRO-1-02HM' 
or lt_codeext='SRO-1-03HM' 
or lt_codeext='SRO-1-04HM' 
or lt_codeext='SRO-1-05ME' 
or lt_codeext='SRO-1-06ME' 
or lt_codeext='SRO-1-07ME' 
or lt_codeext='SRO-1-08LG' 
or lt_codeext='SRO-1-09LG' 
or lt_codeext='SRO-1-10LG' 
or lt_codeext='SRO-1-11MM' 
or lt_codeext='SRO-1-12MM' 
or lt_codeext='SRO-1-13MM' 
or lt_codeext='SRO-1-14MM' 
or lt_codeext='SRO-1-15MM' 
or lt_codeext='SRO-1-16MM' 
or lt_codeext='SRO-1-17MM' 
or lt_codeext='SRO-1-18SA' 
or lt_codeext='SRO-1-19SA' 
or lt_codeext='SRO-1-20SA' 
or lt_codeext='SRO-1-21MM' 
or lt_codeext='SRO-1-22MM' 
or lt_codeext='SRO-2-01TI' 
or lt_codeext='SRO-2-02HG' 
or lt_codeext='SRO-2-03HG' 
or lt_codeext='SRO-2-04HG' 
or lt_codeext='SRO-2-05HG' 
and lt_gest='OR000000000021';
update t_ltech set lt_prop = lt_gest;
update t_ptech set pt_gest=pt_prop;


/*t_adresse*/
--update t_adresse set ad_ietat='CI';--ad_ietat par defaut valeur CIBLE en APD
update t_adresse set ad_typzone=3; --ad_typzone =3 par défaut APD/DOE
update t_adresse set ad_ietat='CI';
update t_adresse set ad_x_ban= st_x(geom),ad_y_ban= st_y(geom);
update t_adresse set ad_racc='7' where ad_racc is null or ad_racc='';
update t_adresse set ad_iaccgst=0 where  ad_idatsgn<> null ;


/*t_suf*/
update t_suf set sf_racco='RA';

/*t_ptech*/
update t_ptech set pt_statut = 'REC'; --en attente d'une gestion des statuts, PRO par défaut en APD 
update t_ptech set pt_rf_code = null; --champ à ne pas remplir (MCD)
update t_ptech set pt_etiquet = pt_codeext where pt_avct='C' ;
update t_ptech set pt_etat = 'OK';
update t_ptech set pt_etat = 'NC' where pt_avct='C' ;

update t_ptech set pt_prop = "OR000000000030" where pt_codeext in (select noe_codext from temp_INFRA_POINTS where INF_TYPE= "POT-EP");
update t_ptech set pt_gest=pt_prop;
update t_ptech set pt_datemes='22/01/2026' where pt_gest=OR000000000007 and pt_avct='C';
update t_ptech set pt_occp='1.1' where pt_codeext in (select noe_codext from temp_INFRA_POINTS where INF_TYPE= "CHB-AC");


/*t_ebp*/
--update t_ebp set bp_statut = 'PRO';--en attente d'une gestion des statuts en DE, PRO par défaut en APD


update t_ebp set bp_codeext = '' where bp_typelog = 'PTO';
update t_ebp set bp_etiquet = bp_codeext;
update t_ebp set bp_statut = 'REC';
update t_ebp set bp_rf_code = 'RF000000000015' where bp_typelog='BPE' and bp_lt_code is not null;
update t_ebp set bp_etat = 'OK';


/*t_cable*/
update t_cable set cb_codeext=null where cb_typelog = 'RA';
update t_cable set cb_etiquet=cb_codeext;
update t_cable set cb_statut='REC';
update t_cable set cb_r1_code = 'E2000';
update t_cable set  cb_r3_code = (select substr(zs_refpm,-11) from t_zsro) where cb_code not in(select st_nd_code from t_sitetech where st_typelog='NRO');
update t_cable set cb_r3_code='SRO-1-01HM' where cb_r2_code='NRO1' and cb_r3_code='01';
update t_cable set cb_r3_code='SRO-1-02HM' where cb_r2_code='NRO1' and cb_r3_code='02';
update t_cable set cb_r3_code='SRO-1-03HM' where cb_r2_code='NRO1' and cb_r3_code='03';
update t_cable set cb_r3_code='SRO-1-04HM' where cb_r2_code='NRO1' and cb_r3_code='04';
update t_cable set cb_r3_code='SRO-1-05ME' where cb_r2_code='NRO1' and cb_r3_code='05';
update t_cable set cb_r3_code='SRO-1-06ME' where cb_r2_code='NRO1' and cb_r3_code='06';
update t_cable set cb_r3_code='SRO-1-07ME' where cb_r2_code='NRO1' and cb_r3_code='07';
update t_cable set cb_r3_code='SRO-1-08LG' where cb_r2_code='NRO1' and cb_r3_code='08';
update t_cable set cb_r3_code='SRO-1-09LG' where cb_r2_code='NRO1' and cb_r3_code='09';
update t_cable set cb_r3_code='SRO-1-10LG' where cb_r2_code='NRO1' and cb_r3_code='10';
update t_cable set cb_r3_code='SRO-1-11MM' where cb_r2_code='NRO1' and cb_r3_code='11';
update t_cable set cb_r3_code='SRO-1-12MM' where cb_r2_code='NRO1' and cb_r3_code='12';
update t_cable set cb_r3_code='SRO-1-13MM' where cb_r2_code='NRO1' and cb_r3_code='13';
update t_cable set cb_r3_code='SRO-1-14MM' where cb_r2_code='NRO1' and cb_r3_code='14';
update t_cable set cb_r3_code='SRO-1-15MM' where cb_r2_code='NRO1' and cb_r3_code='15';
update t_cable set cb_r3_code='SRO-1-16MM' where cb_r2_code='NRO1' and cb_r3_code='16';
update t_cable set cb_r3_code='SRO-1-17MM' where cb_r2_code='NRO1' and cb_r3_code='17';
update t_cable set cb_r3_code='SRO-1-18SA' where cb_r2_code='NRO1' and cb_r3_code='18';
update t_cable set cb_r3_code='SRO-1-19SA' where cb_r2_code='NRO1' and cb_r3_code='19';
update t_cable set cb_r3_code='SRO-1-20SA' where cb_r2_code='NRO1' and cb_r3_code='20';
update t_cable set cb_r3_code='SRO-1-21MM' where cb_r2_code='NRO1' and cb_r3_code='21';
update t_cable set cb_r3_code='SRO-1-22MM' where cb_r2_code='NRO1' and cb_r3_code='22';
update t_cable set cb_r3_code='SRO-2-01TI' where cb_r2_code='NRO2' and cb_r3_code='01';
update t_cable set cb_r3_code='SRO-2-02HG' where cb_r2_code='NRO2' and cb_r3_code='02';
update t_cable set cb_r3_code='SRO-2-03HG' where cb_r2_code='NRO2' and cb_r3_code='03';
update t_cable set cb_r3_code='SRO-2-04HG' where cb_r2_code='NRO2' and cb_r3_code='04';
update t_cable set cb_r3_code='SRO-2-05HG' where cb_r2_code='NRO2' and cb_r3_code='05';
update t_cable set cb_proptyp='CST';
update t_cable set cb_etat='OK';
update t_cable set cb_datemes=cb_creadat;
--update t_cable set cb_lgreel= ( SELECT _champ__ from _table__ where _champ_num_troncon__=cb_codeext); attente longueur tronçon majoré dans FR





/*t_sitetech*/
update t_sitetech set st_statut='REC';--statut normalement dans DE, en attendant: PRO par défaut pour l'APD
--update t_sitetech set st_typephy='' where st_typephy = 'BAT';
update t_sitetech set st_prop='OR000000000021' where st_typephy= 'BAT';
update t_sitetech set st_gest='OR000000000021' where st_typephy= 'BAT';


/*t_ltech*/
--update t_ltech set lt_codeext=(select replace(st_codeext,'HT-TEC','HT-LT') || '-0'|| (select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code);--compte le nombre de Ltech sur le sitetech
--update t_ltech set lt_etiquet=lt_codeext;--lt_etiquet=lt_codeext en attente régle étiquettage
update t_ltech set lt_statut=(select st_statut from t_sitetech where lt_st_code=st_code);--satut du ltech = statut du sitetech correspondant
update t_ltech set lt_etat='NC'; --lt_etat= NC par défaut, rien n'est encore posé
update t_ltech set lt_prop= (select st_prop from t_sitetech where lt_st_code=st_code);--même propriétaire que sitetech
update t_ltech set lt_gest= (select st_gest from t_sitetech where lt_st_code=st_code);--même gestionnaire que sitetech
update t_ltech set lt_etiquet = lt_codeext;
update t_ltech set lt_etat = 'OK';
update t_ltech set lt_proptyp = 'OCC';



/*t_noeud*/

update t_noeud set nd_r1_code='E2000';
update t_noeud set nd_type_ep='OPT';
update t_noeud set  nd_r3_code = (select substr(zs_refpm,-4) from t_zsro) where nd_code not in(select st_nd_code from t_sitetech where st_typelog='NRO');
update t_noeud set nd_r3_code='SRO-1-01HM' where nd_r2_code='NRO1' and nd_r3_code='01HM';
update t_noeud set nd_r3_code='SRO-1-02HM' where nd_r2_code='NRO1' and nd_r3_code='02HM';
update t_noeud set nd_r3_code='SRO-1-03HM' where nd_r2_code='NRO1' and nd_r3_code='03HM';
update t_noeud set nd_r3_code='SRO-1-04HM' where nd_r2_code='NRO1' and nd_r3_code='04HM';
update t_noeud set nd_r3_code='SRO-1-05ME' where nd_r2_code='NRO1' and nd_r3_code='05ME';
update t_noeud set nd_r3_code='SRO-1-06ME' where nd_r2_code='NRO1' and nd_r3_code='06ME';
update t_noeud set nd_r3_code='SRO-1-07ME' where nd_r2_code='NRO1' and nd_r3_code='07ME';
update t_noeud set nd_r3_code='SRO-1-08LG' where nd_r2_code='NRO1' and nd_r3_code='08LG';
update t_noeud set nd_r3_code='SRO-1-09LG' where nd_r2_code='NRO1' and nd_r3_code='09LG';
update t_noeud set nd_r3_code='SRO-1-10LG' where nd_r2_code='NRO1' and nd_r3_code='10LG';
update t_noeud set nd_r3_code='SRO-1-11MM' where nd_r2_code='NRO1' and nd_r3_code='11MM';
update t_noeud set nd_r3_code='SRO-1-12MM' where nd_r2_code='NRO1' and nd_r3_code='12MM';
update t_noeud set nd_r3_code='SRO-1-13MM' where nd_r2_code='NRO1' and nd_r3_code='13MM';
update t_noeud set nd_r3_code='SRO-1-14MM' where nd_r2_code='NRO1' and nd_r3_code='14MM';
update t_noeud set nd_r3_code='SRO-1-15MM' where nd_r2_code='NRO1' and nd_r3_code='15MM';
update t_noeud set nd_r3_code='SRO-1-16MM' where nd_r2_code='NRO1' and nd_r3_code='16MM';
update t_noeud set nd_r3_code='SRO-1-17MM' where nd_r2_code='NRO1' and nd_r3_code='17MM';
update t_noeud set nd_r3_code='SRO-1-18SA' where nd_r2_code='NRO1' and nd_r3_code='18SA';
update t_noeud set nd_r3_code='SRO-1-19SA' where nd_r2_code='NRO1' and nd_r3_code='19SA';
update t_noeud set nd_r3_code='SRO-1-20SA' where nd_r2_code='NRO1' and nd_r3_code='20SA';
update t_noeud set nd_r3_code='SRO-1-21MM' where nd_r2_code='NRO1' and nd_r3_code='21MM';
update t_noeud set nd_r3_code='SRO-1-22MM' where nd_r2_code='NRO1' and nd_r3_code='22MM';
update t_noeud set nd_r3_code='SRO-2-01TI' where nd_r2_code='NRO2' and nd_r3_code='01TI';
update t_noeud set nd_r3_code='SRO-2-02HG' where nd_r2_code='NRO2' and nd_r3_code='02HG';
update t_noeud set nd_r3_code='SRO-2-03HG' where nd_r2_code='NRO2' and nd_r3_code='03HG';
update t_noeud set nd_r3_code='SRO-2-04HG' where nd_r2_code='NRO2' and nd_r3_code='04HG';
update t_noeud set nd_r3_code='SRO-2-05HG' where nd_r2_code='NRO2' and nd_r3_code='05HG';

update t_noeud set nd_r3_code=NULL where nd_r3_code='00';

update t_noeud set nd_coderat=nd_r3_code;
update t_noeud set nd_coderat=nd_r2_code where nd_coderat is null or nd_coderat='';
UPDATE t_noeud SET nd_coderat = (     SELECT nd_code     FROM t_noeud t2     WHERE t2.nd_codeext = t_noeud.nd_coderat);
update t_noeud set nd_dtclass='A' where pt_codeext in (select noe_codext from temp_INFRA_POINTS where INF_TYPE= "CHB-AC");
update t_noeud set nd_geolmod='LVIS' where nd_dtclass='A';
update t_noeud set nd_geolqlt='0,3' where nd_dtclass='A';



/*t_cheminement*/
--update t_cheminement set cm_statut='PRO';--doit etre issus de DE; en attendant PRO par défaut en APD
update t_cheminement set cm_nature='TEL';
update t_cheminement set cm_cddispo='2' where cm_avct='C';
update t_cheminement set cm_statut='REC';
update t_cheminement set cm_gest_do='OR000000000007' where cm_avct='C';
update t_cheminement set cm_prop_do='OR000000000007' where cm_avct='C';
update t_cheminement set cm_fildtec='1' where cm_avct='C' and cm_typ_imp='7';
update t_cheminement set cm_dtclass='A' where cm_fildtec='1';
update t_cheminement set cm_geolqlt='0,3' where cm_fildtec='1';
update t_cheminement set cm_geolmod='INDT';
update t_cheminement set cm_geolmod='LVIS' where cm_fildtec='1';


/*t_cond_chem*/
--update t_cond_chem set dm_creadat = DATE('NOW') ; --formatage de la date

/*t_conduite*/
update t_conduite set cd_r4_code=null;--MCD: à ne pas remplir
update t_conduite set cd_avct=(select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même avancement que le cheminement la comportant
update t_conduite set cd_statut=(select cm_statut from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même statut que le cheminement
update t_conduite set cd_prop = 'OR000000000007' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='C';--proriétaire=Evicom pour tout ce qui est à construire
update t_conduite set cd_prop = 'OR000000000007' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=7 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=0);--Evicom pour les conduites de type 7 existantes ou pour l'aérien ORANGE
update t_conduite set cd_prop = 'OR000000000008' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=1;--ENEDIS pour l'aérien ERDF
update t_conduite set cd_prop = 'OR000000000021' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--PRIVE pour les facades et le cheminement immeuble	
	--update t_conduite set cd_gest=null;

update t_conduite set cd_type = 'NC' where cd_avct= 'E';--cd_type nécessaire uniquement pour le GC à créer

update t_conduite set cd_nbcable=null;--vider la colonne cd_nbcable non demandée
/*update t_conduite set cd_long=cast(replace(cast(cd_long as varchar),',','.') as varchar);*/--formatage du champ longueur
--update t_conduite set cd_creadat = DATE('NOW'); --formatage de la date
update t_conduite set cd_statut='REC';
update t_conduite set cd_type = 'PVC';
update t_conduite set cd_type = 'PEHD' where cd_long < 18;
update t_conduite set cd_type = 'NC' where cd_avct= 'E';--cd_type nécessaire uniquement pour le GC à crée
update t_conduite set cd_long = REPLACE(cd_long, ',','.');
update t_conduite set cd_user = 'OR000000000007';
update t_conduite set cd_etat = 'OK';
update t_conduite set cd_dia_int = '33' where cd_type = 'PEHD';
update t_conduite set cd_dia_int = '42' where cd_type = 'PVC';
update t_conduite set cd_dia_ext = '33' where cd_type = 'PEHD';
update t_conduite set cd_dia_ext = '45' where cd_type = 'PVC';


/*zsro*/
--update t_zsro set zs_etatpm='EC'; --zs_etatpm passe à la valeur EC par défaut en APD
update t_zsro set zs_ad_code =(SELECT st_ad_code FROM t_sitetech where st_nd_code = zs_nd_code); 
update t_zsro set zs_r1_code ='E2000';
update t_zsro set zs_r3_code = (select substr(zs_refpm,-11) from t_zsro) where zs_code not in(select st_nd_code from t_sitetech where st_typelog='NRO');
update t_zsro set zs_r3_code='SRO-1-01HM' where zs_r2_code='NRO1' and zs_r3_code='01';
update t_zsro set zs_r3_code='SRO-1-02HM' where zs_r2_code='NRO1' and zs_r3_code='02';
update t_zsro set zs_r3_code='SRO-1-03HM' where zs_r2_code='NRO1' and zs_r3_code='03';
update t_zsro set zs_r3_code='SRO-1-04HM' where zs_r2_code='NRO1' and zs_r3_code='04';
update t_zsro set zs_r3_code='SRO-1-05ME' where zs_r2_code='NRO1' and zs_r3_code='05';
update t_zsro set zs_r3_code='SRO-1-06ME' where zs_r2_code='NRO1' and zs_r3_code='06';
update t_zsro set zs_r3_code='SRO-1-07ME' where zs_r2_code='NRO1' and zs_r3_code='07';
update t_zsro set zs_r3_code='SRO-1-08LG' where zs_r2_code='NRO1' and zs_r3_code='08';
update t_zsro set zs_r3_code='SRO-1-09LG' where zs_r2_code='NRO1' and zs_r3_code='09';
update t_zsro set zs_r3_code='SRO-1-10LG' where zs_r2_code='NRO1' and zs_r3_code='10';
update t_zsro set zs_r3_code='SRO-1-11MM' where zs_r2_code='NRO1' and zs_r3_code='11';
update t_zsro set zs_r3_code='SRO-1-12MM' where zs_r2_code='NRO1' and zs_r3_code='12';
update t_zsro set zs_r3_code='SRO-1-13MM' where zs_r2_code='NRO1' and zs_r3_code='13';
update t_zsro set zs_r3_code='SRO-1-14MM' where zs_r2_code='NRO1' and zs_r3_code='14';
update t_zsro set zs_r3_code='SRO-1-15MM' where zs_r2_code='NRO1' and zs_r3_code='15';
update t_zsro set zs_r3_code='SRO-1-16MM' where zs_r2_code='NRO1' and zs_r3_code='16';
update t_zsro set zs_r3_code='SRO-1-17MM' where zs_r2_code='NRO1' and zs_r3_code='17';
update t_zsro set zs_r3_code='SRO-1-18SA' where zs_r2_code='NRO1' and zs_r3_code='18';
update t_zsro set zs_r3_code='SRO-1-19SA' where zs_r2_code='NRO1' and zs_r3_code='19';
update t_zsro set zs_r3_code='SRO-1-20SA' where zs_r2_code='NRO1' and zs_r3_code='20';
update t_zsro set zs_r3_code='SRO-1-21MM' where zs_r2_code='NRO1' and zs_r3_code='21';
update t_zsro set zs_r3_code='SRO-1-22MM' where zs_r2_code='NRO1' and zs_r3_code='22';
update t_zsro set zs_r3_code='SRO-2-01TI' where zs_r2_code='NRO2' and zs_r3_code='01';
update t_zsro set zs_r3_code='SRO-2-02HG' where zs_r2_code='NRO2' and zs_r3_code='02';
update t_zsro set zs_r3_code='SRO-2-03HG' where zs_r2_code='NRO2' and zs_r3_code='03';
update t_zsro set zs_r3_code='SRO-2-04HG' where zs_r2_code='NRO2' and zs_r3_code='04';
update t_zsro set zs_r3_code='SRO-2-05HG' where zs_r2_code='NRO2' and zs_r3_code='05';
update t_zsro set zs_etatpm ='EC';
update t_zsro set zs_typeing ='mono';


/*t_znro*/
update t_znro set zn_nroref =null;--vide la colonne nroref non demandée

update t_znro set zn_etatlpm = null;--MCD: pas demandé
update t_znro set zn_nrotype='PTP';
update t_znro set zn_etat='EC';
update t_znro set zn_r1_code='E2000';


/*t_zpbo*/

update t_zpbo set zp_r1_code='E2000';
update t_zpbo set zp_r3_code = (select substr(zs_refpm,-11) from t_zsro) where zp_code not in(select st_nd_code from t_sitetech where st_typelog='NRO');
update t_zpbo set zp_r3_code='SRO-1-01HM' where zp_r2_code='NRO1' and zp_r3_code='01';
update t_zpbo set zp_r3_code='SRO-1-02HM' where zp_r2_code='NRO1' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SRO-1-03HM' where zp_r2_code='NRO1' and zp_r3_code='03';
update t_zpbo set zp_r3_code='SRO-1-04HM' where zp_r2_code='NRO1' and zp_r3_code='04';
update t_zpbo set zp_r3_code='SRO-1-05ME' where zp_r2_code='NRO1' and zp_r3_code='05';
update t_zpbo set zp_r3_code='SRO-1-06ME' where zp_r2_code='NRO1' and zp_r3_code='06';
update t_zpbo set zp_r3_code='SRO-1-07ME' where zp_r2_code='NRO1' and zp_r3_code='07';
update t_zpbo set zp_r3_code='SRO-1-08LG' where zp_r2_code='NRO1' and zp_r3_code='08';
update t_zpbo set zp_r3_code='SRO-1-09LG' where zp_r2_code='NRO1' and zp_r3_code='09';
update t_zpbo set zp_r3_code='SRO-1-10LG' where zp_r2_code='NRO1' and zp_r3_code='10';
update t_zpbo set zp_r3_code='SRO-1-11MM' where zp_r2_code='NRO1' and zp_r3_code='11';
update t_zpbo set zp_r3_code='SRO-1-12MM' where zp_r2_code='NRO1' and zp_r3_code='12';
update t_zpbo set zp_r3_code='SRO-1-13MM' where zp_r2_code='NRO1' and zp_r3_code='13';
update t_zpbo set zp_r3_code='SRO-1-14MM' where zp_r2_code='NRO1' and zp_r3_code='14';
update t_zpbo set zp_r3_code='SRO-1-15MM' where zp_r2_code='NRO1' and zp_r3_code='15';
update t_zpbo set zp_r3_code='SRO-1-16MM' where zp_r2_code='NRO1' and zp_r3_code='16';
update t_zpbo set zp_r3_code='SRO-1-17MM' where zp_r2_code='NRO1' and zp_r3_code='17';
update t_zpbo set zp_r3_code='SRO-1-18SA' where zp_r2_code='NRO1' and zp_r3_code='18';
update t_zpbo set zp_r3_code='SRO-1-19SA' where zp_r2_code='NRO1' and zp_r3_code='19';
update t_zpbo set zp_r3_code='SRO-1-20SA' where zp_r2_code='NRO1' and zp_r3_code='20';
update t_zpbo set zp_r3_code='SRO-1-21MM' where zp_r2_code='NRO1' and zp_r3_code='21';
update t_zpbo set zp_r3_code='SRO-1-22MM' where zp_r2_code='NRO1' and zp_r3_code='22';
update t_zpbo set zp_r3_code='SRO-2-01TI' where zp_r2_code='NRO2' and zp_r3_code='01';
update t_zpbo set zp_r3_code='SRO-2-02HG' where zp_r2_code='NRO2' and zp_r3_code='02';
update t_zpbo set zp_r3_code='SRO-2-03HG' where zp_r2_code='NRO2' and zp_r3_code='03';
update t_zpbo set zp_r3_code='SRO-2-04HG' where zp_r2_code='NRO2' and zp_r3_code='04';
update t_zpbo set zp_r3_code='SRO-2-05HG' where zp_r2_code='NRO2' and zp_r3_code='05';


/*t_sitetech*/
update t_sitetech set st_nom=st_codeext;
update t_sitetech set st_proptyp='OCC';


/*t_baie*/
--les deux requetes qui suivent se retrouvent en DOE
update t_baie set ba_codeext= 'SRO-1-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code)|| '-' || substr('0' || ba_etiquet,-2);--increment du lt_codeext avec le prefixe HT-ARM- et le suffixe de l'étiquette de la baie02
update t_baie set ba_etiquet = ba_codeext;--par défaut l'étiquette de la baie est le codeext de la baie
update t_baie set ba_statut = (select lt_statut from t_ltech where ba_lt_code = lt_code); --même staut que le local technique
update t_baie set ba_prop=(select st_prop from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code);--même propriétaire que le site technique
update t_baie set ba_gest=(select st_gest from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code); --même gestionnaire que le site technique

update t_baie set ba_user=ba_gest;
update t_baie set ba_proptyp='CST';
update t_baie set ba_etat='OK';
update t_baie set ba_nb_u='28';
update t_baie set ba_type='BAIE';
update t_baie set ba_rf_code='RF000000000002';
update t_baie set ba_haut=null;
update t_baie set ba_larg=null;
update t_baie set ba_prof=null;


/*t_tiroir*/
delete from t_tiroir where ti_ba_code='' or ti_ba_code=null;--supprimer les tiroirs qui ne correspondent pas à une baie
update t_tiroir set ti_codeext= 'SRO-1-' || (select substr(ba_codeext,8,8) from t_baie where ti_ba_code = ba_code)||'-'||substr('0' || ti_etiquet,-2);--tiroir prend l'increment de la baie + numéro du tiroir
update t_tiroir set ti_etiquet= ti_codeext;--etiquette du tiroir = codeext du tiroir en attente régles étiquettage 
update t_tiroir set ti_prop= (select ba_prop from t_baie where ti_ba_code = ba_code);--propriétaire du tiroir = propriétaire de la baie
update t_tiroir set ti_etat= 'OK';
update t_tiroir set ti_type= 'TIROIR';
update t_tiroir set ti_taille= '3';

/*t_cassette*/
--update t_cassette set cs_nb_pas=12;--A VERIFIER: 12 positions quelque soit la cassette
update t_cassette set cs_face=null; --vide la colonne cs_face non demandée
update t_cassette_patch201 set cs_ti_code=null where cs_ti_code not in (select ti_code from t_tiroir);--vide la colonne cs_ti_code pour les tiroirs qui n'en sont pas
update t_cassette set cs_bp_code=null where cs_code in (select cs_code from t_cassette_patch201 where cs_ti_code not null);--vider les bp_code des cassettes dans les NRO et SRO

/*t_cable*/
--update t_cable set cb_statut='PRO'; --en attente de la gestion des statuts en DE: PRO par défaut en APD
--update t_cable set cb_capafo = '2' where cb_capafo = '1';



/*t_fibre*/
update t_fibre set fo_type='G567';


/* champs a vider */






update t_noeud set nd_voie=null;
update t_zsro set zs_actif=null;
update t_sitetech set st_avct=null;
update t_ebp set bp_ca_nb=null;

/* sup D3 */
delete from t_cable_patch201 where cb_bp2 in (select BP_CODE from t_ebp where bp_typelog='PTO');
delete from t_ebp where bp_typelog='PTO'; 

delete from t_fibre where fo_cb_code in ( select cb_code from t_cable where cb_typelog='RA');
delete from t_cableline where cl_cb_code in ( select cb_code from t_cable where cb_typelog='RA');
delete from t_cable where cb_typelog='RA';

/*DOE*/
update t_cheminement set cm_avct='E' where cm_avct='C';
update t_conduite set cd_avct='E' where cd_avct='C';
update t_ptech set pt_avct='E' where pt_avct='C';
update t_sitetech set st_avct='E' where st_avct='C';
update t_cable set cb_avct='E' where cb_avct='C';
update t_ebp set bp_avct='E' where bp_avct='C';




/*delete from t_ebp where bp_typelog in ('NRO','SRO');*/ --retirer les points ebp des NRO/SRO

end transaction;


