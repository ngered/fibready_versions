﻿begin transaction;

/* maj orange*/
update t_cable set cb_prop='OR000000000001' where cb_prop='OR91000000000003';
update t_ebp set bp_prop='OR000000000001' where bp_prop='OR91000000000003';
update t_ptech set pt_prop='OR000000000001' where pt_prop='OR91000000000003';
update t_ltech set lt_prop='OR000000000001' where lt_prop='OR91000000000003';
update t_sitetech set st_prop='OR000000000001' where st_prop='OR91000000000003';

/* maj enedis */
update t_cable set cb_prop='OR000000000002' where cb_prop='OR91000000000004';
update t_ebp set bp_prop='OR000000000002' where bp_prop='OR91000000000004';
update t_ptech set pt_prop='OR000000000002' where pt_prop='OR91000000000004';
update t_ltech set lt_prop='OR000000000002' where lt_prop='OR91000000000004';
update t_sitetech set st_prop='OR000000000002' where st_prop='OR91000000000004';

/*maj client*/
update t_cable set cb_prop='OR710000000571' where cb_prop='OR91000000000002' or cb_prop='OR91000000000001';
update t_ebp set bp_prop='OR710000000571' where bp_prop='OR91000000000002' or bp_prop='OR91000000000001';
update t_ptech set pt_prop='OR710000000571' where pt_prop='OR91000000000002' or pt_prop='OR91000000000001';
update t_ltech set lt_prop='OR710000000571' where lt_prop='OR91000000000002' or lt_prop='OR91000000000001';
update t_sitetech set st_prop='OR710000000571' where st_prop='OR91000000000002' or st_prop='OR91000000000001';

/*maj indertemine*/
update t_cable set cb_prop='OR710000000571' where cb_prop='OR91000000000006' ;
update t_ebp set bp_prop='OR710000000571' where bp_prop='OR91000000000006' ;
update t_ptech set pt_prop='OR710000000571' where pt_prop='OR91000000000006' ;
update t_ltech set lt_prop='OR710000000571' where lt_prop='OR91000000000006' ;
update t_sitetech set st_prop='OR710000000571' where st_prop='OR91000000000006';


/* gest */
update t_ptech set pt_gest=pt_prop;
update t_cable set cb_gest=cb_prop;


/* etiquettes */

update t_ptech set pt_etiquet = pt_codeext;

update t_ebp set bp_etiquet = bp_codeext;

update t_cable set cb_etiquet = cb_codeext;



/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_ban_id=null;
update t_adresse set ad_y_ban=null;
update t_adresse set ad_x_ban=null;
update t_adresse set ad_prio = '0';
update t_adresse set ad_ietat = 'CI';
update t_adresse set ad_typzone = null;
update t_adresse set ad_geolsrc = null;
update t_adresse set ad_racc = '7' where ad_racc = '' ;
update t_adresse set ad_iaccgst = null ;
update t_adresse set ad_itypeim  = 'P' where ad_itypeim  = '' ;
update t_adresse set ad_distinf=(select st_length(t_cableline.geom) from t_cableline 
                                                                                   join t_cable on (t_cable.cb_code= t_cableline.cl_cb_code)
                                                                                   join t_cable_patch201 on (t_cable_patch201.cb_code = t_cable.cb_code)
                                                                                   join t_ebp on (t_ebp.bp_code = t_cable_patch201.cb_bp2)
                                                                                   join t_suf on (t_suf.sf_code = t_ebp.bp_sf_code)
                                                                                  where ad_code=sf_ad_code);
update t_adresse set ad_imneuf = 'N' where ad_imneuf is null ;



/*t_ebp*/
update t_ebp set bp_statut='EXE';
update t_ebp set bp_proptyp = null;
update t_ebp set bp_ca_nb = null;


/* DELETE FROM t_ebp 
WHERE rowid NOT IN (
    SELECT MAX(rowid) 
    FROM t_ebp
    GROUP BY bp_sf_code )
and bp_typelog='PTO'; */


/*t_ptech*/
update t_ptech set pt_statut='EXE';
update t_ptech set pt_a_haut = '8' where pt_typephy = 'A';
update t_ptech set pt_a_struc = 'Simple' where pt_a_haut = '8';
update t_ptech set pt_a_haut = null where pt_avct = 'E';
update t_ptech set pt_secu = '0';


/*t_ltech*/
update t_ltech set lt_statut='EXE';
update t_ltech set lt_prop ='OR710000000571';
update t_ltech set lt_gest ='OR710000000571';
update t_ltech set lt_proptyp =null;
update t_ltech set lt_elec= null;
update t_ltech set lt_clim = null;



/*t_sitetech*/
update t_sitetech set st_statut='EXE';
update t_sitetech set st_prop ='OR710000000571';
update t_sitetech set st_gest ='OR710000000571';
update t_sitetech set st_comment ='7035' where st_typelog= 'NRO' or st_typelog='SRO';


/*t_noeud */

update t_noeud set nd_type ='SP' where nd_codeext = 'SP';
update t_noeud set nd_codeext= null where nd_codeext = 'SP';
delete from t_ptech where pt_codeext= 'SP';
update t_noeud set nd_geolqlt=null;
update t_noeud set nd_codeext=null;
update t_noeud set nd_dtclass='C';
update t_noeud set nd_geolmod=null;
update t_noeud set nd_r1_code='CD71';
update t_noeud set nd_r3_code=nd_r2_code||'_'||nd_r3_code;


/*t_cableline*/
update t_cableline set cl_geolqlt=null;
delete from t_cableline where st_length (geom) = 0;
update t_cableline set cl_long = null;

/*t_cheminement*/
update t_cheminement set cm_r1_code = 'CD71';
update t_cheminement set cm_statut='EXE';


/* t_znro */
update t_znro set zn_nrotype = 'PON';
update t_znro set zn_r2_code = zn_nroref;

/*t_zsro*/
update t_zsro set zs_etatpm = 'EC';
update t_zsro set zs_typeing = 'mono';
update t_zsro set zs_r3_code = zs_refpm;
update t_zsro set zs_r1_code = 'CD71';


/* t_zpbo */

update t_zpbo set zp_capamax = null;


/*t_cable*/

update t_cable set cb_modulo=6 where cb_typelog='DI';
update t_cable set cb_modulo=12 where cb_typelog='TR' OR cb_typelog='CO';
update t_cable set cb_modulo=2 where cb_typelog='RA';
update t_cable set cb_proptyp = null;

update t_cable set cb_statut='EXE';
update t_cable set cb_etat=null;

update t_cable set cb_r3_code='' where cb_typelog='TR';
update t_cable set cb_r3_code='' where cb_typelog='CO';
update t_cable set cb_r3_code=cb_r2_code||'_'||cb_r3_code;

update t_cable set cb_capafo='2' where cb_capafo='1';

update t_cable set cb_lgreel =(select st_length(geom) from t_cableline where cl_cb_code=cb_code);
update t_cable set cb_lgreel = '0' where cb_lgreel is null;

update t_cable set cb_r1_code='CD71';
update t_cable set cb_fo_disp= null;
update t_cable set cb_fo_util= null;

update t_cable set cb_lgreel= round (cb_lgreel);



/*t_conduite*/
update t_conduite set cd_statut = 'EXE';
update t_conduite set cd_r1_code = null ;
update t_conduite set cd_r2_code = null ;
update t_conduite set cd_r3_code = null ;
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR710000000571' 
end);
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR710000000571' 
end);
update t_conduite set cd_gest = null where cd_avct='E';


update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_comment='CD71') then 'OR710000000571' 
end);


update t_conduite set cd_type = 'NC' where cd_avct='E';
update t_conduite set cd_type='PEHD' where cd_type= 'PVC';
update t_conduite set cd_dia_int= '32' where cd_type= 'PEHD';
update t_conduite set cd_dia_ext= '40' where cd_type= 'PEHD';


update t_conduite set cd_r1_code=null;
update t_conduite set cd_proptyp=null;
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;

/* t_baie */

update t_baie set ba_prop='OR710000000571';
update t_baie set ba_gest='OR710000000571';
update t_baie set ba_proptyp='CST';
update t_baie set ba_type='BAIE';
update t_baie set ba_codeext =(select lt_etiquet from  t_ltech where ba_lt_code= lt_code) || ba_etiquet;
update t_baie set ba_codeext='Droite';
update t_baie set ba_nb_u=null;
update t_baie set ba_haut=null;
update t_baie set ba_larg=null;
update t_baie set ba_prof=null;

/* t_tiroir */
update t_tiroir set ti_prop='OR710000000571';
update t_tiroir set ti_type='TIROIR';
update t_tiroir set ti_placemt = ti_etiquet;
update t_tiroir set ti_etiquet=( select ba_etiquet from t_baie where ti_ba_code=ba_code) ||'_'|| ti_etiquet;
update t_tiroir set ti_codeext=ti_etiquet;
update t_tiroir set ti_taille = '3';
update t_tiroir set ti_rf_code = 'RF000000000194';

/* t_fibre */
update t_fibre set fo_proptyp='CST';

update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='DI');
update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='RA');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='TR');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='CO');
update t_fibre set fo_reper = null;


/* t_position */
update t_position set ps_preaff = (case 
when ps_comment = 'ABONNE' then  'ABONNE'
end);
update t_position set ps_cs_code = NULL where ps_fonct = 'CO';

delete from t_position where ps_fonct='';

/* t_suf */
update t_suf set sf_racco = 'RA';


/* t_cassette */
delete from t_cassette_patch201 where cs_ti_code is null;
update t_cassette set cs_bp_code= null where cs_code in ( select cs_code from t_cassette_patch201);
delete from t_cassette_patch201;
delete from t_cassette where cs_bp_code is null;

update t_cassette set cs_face= 'A';
update t_cassette set cs_rf_code= 'RF000000000191';
update t_cassette set cs_nb_pas= null;

/* sup SRO et NRO dans t_ebp 
delete from t_cable_patch201;*/
delete from t_ebp where bp_typelog='SRO';
delete from t_ebp where bp_typelog='NRO';

/*delete from t_cable_patch201 where cb_bp1 not in (select bp_code from t_ebp) and cb_bp2 not in (select bp_code from t_ebp);
update t_cable_patch201 set cb_bp1 = NULL where cb_bp1 not in (select bp_code from t_ebp);
update t_cable_patch201 set cb_bp2 = NULL where cb_bp2 not in (select bp_code from t_ebp); */



/* t_love*/

delete from t_love where lv_long = '0';


/* no PTO */
delete from t_cable_patch201 where cb_bp2 in (select BP_CODE from t_ebp where bp_typelog='PTO');
delete from t_ebp where bp_typelog='PTO'; 

/* champs a vider */


delete from t_ropt;

update t_adresse set ad_nblhab=null;
update t_adresse set ad_nblpro=null;
update t_adresse set ad_x_ban=null;
update t_adresse set ad_y_ban=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_isole=null;
update t_adresse set ad_prio=null;
update t_adresse set ad_comment=null;
update t_adresse set ad_geolqlt=null;
update t_baie set ba_prop=null;
update t_baie set ba_gest=null;
update t_baie set ba_proptyp=null;
update t_cable set cb_tech=null;
update t_cableline set cl_geolqlt=null;
update t_cassette set cs_face=null;
update t_cheminement set cm_compo=null;
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_mod_pos=null;
update t_cheminement set cm_passage=null;
update t_cheminement set cm_revet=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_fildtec=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;
update t_cheminement set cm_gest_do = NULL;
update t_cheminement set cm_prop_do = null;
update t_cheminement set cm_etat=null;
update t_ebp set bp_prop=null;
update t_fibre set fo_code_ext=null;
update t_fibre set fo_etat=null;
update t_fibre set fo_etat=null;
update t_fibre set fo_proptyp=null;
update t_ltech set lt_prop=null;
update t_ltech set lt_gest=null;
update t_noeud set nd_geolqlt=null;
update t_position set ps_type=null;
update t_ptech set pt_proptyp=null;
update t_sitetech set st_codeext=null;
update t_sitetech set st_etat=null;
update t_sitetech set st_nom=null;
update t_tiroir set ti_taille=null;
update t_tiroir set ti_placemt=null;
update t_znro set zn_nrotype=null;


/*SUP cable RACCO*/
delete from t_fibre where fo_cb_code in ( select cb_code from t_cable where cb_typelog='RA');
delete from t_cableline where cl_cb_code in ( select cb_code from t_cable where cb_typelog='RA');
delete from t_cable where cb_typelog='RA';



/* Maj l_tech_patch_201 pour sro et nro */
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in (select lt_code from t_ltech_patch201);

/* SUP sro et nro de t_adresse */

update t_sitetech set st_ad_code=null where st_typephy='SHE';
update t_sitetech set st_ad_code=null where st_typephy='ADR';
delete from t_adresse where ad_batcode <> '';


/* collecte mutualis dans distri transport 

update t_cheminement set cm_typelog='CT' where cm_typelog='CO';
update t_cheminement set cm_typelog='CX' where cm_typelog='CD';
update t_cable set cb_typelog='CT' where cb_typelog='CO'; */

end transaction;