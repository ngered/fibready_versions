﻿begin transaction;
/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);

/*t_ebp*/
update t_ebp set bp_statut='AVD';

/*t_ptech*/
update t_ptech set pt_statut='AVD';

/*t_ltech*/
update t_ltech set lt_statut='AVD';

/*t_sitetech*/
update t_sitetech set st_statut='AVD';

/*t_noeud */
update t_noeud set nd_geolqlt=null;


/*t_cableline*/
update t_cableline set cl_geolqlt=null;

/*t_cheminement*/
update t_cheminement set cm_statut='APD';
update t_cheminement set cm_compo='';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;
update t_cheminement set cm_statut='APD';

/*t_zpbo*/
update t_zpbo set zp_r3_code=zp_r2_code || '_0' || substr(zp_code,6,2);
/*update t_zpbo set zp_capamax=null;*/

/*t_zsro*/
/*update t_zsro set zs_capamax=null;*/
update t_zsro set zs_nblogmt=null;

/*t_znro*/
update t_znro set zn_r3_code=zn_r2_code || '_0' || substr(zn_code,6,2);

/*t_cable*/
update t_cable set cb_r3_code=cb_r2_code || '_0' || substr(cb_code,6,2);
update t_cable set cb_statut='AVD';
end transaction;


