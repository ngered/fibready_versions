﻿begin transaction;
	/*sitetech*/
    --update t_sitetech set st_codeext='ES-TEC-' || (select nd_r3_code from t_noeud where nd_code = st_nd_code) where st_typelog='SRO' or st_typelog='NRO';
	--fat
	--update t_sitetech set st_codeext='ES-TEC-' || (select substr( nd_r3_code , 1, 3) || substr( nd_r3_code , -2) from t_noeud  where nd_code = st_nd_code) where st_typelog='SRO' or st_typelog='NRO';
	--fat
	--update t_sitetech set st_codeext=(select replace(ad_batcode,'ES-BAT' ,'ES-TEC') from t_adresse where ad_code = st_ad_code) WHERE st_typelog='CLIENT' ;
	update t_sitetech set st_codeext = 'ES-TEC-'|| (case 
when st_typelog = 'NRO' then (select nd_r2_code from t_noeud)
when st_typelog = 'SRO' then (select nd_r2_code from t_noeud) || st_nom
when st_typelog = 'CLIENT' then (select substr (ad_batcode,8,5 ) from t_adresse where st_ad_code = ad_code)
end);--david

	
	/*t_ltech*/
	update t_ltech set lt_codeext='';
	--fat
	update t_ltech set lt_codeext=(select replace(st_codeext,'ES-TEC','ES-LT') || '-0'|| (select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code);--david ajout '-0'
	
	/*t_baie*/
	update t_baie set ba_codeext='';
	--update t_baie set ba_codeext= (select replace(lt_codeext,'ES-LT','ES-ARM') || '-' || (select count(*)+1 from t_baie where ba_lt_code=lt_code and ba_codeext<>'') from t_ltech where lt_code = ba_lt_code);
	update t_baie set ba_codeext= (case 
	--when (select st_typelog from t_sitetech where st_typelog ='NRO')= 'NRO' then 'ES-ARM-XXXXX-XX' ajout pour NRO
	when (select st_typelog from t_sitetech where st_typelog ='SRO')= 'SRO' then (select replace (replace(lt_codeext,'ES-LT','ES-ARM'), '01','02' ) from t_ltech where lt_code = ba_lt_code)
	end); --david
	
	/*t_tiroir*/
	update t_tiroir set ti_codeext='';
	update t_tiroir set ti_codeext=(select replace(ba_codeext,'ES-ARM','ES-TI') || '-' || (select count(*)+1 from t_tiroir where ti_ba_code=ba_code and ba_codeext<>'') from t_baie where ba_code =ti_ba_code);
	
	/*t_ebp*/
	update t_ebp set bp_codeext='';
	--update t_ebp set bp_codeext=(select replace(pt_codeext,'ES-PT','ES-BPE') ||'-' || (select count(*)+1 from t_ebp where bp_pt_code=pt_code and bp_codeext<>'') from t_ptech where pt_code =bp_pt_code);
	update t_ebp set bp_codeext=(case 
when bp_pt_code is not '' then (select replace(pt_codeext,'ES-PT','ES-BPE') ||'-0' || (select count(*)+1 from t_ebp where bp_pt_code=pt_code and bp_codeext<>'') from t_ptech where pt_code =bp_pt_code)
when bp_lt_code is not '' then (select 'ES-BPI-'||substr( lt_codeext,7) from t_ltech where lt_code = bp_lt_code) --fonctionne exclusivemment parce que SRO et NRO sont supprimés
end);
end transaction;

