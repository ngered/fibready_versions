﻿begin transaction;
/*statut pro 
update t_cable set cb_statut='AVP' where cb_statut<>'DIA';
update t_ebp set bp_statut='AVP' where bp_statut<>'DIA';
update t_ptech set pt_statut='AVP' where pt_statut<>'DIA';
update t_ltech set lt_statut='AVP' where lt_statut<>'DIA';
update t_sitetech set st_statut='AVP' where st_statut<>'DIA';
update t_cheminement set cm_statut='AVP' where cm_statut<>'DIA';
update t_conduite set cd_statut='AVP' where cd_statut<>'DIA';*/

/*Organisme */
update t_ebp set bp_prop='OR91000000000001';
update t_ebp set bp_gest='OR91000000000002';
update t_cable set cb_prop='OR91000000000001';
update t_cable set cb_gest='OR91000000000002';
update t_cable set cb_gest='OR91000000000002';
update t_sitetech set st_prop='OR91000000000001' where st_typelog='SRO' or  st_typelog='NRO' ;
update t_sitetech set st_prop='OR91000000000006' where st_prop='' or st_prop is null;

/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);
--fat
update t_adresse set ad_batcode = ad_ban_id;


/*t_noeud */
update t_noeud set nd_r1_code='ES91';
update t_noeud set nd_r2_code='MER' where substr(nd_code,8,4)='8181';
update t_noeud set nd_r2_code='FBC' where substr(nd_code,8,4)='5454';
update t_noeud set nd_r2_code='DOU' where substr(nd_code,8,4)='4545';
update t_noeud set nd_r3_code=nd_r2_code || '_0' || substr(nd_code,6,2);
update t_noeud set nd_geolqlt=null;


/*t_cableline*/
update t_cableline set cl_geolqlt=null;

/*t_cheminement*/
update t_cheminement set cm_r1_code='ES91';
update t_cheminement set cm_r2_code='MER' where substr(cm_code,8,4)='8181';
update t_cheminement set cm_r2_code='FBC' where substr(cm_code,8,4)='5454';
update t_cheminement set cm_r2_code='DOU' where substr(cm_code,8,4)='4545';
update t_cheminement set cm_r3_code=cm_r2_code || '_0' || substr(cm_code,6,2);
update t_cheminement set cm_compo='';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;


/*t_zpbo*/
update t_zpbo set zp_r1_code='ES91';
update t_zpbo set zp_r2_code='MER' where substr(zp_code,8,4)='8181';
update t_zpbo set zp_r2_code='FBC' where substr(zp_code,8,4)='5454';
update t_zpbo set zp_r2_code='DOU' where substr(zp_code,8,4)='4545';
update t_zpbo set zp_r3_code=zp_r2_code || '_0' || substr(zp_code,6,2);
update t_zpbo set zp_capamax= 2 where zp_capamax= 1;

/*t_zsro*/
update t_zsro set zs_r1_code='ES91';
update t_zsro set zs_r2_code='MER' where substr(zs_code,8,4)='8181';
update t_zsro set zs_r2_code='FBC' where substr(zs_code,8,4)='5454';
update t_zsro set zs_r2_code='DOU' where substr(zs_code,8,4)='4545';
update t_zsro set zs_r3_code=zs_r2_code || '_0' || substr(zs_code,6,2);
/*update t_zsro set zs_capamax=null;*/
update t_zsro set zs_refpm='ES'||'-TEC-'||zs_r2_code||substr(zs_code,6,2);
update t_zsro set zs_nblogmt=null;
update t_zsro set zs_nbcolmt=null;

/*t_znro*/
update t_znro set zn_r1_code='ES91';
update t_znro set zn_r2_code='MER' where substr(zn_code,8,4)='8181';
update t_znro set zn_r2_code='FBC' where substr(zn_code,8,4)='5454';
update t_znro set zn_r2_code='DOU' where substr(zn_code,8,4)='4545';
/*update t_znro set zn_r3_code=zn_r2_code || '_0' || substr(zn_code,6,2);*/
update t_znro set  zn_nroref ='ES-TEC-'||zn_r2_code||substr(zn_code,6,2);

/*t_cable*/
update t_cable set cb_modulo=6 where (cb_typelog='DI' or cb_typelog='TR') and cb_capafo<96;
update t_cable set cb_modulo=12 where (cb_typelog='DI' or cb_typelog='TR') and cb_capafo>=96;
update t_cable set cb_modulo=2, cb_capafo=2,cb_fo_disp=2 where (cb_typelog='RA');

update t_cable set cb_r1_code='ES91';
update t_cable set cb_r2_code='MER' where substr(cb_code,8,4)='8181';
update t_cable set cb_r2_code='FBC' where substr(cb_code,8,4)='5454';
update t_cable set cb_r2_code='DOU' where substr(cb_code,8,4)='4545';
update t_cable set cb_r3_code=cb_r2_code || '_0' || substr(cb_code,6,2);

/*t_ebp*/
update t_ebp set bp_comment = '' where bp_typelog in ('SRO', 'NRO');

/*R4_Code*/
update t_znro set zn_r4_code=replace(upper(zn_r4_code),'jalon_','LOT');
update t_zsro set zs_r4_code=replace (upper(zs_r4_code),'jalon_','LOT');
update t_cable set cb_r4_code =replace(upper(cb_r4_code),'jalon_','LOT');

end transaction;