﻿begin transaction;

/*t_adresse */
update t_adresse set ad_hexaclv=null;
update t_adresse set ad_batcode=null where ad_nblhab=0 and ad_nblpro=0;

/*t_noeud */
update t_noeud set nd_codeext=null;

/*t_cableline*/

/*t_cheminement*/

/*t_cond_chem*/

/*t_zpbo*/

/*t_zsro*/

/*t_znro*/

/*t_cable*/
update t_cable set cb_codeext=null where cb_typelog='RA';																						

/*t_ebp*/
update t_ebp set bp_comment = null;

/*t_sitetech*/
update t_sitetech set st_codeext = 'ES-TEC-'|| (case 
	when st_typelog = 'NRO' then (select nd_r2_code from t_noeud)
	when st_typelog = 'SRO' then (select nd_r2_code from t_noeud) || st_nom
	when st_typelog = 'CLIENT' then substr(st_codeext,8,5) 
	end);
update t_sitetech set st_nom = substr(st_codeext,8,3) || '_0' || st_nom where st_typelog='SRO';

/*t_ltech*/
--update t_ltech set lt_codeext=(select replace(st_codeext,'ES-TEC','ES-LT') || '-0'|| (select count(*) from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code );
update t_ltech set lt_codeext=(select replace(st_codeext,'ES-TEC','ES-LT') || '-0'|| (select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext IS NULL) from t_sitetech where st_code = lt_st_code );

/*t_baie*/
update t_baie set ba_codeext= (select substr(replace(lt_codeext,'ES-LT-','ES-ARM-'),1,12) || '-' || substr( '00' || ba_etiquet,-2) from t_ltech where lt_code = ba_lt_code) where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='SRO');
update t_baie set ba_codeext= (select substr(replace(lt_codeext,'ES-LT-','ES-ARM-'),1,10) || '-' || substr( '00' || ba_etiquet,-2) from t_ltech where lt_code = ba_lt_code) where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='NRO');
update t_baie set ba_etiquet = 'B02' where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='SRO');
update t_baie set ba_etiquet = ba_codeext where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='NRO');

/*t_tiroir*/
update t_tiroir set ti_codeext='ES-TI-'||(select substr(ba_codeext,8,4) from t_baie where ba_code =ti_ba_code and ba_code like 'BA91000%')||substr(('00'||ti_etiquet),-2) where ti_code like 'TI91000%';
update t_tiroir set ti_codeext='ES-TI-'||(select substr(ba_codeext,8,6) from t_baie where ba_code =ti_ba_code and ba_code not like 'BA91000%')||substr(('00'||ti_etiquet),-2) where ti_code not like 'TI91000%'; 
update t_tiroir set ti_etiquet=ti_codeext;

/*t_conduite*/

/*t_ptech*/
 
/*t_cable_patch201*/

/*t_suf*/
update t_suf set sf_comment=null;

end transaction;



