begin transaction;

/*t_adresse */
update t_adresse set ad_hexaclv=null;

/*t_noeud */
update t_noeud set nd_codeext=null;

/*t_cableline*/

/*t_cheminement*/
update t_cheminement set cm_codeext=null;

/*t_cond_chem*/

/*t_zpbo*/

/*t_zsro*/

/*t_znro*/

/*t_cable*/
update t_cable set cb_codeext=null where cb_typelog='RA';																						

/*t_ebp*/
update t_ebp set bp_comment = null;

/*t_sitetech*/
update t_sitetech set st_codeext = 'ES-TEC-'|| (case 
	--when st_typelog = 'NRO' then (select nd_r2_code from t_noeud)
	--when st_typelog = 'SRO' then (select nd_r2_code from t_noeud) || st_nom
	when st_typelog = 'CLIENT' then 'ES-TEC-' || substr(st_codeext,8,5) 
	end);

/*t_ltech*/
update t_ltech set lt_codeext=(select replace(st_codeext,'ES-TEC','ES-LT') || '-0'|| (select count(*) from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code );
update t_ltech set lt_codeext=(select replace(st_codeext,'ES-TEC','ES-LT') || '-0'|| (select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext IS NULL) from t_sitetech where st_code = lt_st_code );

/*t_baie*/
update t_baie set ba_codeext= (select substr(replace(lt_codeext,'ES-LT-','ES-ARM-'),1,12) || '-' || substr( '00' || ba_etiquet,-2) from t_ltech where lt_code = ba_lt_code) where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='SRO');
update t_baie set ba_codeext= (select substr(replace(lt_codeext,'ES-LT-','ES-ARM-'),1,10) || '-' || substr( '00' || ba_etiquet,-2) from t_ltech where lt_code = ba_lt_code) where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='NRO');
update t_baie set ba_etiquet = 'B02' where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='SRO');
update t_baie set ba_etiquet = ba_codeext where ba_lt_code in (select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='NRO');



/*t_conduite*/
update t_conduite set cd_r3_code=null;
update t_conduite set cd_proptyp=null;

/*t_ptech*/
 
/*t_cable_patch201*/

/*t_suf*/
update t_suf set sf_comment=null;

/*vider les tables non demandées*/
delete from t_cassette;
delete from t_cassette_patch201;
delete from t_ropt;
delete from t_tiroir;
delete from t_love;
delete from t_fibre;
delete from t_position;

end transaction;



