--delete from t_cable_patch201 where cb_bp2 in (select BP_CODE from t_ebp where bp_typelog='PTO');
update t_cable_patch201 set cb_bp2=null where cb_bp2 in (select bp_code from t_ebp where bp_typelog='PTO');
delete from t_ebp where bp_typelog='PTO';
