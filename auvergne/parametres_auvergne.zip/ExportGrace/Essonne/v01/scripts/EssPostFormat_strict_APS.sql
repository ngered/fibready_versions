begin transaction;

/*t_adresse */
update t_adresse set ad_hexaclv=null;
update t_adresse set ad_racc=null;
update t_adresse set ad_hexacle=null;
update t_adresse set ad_batcode=null;
update t_adresse set ad_imneuf=null;
update t_adresse set ad_iaccgst=null;
update t_adresse set ad_ietat=null;

/*t_noeud */
update t_noeud set nd_codeext=null;

/*t_cableline*/
update t_cableline set cl_long =   st_length (t_cableline.geom) ; --(select st_length (t_cableline.geom) from t_cable where cb_typelog = 'RA' and cl_cb_code = cb_code);

/*t_cheminement*/
update t_cheminement set cm_codeext=null;
update t_cheminement set cm_r4_code=null;
update t_cheminement set cm_prop_do=null;

/*t_cond_chem*/

/*t_zpbo*/
update t_zpbo set zp_r4_code=null;
update t_zpbo set zp_capamax=null;

/*t_zsro*/
update t_zsro set zs_typeemp=null;

/*t_znro*/

/*t_cable*/
update t_cable set cb_codeext=null;	
update t_cable set cb_gest=null;
update t_cable set cb_rf_code=null;
update t_cable set cb_fo_disp=null;
update t_cable set cb_fo_util=null;																									

/*t_ebp*/
update t_ebp set bp_comment = null;
update t_ebp set bp_codeext = null;
update t_ebp set bp_gest = null;
update t_ebp set bp_rf_code = null;

/*t_sitetech*/
update t_sitetech set st_codeext = null;
update t_sitetech set st_ad_code=null;

/*t_ltech*/
update t_ltech set lt_codeext=null;



/*t_conduite*/
update t_conduite set cd_r3_code=null;
update t_conduite set cd_proptyp=null;

/*t_ptech*/
update t_ptech set pt_codeext=null;
update t_ptech set pt_ad_code=null;
update t_ptech set pt_gest=null;
update t_ptech set pt_proptyp=null;
update t_ptech set pt_nature=null;
--update t_ptech set pt_typelog = 'R' where pt_code = (select bp_pt_code from t_ebp where bp_pt_code=pt_code);

/*t_cable_patch201*/

/*t_suf*/
update t_suf set sf_comment=null;
update t_suf set sf_zp_code=null;

delete from t_ltech_patch201;
delete from t_zpbo_patch201;
delete from t_cable_patch201;

end transaction;



