begin transaction;

/*t_adresse */
update t_adresse set ad_isole=null where ad_nblhab=0 and ad_nblpro=0;
update t_adresse set ad_imneuf=null where ad_nblhab+ad_nblpro <4;
update t_adresse set ad_ietat = 'DE' where ad_ietat='REC';
update t_adresse set ad_ietat = 'CI' where ad_ietat in('AVP','PRO');
/*t_cableline*/

/*t_cheminement*/
update t_cheminement set cm_dtclass = 'A' where cm_avct='C' and cm_statut='REC';
update t_cheminement set cm_nature = (case
								when cm_typ_imp = '1' then 'ELE'
								else 'TEL'
								end);
update t_cheminement set cm_datemes = DATE('NOW') where cm_statut='REC'; --date au format '2018-05-12' --pour un format 2018-05-12 hh:mm:ss écrire datetime('now') - strftime( "%Y%m%d" , DATE(NOW))
update t_cheminement set cm_fildtec=1 where cm_avct='C' and cm_typ_imp=7 and cm_statut='REC';

/*t_cond_chem*/

/*t_znro*/
update t_znro set zn_etat = 'EC'; --jusqu'à DOE JALON4

/*t_cable*/
update t_cable set cb_proptyp='CST';
update t_cable set cb_datemes= DATE('NOW') where cb_statut='REC';
update t_cable set cb_avct='E' where cb_statut='REC';

/*t_cable_patch*/

/*t_ebp*/
update t_ebp set bp_comment = null;
update t_ebp set bp_etiquet = SUBSTR(bp_codeext,8,5);
update t_ebp set bp_datemes = DATE('NOW') where bp_statut='REC';
update t_ebp set bp_ca_nb = ( case
								when bp_rf_code in ('RF91000000000113','RF91000000000115','RF91000000000120') then 4
								when bp_rf_code in ('RF91000000000114','RF91000000000116','RF91000000000121','RF91000000000124') then 12
								when bp_rf_code = 'RF91000000000117' then 24
								when bp_rf_code = 'RF91000000000118' then 48
								when bp_rf_code = 'RF91000000000119' then 60
								end);

/*t_sitetech*/

update t_sitetech set st_proptyp= (case 
									when st_typelog in ('NRO','SRO') then 'CST'
									else 'OCC'
									end) ;
--update t_sitetech set st_datemes = DATE('NOW') where st_statut='REC';
update t_sitetech set st_dateins = DATE('NOW') where st_statut='REC';

/*t_conduite*/
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR91000000000001' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR91000000000003'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR91000000000004'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR91000000000006'
end);
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then null 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR91000000000003'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR91000000000004'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR91000000000006'
end);
update t_conduite set cd_type='PEHD' where cd_code in (select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct = 'C' and cm_typ_imp=7 ) and cd_statut='REC';
update t_conduite set cd_type='NC' where cd_code in (select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct = 'E' or (cm_avct='C' and cm_typ_imp<>7)) or cd_statut <>'REC';
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;
update t_conduite set cd_datemes=(select cm_datemes from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);
update t_conduite set cd_comment = (select cm_comment from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);


/*t_ptech*/
update t_ptech set pt_detec='0' where pt_statut='REC'; 
update t_ptech set pt_datemes = DATE('NOW') where pt_statut='REC';
update t_ptech set pt_gest_do='A REMPLIR' where pt_avct='C' and pt_statut ='REC';
 
/*t_ltech*/
update t_ltech set lt_proptyp =(select st_proptyp from t_sitetech where lt_st_code = st_code); 
update t_ltech set lt_statut=(select st_statut from t_sitetech where lt_st_code=st_code);
update t_ltech set lt_etat='OK' where lt_statut='REC';
 
/*t_noeud*/
update t_noeud set nd_dtclass='A' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C');
 
/*t_baie*/ 
update t_baie set ba_statut='REC' where ba_lt_code in (select lt_code from t_ltech where lt_statut='REC');
update t_baie set ba_gest='OR91000000000002' where ba_statut='REC';
update t_baie set ba_prop='OR91000000000001' where ba_statut='REC';
update t_baie set ba_proptyp='CST' where ba_statut='REC';
update t_baie set ba_type ='BAIE' where ba_statut='REC';

update t_baie set  ba_rf_code = (select case 
when zs_capamax = 800 then  'RF91000000000004'
when zs_capamax = 600 then  'RF91000000000003'
end
from t_zsro 
join t_sitetech on  zs_nd_code= st_nd_code
join t_ltech on st_code = lt_st_code
join t_baie on  ba_lt_code = lt_code);
update t_baie set ba_rf_code='RF91000000000001' where ba_lt_code in (select lt_code from t_ltech, t_sitetech where st_code=lt_st_code and st_typelog='NRO') and ba_statut='REC';
update t_baie set ba_rf_code=null where ba_statut<>'REC';

update t_baie set ba_nb_u = (case
									when ba_rf_code ='RF91000000000003'  then 28
									when ba_rf_code='RF91000000000004' then 40
									when ba_rf_code='RF91000000000001' then 42
									when ba_rf_code='RF91000000000002' then 42
								end) where ba_statut='REC';


/*t_cassette*/
update t_cassette set cs_face=null;
update t_cassette set cs_rf_code='RF91000000000128' where cs_type='C';
update t_cassette set cs_rf_code = 'RF91000000000125' where cs_type='E' and cs_bp_code in (select bp_code from t_ebp where bp_typephy in ('B012','B024' ,'B036','B048','B072','B096','B144')) ; --petits câbles
update t_cassette set cs_rf_code = 'RF91000000000129' where cs_type='E' and cs_bp_code in (select bp_code from t_ebp where bp_typephy in ('B288','B432' ,'B576','B720')); --gros cables
update t_cassette set cs_bp_code=null where cs_bp_code not in (select bp_code from t_ebp);
update t_cassette set cs_nb_pas=null;

/*t_tiroir*/


update t_tiroir set ti_prop = 'OR91000000000001';
update t_tiroir set ti_taille=4;
update t_tiroir set ti_type='TIROIR';

 /* t_fibre */
update t_fibre set fo_nincab = null;
update t_fibre set fo_type = null;
update t_fibre set fo_color = null;
update t_fibre set fo_reper = null;

/*completer t_ltechpatch201*/
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in ( select lt_code from t_ltech_patch201 );

/*formatage creadat*/
update t_fibre set fo_creadat=datetime(fo_creadat);
update t_cassette set cs_creadat=datetime(cs_creadat);
update t_tiroir set ti_creadat=datetime(ti_creadat);
update t_position set ps_creadat=datetime(ps_creadat);
update t_ropt set rt_creadat=datetime(rt_creadat);
update t_love set lv_creadat=datetime(lv_creadat);
update t_cab_cond set cc_creadat=datetime(cc_creadat);
update t_organisme set or_creadat=datetime(or_creadat);
update t_reference set rf_creadat=datetime(rf_creadat);
update t_conduite set cd_creadat=datetime(cd_creadat);
update t_cond_chem set dm_creadat=datetime(dm_creadat);
update t_baie set ba_creadat=datetime(ba_creadat);

end transaction;
 



begin transaction;

update t_conduite set cd_avct = 'E' where cd_statut = 'REC';
update t_cheminement set cm_avct = 'E' where cm_statut = 'REC';
update t_ebp set bp_avct = 'E' where bp_statut='REC';
update t_ptech set pt_avct = 'E' where pt_statut='REC';
update t_sitetech set st_avct='E' where st_statut='REC';

end transaction;