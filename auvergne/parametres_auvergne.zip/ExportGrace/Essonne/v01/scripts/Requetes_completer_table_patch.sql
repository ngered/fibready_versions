
Compléter t_ltech_patch201:

insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in ( select lt_code from t_ltech_patch201 );

Compléter t_cassette_patch201:

insert into t_cassette_patch201 (cs_code) select cs_code from t_cassette where cs_code not in (select cs_code from t_cassette_patch201);

Compléter t_zpbo_patch201 avec les codes pbo manquants:

insert into t_zpbo_patch201 (zp_code) select zp_code from t_zpbo where zp_code not in (select zp_code from t_zpbo_patch201);

Compléter t_cable_patch201 avec les codes cables manquants:

insert into t_cable_patch201 (cb_code) select cb_code from t_cable where cb_code not in (select cb_code from t_cable_patch201);