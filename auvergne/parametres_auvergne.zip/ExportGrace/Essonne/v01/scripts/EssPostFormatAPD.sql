﻿begin transaction;

/*t_adresse */
update t_adresse set ad_imneuf=null where ad_nblhab+ad_nblpro <4;

/*t_noeud */

/*t_cableline*/

/*t_cheminement*/
update t_cheminement set cm_r4_code = null;

/*t_cond_chem*/
--update t_cond_chem set dm_creadat = ( select cm_creadat from t_cheminement where dm_cm_code = cm_code) ;--david
update t_cond_chem set dm_creadat=datetime(dm_creadat);

/*t_zpbo*/
update t_zpbo set zp_r4_code=null;

/*t_zsro*/

/*t_znro*/

/*t_cable*/
update t_cable set cb_etiquet=cb_capafo || 'FO-' || cb_codeext where cb_typelog <>'RA';
update t_cable set cb_comment='HORS_ZA' where exists (select distinct cm_comment from t_cheminement 
																						inner join t_cond_chem on cm_code = dm_cm_code
																						inner join t_cab_cond on cc_cd_code = dm_cd_code
																						where cc_cb_code=cb_code and cm_comment='HORS_ZA');

/*t_ebp*/
update t_ebp set bp_etiquet = substr(bp_codeext,8,5);

/*t_ltech*/

--update t_ltech set lt_statut = 'PRO'; --ATTENTION; en attente de faire mieux


/*t_sitetech*/
update t_sitetech set st_gest = 'OR91000000000002' where st_typelog in ('NRO','SRO');

update t_ltech set lt_statut = (select bp_statut from t_ebp where bp_lt_code = lt_code) where lt_st_code IN (SELECT st_code FROM t_sitetech where st_gest <> 'OR91000000000002');

update t_sitetech set st_statut = (select lt_statut from t_ltech where lt_st_code = st_code );

/*t_conduite*/
update t_conduite set cd_prop = (case 
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR91000000000001' 
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR91000000000003'
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR91000000000004'
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR91000000000006'
end);
update t_conduite set cd_gest = (case 
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then null 
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR91000000000003'
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR91000000000004'
	when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR91000000000006'
end);
update t_conduite set cd_statut = (select cm_statut from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;
update t_conduite set cd_r4_code=null;
update t_conduite set cd_creadat=datetime(cd_creadat);

/*t_ptech*/
update t_ptech set pt_etiquet = pt_codeext where pt_avct = 'C' and pt_typephy = 'A';
update t_ptech set pt_rf_code= (case
	when pt_nature='L2T' then 'RF91000000000131'
	when pt_nature='L3T' then 'RF91000000000132'
	when pt_nature='L4T' then 'RF91000000000133'
	when pt_nature='L5T' then 'RF91000000000134'
	when pt_nature='K1C' then 'RF91000000000135'
	when pt_nature='K2C' then 'RF91000000000136'
	when pt_nature='PMET' then 'RF91000000000137'
	when pt_nature='PIND' then 'RF91000000000139'
end) where pt_avct='C';
 /*à faire: pour les poteaux à créer (comment on les appelle? quelle hauteur?)Dans DOU J1 tous les appuis à créer sont IND, je mets poteaux composite 8M par défaut*/
 update t_ptech set pt_rf_code='RF91000000000139' where (pt_avct='C' and pt_typephy='A' and pt_nature='IND');
 update t_ptech set pt_gest='OR91000000000002' where (pt_avct='C' and pt_typephy='C' and pt_statut != 'AVP');--maj 14012020
 
 /*t_baie*/ 
 update t_baie set ba_statut = (select lt_statut from t_ltech where ba_lt_code = lt_code);

/*t_love*/
delete from t_love where lv_long=0;


/*t_ebp*/
delete from t_ebp where bp_typelog in ('NRO','SRO');

update t_cassette set cs_bp_code=null where cs_bp_code not in (select bp_code from t_ebp);

/*t_cable_patch201*/
update t_cable_patch201 set cb_bp1=null where cb_bp1 not in (select bp_code from t_ebp);
update t_cable_patch201 set cb_bp2=null where cb_bp2 not in (select bp_code from t_ebp);

/*completer t_ltechpatch201*/
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in ( select lt_code from t_ltech_patch201 );

update t_fibre set fo_creadat=datetime(fo_creadat);
update t_cassette set cs_creadat=datetime(cs_creadat);
update t_tiroir set ti_creadat=datetime(ti_creadat);
update t_position set ps_creadat=datetime(ps_creadat);
update t_ropt set rt_creadat=datetime(rt_creadat);
update t_love set lv_creadat=datetime(lv_creadat);
update t_cab_cond set cc_creadat=datetime(cc_creadat);
update t_organisme set or_creadat=datetime(or_creadat);
update t_reference set rf_creadat=datetime(rf_creadat);
update t_baie set ba_creadat=datetime(ba_creadat);

end transaction;

