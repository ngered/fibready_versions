--le dernier code Grace et le numero du tiroir de surcapa pour chaque baie
create view derTi as select max(ti_code) as der_cod_gra,ti_codeext,substr(ti_codeext,16,2) as ti_max, ti_ba_code, ba_nb_u , ba_codeext,
	case when ba_nb_u=28 then '07' when ba_nb_u=40 then '10' when ba_nb_u=42 then '06' end as ti_surcapa,
	case when substr(ti_codeext,16,2)= (case when ba_nb_u=28 then '07' when ba_nb_u=40 then '10' when ba_nb_u=42 then '06' end) then 'ok' else 'nok' end as presence_tiroir 
	from t_tiroir 
	join t_baie on ti_ba_code=ba_code
	group by ti_ba_code;
--si le tiroir de surcapa est déjà présent ou non + statut de la baie
create view presenceTiroir as select ti_ba_code, derTi.ba_nb_u,
		case when ti_surcapa in (select substr(ti_codeext,16,2) from t_tiroir where t_tiroir.ti_ba_code=derTi.ti_ba_code) then 'ok' 
		else 'nok' end as presence_tiroir,
		case when derTi.ba_nb_u is null then 'nonREC' else 'REC' end as statut 
		from derTi 
		join t_baie on ti_ba_code=ba_code;
--insertion du tiroir supplémentaire
insert into t_tiroir(ti_code, ti_codeext, ti_etiquet, ti_ba_code, ti_rf_code, ti_creadat,ti_prop, ti_type, ti_taille)
	select (substr(der_cod_gra,1,7) || (substr(der_cod_gra,8,9) + 1)) , (substr(ti_codeext,1,15)|| ti_surcapa) , 'ajout' , derTi.ti_ba_code, 'RF91000000000005', datetime(date()),'OR91000000000001','TIROIR',4
	from derTi
	join presenceTiroir on derTi.ti_ba_code=presenceTiroir.ti_ba_code
	where presenceTiroir.presence_tiroir = 'nok' and presenceTiroir.statut='REC';
--suppression des deux vues
drop view derTi;
drop view presenceTiroir;




