﻿begin transaction;
update t_zsro set zs_nblogmt =(select count(sf_code) from t_suf,t_zpbo where sf_zp_code=zp_code and zp_zs_code=zs_code);
end transaction;

begin transaction;
/*statut pro */
--Pour les statuts, FibReady doit récupérer les DE
update t_cable set cb_statut=(case	
								when cb_r4_code = 'LOT1' then 'REC'
								when cb_r4_code='LOT2' then 'PRO'
								when cb_r4_code = 'LOT3' then 'AVP'
							end); --fonctionne uniquement pour jalon 1 en DOE,jalon 2 en APD,jalon 3 en APS, sinon à adapter
update t_ebp set bp_statut='REC' where bp_statut<>'DIA';
update t_ptech set pt_statut='REC' where pt_statut<>'DIA';
update t_ltech set lt_statut='REC' where lt_statut<>'DIA';
update t_sitetech set st_statut='REC' where st_statut<>'DIA';
--update t_cheminement set cm_statut='REC' where cm_statut<>'DIA';
update t_conduite set cd_statut=(case	
									when cd_r4_code = 'LOT1' then 'REC'
									when cd_r4_code='LOT2' then 'PRO'
									when cd_r4_code = 'LOT3' then 'AVP'
								end); --fonctionne uniquement pour jalon 1 en DOE,jalon 2 en APD,jalon 3 en APS, sinon à adapter

update t_cheminement set cm_statut=(case	
										when cm_r4_code = 'LOT1' then 'REC'
										when cm_r4_code='LOT2' then 'PRO'
										when cm_r4_code = 'LOT3' then 'AVP'
									end); --fonctionne uniquement pour jalon 1 en DOE,jalon 2 en APD,jalon 3 en APS, sinon à adapter



/*statut avp */
--update t_cable set cb_statut='AVP' where cb_statut='DIA';
--update t_ebp set bp_statut='AVP' where bp_statut='DIA';
--update t_ptech set pt_statut='AVP' where pt_statut='DIA';
--update t_ltech set lt_statut='AVP' where lt_statut='DIA';
--update t_sitetech set st_statut='AVP' where st_statut='DIA';
--update t_cheminement set cm_statut='AVP' where cm_statut='DIA';
--update t_conduite set cd_statut='AVP' where cd_statut='DIA';


/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);
update t_adresse set ad_nbprhab=null;
update t_adresse set ad_nbprpro=null;
--fat
update t_adresse set ad_ban_id = null ;
--aude
update t_adresse set ad_numero=null where ad_numero=0;

update t_adresse set ad_itypeim =null;



/*t_noeud */
update t_noeud set nd_geolqlt=null;
--update t_noeud set nd_r4_code = 'LOT1'; /*attention valable suelement pr J1 */
--fat : à remettre pour les autres jalons (nb : en mettant en commentaire la précédente ligne)  
update t_noeud set nd_r4_code = (case 
								WHEN nd_r3_code in ('DOU_001','DOU_003','DOU_004','DOU_005','DOU_006','DOU_007','DOU_010','DOU_012','DOU_013','DOU_018','DOU_021','DOU_023','DOU_024','DOU_026','DOU_027',
                                    'FBC_004','FBC_014','FBC_016','FBC_021','FBC_029','FBC_030','FBC_031','FBC_032','FBC_033','MER_006','MER_010','MER_018','DOU_000','FBC_000','MER_000','CHA_000')  THEN 'LOT1'
								WHEN nd_r3_code in ('DOU_009','DOU_017','DOU_020','DOU_022','FBC_001','FBC_002','FBC_005','FBC_007','FBC_011','FBC_013','FBC_015','FBC_019','FBC_020','FBC_024','FBC_027',
								    'CHA_001','CHA_002','CHA_004','CHA_005','MER_015','MER_017') THEN 'LOT2'
								WHEN nd_r3_code in ('DOU_002','DOU_008','DOU_014','DOU_016','DOU_019','FBC_003','FBC_008','FBC_009','FBC_010','FBC_017','FBC_023','FBC_025','FBC_028','MER_003','MER_009',
                                    'MER_011','MER_012','CHA_003','CHA_007','CHA_008') THEN 'LOT3'
								WHEN nd_r3_code in ('DOU_011','DOU_015','DOU_025','FBC_006','FBC_012','FBC_018','FBC_022','FBC_026','MER_001','MER_002','MER_004','MER_005','MER_007','MER_013','MER_014',
                                   'MER_016','CHA_006') THEN 'LOT4'
							   end) ;
/*t_cableline*/
update t_cableline set cl_geolqlt=null;

/*t_cheminement*/
update t_cheminement set cm_compo='';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;
--aude
update t_cheminement set cm_dtclass = 'A' where (cm_avct='C' and (cm_typ_imp = '7' or cm_typ_imp='0'));
update t_cheminement set cm_nature = (case
								when cm_typ_imp = '1' then 'ELE'
								else 'TEL'
								end);
update t_cheminement set cm_datemes = strftime( "%Y%m%d", DATE('NOW')) where cm_statut='REC'; --date au format '2018-05-12' --pour un format 2018-05-12 hh:mm:ss écrire datetime('now')
--fateh
update t_cheminement set cm_r4_code =  (case 
								WHEN cm_r3_code in ('DOU_001','DOU_003','DOU_004','DOU_005','DOU_006','DOU_007','DOU_010','DOU_012','DOU_013','DOU_018','DOU_021','DOU_023','DOU_024','DOU_026','DOU_027',
                                    'FBC_004','FBC_014','FBC_016','FBC_021','FBC_029','FBC_030','FBC_031','FBC_032','FBC_033','MER_006','MER_010','MER_018','DOU_000','FBC_000','MER_000','CHA_000')  THEN 'LOT1'
								WHEN cm_r3_code in ('DOU_009','DOU_017','DOU_020','DOU_022','FBC_001','FBC_002','FBC_005','FBC_007','FBC_011','FBC_013','FBC_015','FBC_019','FBC_020','FBC_024','FBC_027',
								    'CHA_001','CHA_002','CHA_004','CHA_005','MER_015','MER_017') THEN 'LOT2'
								WHEN cm_r3_code in ('DOU_002','DOU_008','DOU_014','DOU_016','DOU_019','FBC_003','FBC_008','FBC_009','FBC_010','FBC_017','FBC_023','FBC_025','FBC_028','MER_003','MER_009',
                                    'MER_011','MER_012','CHA_003','CHA_007','CHA_008') THEN 'LOT3'
								WHEN cm_r3_code in ('DOU_011','DOU_015','DOU_025','FBC_006','FBC_012','FBC_018','FBC_022','FBC_026','MER_001','MER_002','MER_004','MER_005','MER_007','MER_013','MER_014',
                                    'MER_016','CHA_006') THEN 'LOT4'
							  end) ;



/*t_cond_chem*/

update t_cond_chem set dm_creadat = ( select cm_creadat from t_cheminement where dm_cm_code = cm_code) ;--david

end transaction;

/*t_zpbo*/
/*begin transaction;
update t_zpbo set zp_capamax= 12 where zp_capamax > 5 and zp_capamax <=10;
end transaction;
begin transaction;
update t_zpbo set zp_capamax= 6 where zp_capamax > 2 and zp_capamax <=5;
end transaction;
begin transaction;
update t_zpbo set zp_capamax= 3 where zp_capamax <= 2 ;
end transaction;
*/							

/*t_zsro*/
/*update t_zsro set zs_capamax=null;
update t_zsro set zs_nblogmt=null;
update t_zsro set zs_nbcolmt=null;*/
--update t_zsro set zs_r4_code=upper(replace(lower(zs_r4_code),'jalon_','LOT'));--david

begin transaction;
/*t_znro*/
update t_znro set zn_r3_code = null;
update t_znro set zn_r4_code = upper(zn_r4_code);
--aude: fonctionne seulement pour DOE Jalon 1:
update t_znro set zn_etat = (case
								when zn_r4_code = 'LOT1'then 'EC'
								else 'PL'
								end);

/*t_cable*/

update t_cable set cb_rf_code = 'RF91000000000070'where cb_typelog = 'TR' and cb_capafo = '72'; --bardav

--update t_cable set cb_r4_code = 'LOT1'; --david requete temporaire pour livraison du 05/10
update t_cable set cb_r4_code =  (case 
								WHEN cb_r3_code in ('DOU_001','DOU_003','DOU_004','DOU_005','DOU_006','DOU_007','DOU_010','DOU_012','DOU_013','DOU_018','DOU_021','DOU_023','DOU_024','DOU_026','DOU_027',
                                    'FBC_004','FBC_014','FBC_016','FBC_021','FBC_029','FBC_030','FBC_031','FBC_032','FBC_033','MER_006','MER_010','MER_018','DOU_000','FBC_000','MER_000','CHA_000')  THEN 'LOT1'
								WHEN cb_r3_code in ('DOU_009','DOU_017','DOU_020','DOU_022','FBC_001','FBC_002','FBC_005','FBC_007','FBC_011','FBC_013','FBC_015','FBC_019','FBC_020','FBC_024','FBC_027',
								    'CHA_001','CHA_002','CHA_004','CHA_005','MER_015','MER_017') THEN 'LOT2'
								WHEN cb_r3_code in ('DOU_002','DOU_008','DOU_014','DOU_016','DOU_019','FBC_003','FBC_008','FBC_009','FBC_010','FBC_017','FBC_023','FBC_025','FBC_028','MER_003','MER_009',
                                    'MER_011','MER_012','CHA_003','CHA_007','CHA_008') THEN 'LOT3'
								WHEN cb_r3_code in ('DOU_011','DOU_015','DOU_025','FBC_006','FBC_012','FBC_018','FBC_022','FBC_026','MER_001','MER_002','MER_004','MER_005','MER_007','MER_013','MER_014',
                                    'MER_016','CHA_006') THEN 'LOT4'
							  end);
--aude
update t_cable set cb_etiquet=cb_capafo || 'FO-' || cb_codeext;
update t_cable set cb_fo_disp=null where cb_typelog='RA';
update t_cable set cb_fo_util=null where cb_typelog='RA';
update t_cable set cb_proptyp='CST'where cb_r4_code = 'LOT1'; -- marche uniquement pour DOE JALON 1 - à adapter ensuite pour les autres jalons
--on considère le câble HORS_ZA si au moins un cheminement qui le compose est HORS_ZA
update t_cable set cb_comment='HORS_ZA' where exists (select distinct cm_comment from t_cheminement 
																						inner join t_cond_chem on cm_code = dm_cm_code
																						inner join t_cab_cond on cc_cd_code = dm_cd_code
																						where cc_cb_code=cb_code and cm_comment='HORS_ZA');
--on considère le câble en REC si tous les cheminements qui le composent sont en REC, si au moins un cheminement est en AVP, le câble sera en AVP, dans tous les autres cas le câble sera donc en PRO
--quid des câbles de RAC?
update t_cable set cb_statut = (case
									when cb_typelog='RA' then 'REC'
									when (select count (distinct cm_statut) from t_cheminement 
															inner join t_cond_chem on cm_code = dm_cm_code
															inner join t_cab_cond on cc_cd_code = dm_cd_code
															where cc_cb_code=cb_code)=1 and 
															(select distinct cm_statut from t_cheminement 
																inner join t_cond_chem on cm_code = dm_cm_code
																inner join t_cab_cond on cc_cd_code = dm_cd_code
																where cc_cb_code=cb_code)='REC' then 'REC'
									when exists(select distinct cm_statut from t_cheminement 
																inner join t_cond_chem on cm_code = dm_cm_code
																inner join t_cab_cond on cc_cd_code = dm_cd_code
																where cc_cb_code=cb_code and cm_statut='AVP') then 'AVP'
									else 'PRO'
								end);
update t_cable set cb_datemes=DATE('NOW') where cb_statut='REC';
update t_cable set cb_avct='E' where cb_statut='REC';

/*t_ebp*/
update t_ebp set bp_comment = '';--david
update t_ebp set bp_etiquet = SUBSTR(bp_codeext,8,5);--david
update t_ebp set bp_typephy = 'B576' where bp_typephy = 'B432'; --david requete temporaire, erreur a fixer dans fibready
update t_ebp set bp_datemes=DATE('NOW') where bp_statut='REC';

/*t_sitetech*/
update t_sitetech set st_gest = 'OR91000000000002' where st_typelog in ('NRO','SRO');--david
update t_sitetech set st_nom ='' where st_nom ='PBO_imm';--david
update t_sitetech set st_prop='' where st_typelog not in ('NRO','SRO');--david
--aude
update t_sitetech set st_proptyp= (case 
									when st_typelog in ('NRO','SRO') then 'CST'
									else 'OCC'
									end) ;
update t_sitetech set st_datemes = DATE('NOW') where st_statut='REC';
update t_sitetech set st_ad_code = (select ad_code from t_adresse where ad_batcode = 'ES-BAT-'||substr(st_codeext,8,5)) where st_typelog = 'CLIENT';

/*t_conduite*/
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then 'OR91000000000002' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR91000000000003'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR91000000000004'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR91000000000006'
end);--barbara
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='C') then '' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR91000000000003'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR91000000000004'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR91000000000006'
end);--barbara
update t_conduite set cd_creadat = ( select dm_creadat from t_cond_chem, t_conduite where dm_cd_code = cd_code); --david
--aude: pour être conforme au MCD APD Essonne
--update t_conduite set cd_proptyp=null; APD
update t_conduite set cd_type='NC';
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;
update t_conduite set cd_datemes=(select cm_datemes from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);
--update t_conduite set cd_statut=(select cm_statut from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);
update t_conduite set cd_comment = (select cm_comment from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);

/*t_cable --> heritage de t_conduite */
--aude
update t_cable set cb_comment =(select cd_comment from t_conduite, t_cab_cond where cc_cd_code=cd_code and cc_cb_code=cb_code);

/*t_ptech*/
update t_ptech set pt_etiquet = pt_codeext where pt_avct = 'C' and pt_typephy = 'A';--david
update t_ptech set pt_proptyp = (case
									when pt_avct = 'C' and pt_typephy in ('A','C') then 'CST'
									when pt_avct = 'E' and pt_typephy in ('A','C') then 'LOC'
									when pt_avct = 'E' and pt_typephy in ('I','F','Z') then 'LOC'
								end);--david
 --aude 
	--(pour les chambres)
 update t_ptech set pt_rf_code= (case
									when pt_nature='L2T' then 'RF91000000000131'
									when pt_nature='L3T' then 'RF91000000000132'
									when pt_nature='L4T' then 'RF91000000000133'
									when pt_nature='L5T' then 'RF91000000000134'
									when pt_nature='K1C' then 'RF91000000000135'
									when pt_nature='K2C' then 'RF91000000000136'
									else 'A REMPLIR'
								end) where (pt_avct='C' and pt_typephy='C');
	/*à faire: pour les poteaux à créer (comment on les appelle? quelle hauteur?)Dans DOU J1 tous les appuis à créer sont IND, je mets poteaux composite 8M par défaut*/
 update t_ptech set pt_rf_code= (case
									when pt_nature = 'IND' then 'RF91000000000139'
									else 'A REMPLIR'
								end) where (pt_avct='C' and pt_typephy='A');
 --
 update t_ptech set pt_detec='0'; 
 update t_ptech set pt_datemes = DATE('NOW') where pt_statut='REC';
 update t_ptech set pt_gest_do='A REMPLIR' where pt_avct='C';
 
 /*t_ltech*/
 --aude
 update t_ltech set lt_proptyp =( select st_proptyp from t_sitetech where lt_st_code = st_code); 
 update t_ltech set lt_statut=(select st_statut from t_sitetech where lt_st_code=st_code);
 
 /*t_noeud*/
 --aude
 update t_noeud set nd_dtclass='A' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C');
 
 /*t_baie*/ 
 --aude
 update t_baie set ba_statut='REC';
 update t_baie set ba_gest='OR91000000000002';
 update t_baie set ba_prop='OR91000000000001';
 update t_baie set ba_proptyp='CST';
 update t_baie set ba_type ='BAIE';
 update t_baie set  ba_rf_code = (select case 
 when zs_nblogmt <= 360 then  'RF91000000000003'
when zs_nblogmt > 360 then  'RF91000000000004'
when ba_code like 'BA91000%' then 'RF91000000000001'
end
from t_zsro, t_baie, t_ltech, t_sitetech
where zs_nd_code= st_nd_code and st_code = lt_st_code and ba_lt_code = lt_code);
 update t_baie set ba_nb_u = (case
									when ba_rf_code ='RF91000000000003'  then 28
									when ba_rf_code='RF91000000000004' then 40
									when ba_rf_code='RF91000000000001' then 42
								end);
--update t_baie set ba_codeext= 'ES-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code) ||'-01' where ba_rf_code='RF91000000000001';								
--update t_baie set ba_codeext= 'ES-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code) ||'-02' where ba_rf_code<>'RF91000000000001';	


/*t_cassette*/
update t_cassette set cs_nb_pas=null;

/*t_tiroir*/
update t_tiroir set ti_etiquet=ti_codeext;
update t_tiroir set ti_prop = 'OR91000000000001';
update t_tiroir set ti_taille=4;
update t_tiroir set ti_type='TIROIR';

/*t_cable_patch*/
 update t_cable_patch201 set cb_bp2=null where cb_ba2 is not null;

 /* t_fibre */
update t_fibre set fo_nincab = null;
update t_fibre set fo_type = 'G657A2';
update t_fibre set fo_color = null;
update t_fibre set fo_reper = null;
 
 /*t_position*/
 update t_position set ps_type = 'SFU' where ps_fonct = 'EP';
 update t_position set ps_type = 'CSA' where ps_fonct = 'CO';
 
 /* t_cassette */
 update t_cassette set cs_rf_code ='RF91000000000128'  where cs_type='C';
 update t_cassette set cs_rf_code = 'RF91000000000125' where cs_type='E' and cs_bp_code in (select bp_code from t_ebp where bp_typephy in ('B012','B024' ,'B036','B048','B072','B096','B144')) ; --petits câbles
 update t_cassette set cs_rf_code = 'RF91000000000129' where cs_type='E' and cs_bp_code in (select bp_code from t_ebp where bp_typephy in ('B288','B432' ,'B576','B720')); --gros cables
 
 
 end transaction;
 
/*t_ebp*/
begin transaction;
delete from t_ebp where bp_typelog in ('NRO','SRO');
end transaction;

begin transaction;

update t_conduite set cd_avct = 'E' where cd_statut = 'REC';
update t_cheminement set cm_avct = 'E' where cm_statut = 'REC';
update t_ebp set bp_avct = 'E' where bp_statut='REC';
update t_ptech set pt_avct = 'E' where pt_statut='REC';

end transaction;



--aude
/*supprimer les points adresse pour les locaux tech sur les immeubles ATTENTION ne marche que pour DOU 
begin transaction;
	create view loctech as select ad_batcode as loctech from t_adresse where (ad_batcode like 'ES-TEC-%' and ad_batcode not like 'ES-TEC-DOU%') ; --loctech
	create view increment as select substr(loctech,8,5) as increment from loctech ;--increment
	create view bati as select 'ES-BAT-'||increment as bati from increment; --bati
	create view ad2 as select ad_code, ad_batcode, st_codeext from (select ad_code, ad_batcode from t_adresse where ad_batcode in (select "bati" from bati)) join t_sitetech on (substr(ad_batcode,8,5) = substr(st_codeext,8,5)); --ad2
	update t_sitetech set st_ad_code=(select ad_code from ad2 where t_sitetech.st_codeext=ad2.st_codeext) where st_typelog='CLIENT' and st_codeext in (select ad2.st_codeext from ad2); --mise à jour st_ad_code pour st_typelog=CLIENT
	delete from t_adresse where (ad_batcode like 'ES-TEC-%' and ad_batcode not like 'ES-TEC-DOU%');--suppression des t_adresse pour les locaux techniques autres que SRO, NRO
	update t_adresse set ad_batcode=null where ad_batcode like 'ES-TEC-DOU%';--vider le champ ad_batcode pour les SRO et NRO
	drop view loctech;
	drop view increment;
	drop view bati;
	drop view ad2;
end transaction;

begin transaction;
	create view sro as select st_typelog, ba_code as code from t_sitetech inner join t_ltech ON t_sitetech.st_code=t_ltech.lt_st_code
																	inner join t_baie on t_ltech.lt_code=t_baie.ba_lt_code
																	where st_typelog='SRO';
	update t_baie set ba_etiquet =(case 
									when ba_code=(select code from sro) then 'B02'
									else ba_codeext
								end);
	drop view sro;
end transaction;*/

begin transaction;
update t_zsro set zs_nblogmt =null;
update t_baie set ba_etiquet= 'B02' where ba_code not like 'BA91000%';
update t_baie set ba_etiquet= ba_codeext where ba_code like 'BA91000%';
end transaction;