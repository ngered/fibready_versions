begin transaction; --Aude 19/03
create view baie as select ba_code as ba_code,ba_codeext as ba_codeext, ba_lt_code as ba_lt_code, ba_statut as ba_statut, ba_rf_code as ba_ref from t_baie ;
insert into t_baie(ba_code,ba_codeext,ba_etiquet, ba_lt_code, ba_prop, ba_gest, ba_proptyp, ba_statut, ba_rf_code, ba_type) 
                select substr(ba_code,1,13)||'2',ba_codeext,'1', ba_lt_code, 'OR033001002022','OR033001001506', 'CST', ba_statut,ba_ref,'BAIE' from baie;
drop view baie;
end transaction;

BEGIN TRANSACTION;

/* maj Orange */
update t_cable set cb_prop='OR033001001581' where cb_prop='OR91000000000003';
update t_ebp set bp_prop='OR033001001581' where bp_prop='OR91000000000003';
--update t_ptech set pt_prop='OR033001001581' where pt_prop='OR91000000000003';
update t_ltech set lt_prop='OR033001001581' where lt_prop='OR91000000000003';
update t_sitetech set st_prop='OR033001001581' where st_prop='OR91000000000003';

/* maj enedis */
update t_cable set cb_prop='OR033002000000' where cb_prop='OR91000000000004';
update t_ebp set bp_prop='OR033002000000' where bp_prop='OR91000000000004';
--update t_ptech set pt_prop='OR033002000000' where pt_prop='OR91000000000004';
update t_ltech set lt_prop='OR033002000000' where lt_prop='OR91000000000004';
update t_sitetech set st_prop='OR033002000000' where st_prop='OR91000000000004';

/*maj RAUV*/
update t_cable set cb_prop='OR033001001714' where cb_prop='OR91000000000001';
update t_ebp set bp_prop='OR033001001714' where bp_prop='OR91000000000001';
--update t_ptech set pt_prop='OR033001001714' where pt_prop='OR91000000000001';
update t_ltech set lt_prop='OR033001001714' where lt_prop='OR91000000000001';
update t_sitetech set st_prop='OR033001001714' where st_prop='OR91000000000001';

/*maj ATHD*/
update t_cable set cb_prop='OR033001000259' where cb_prop='OR91000000000002';
update t_ebp set bp_prop='OR033001000259' where bp_prop='OR91000000000002';
--update t_ptech set pt_prop='OR033001000259' where pt_prop='OR91000000000002';
update t_ltech set lt_prop='OR033001000259' where lt_prop='OR91000000000002';
update t_sitetech set st_prop='OR033001000259' where st_prop='OR91000000000002';


/*maj TIERS*/
update t_cable set cb_prop='OR000000000000' where cb_prop='OR91000000000006' ;
update t_ebp set bp_prop='OR000000000000' where bp_prop='OR91000000000006' ;
--update t_ptech set pt_prop='OR033001002690' where pt_prop='OR91000000000006' ;
update t_ltech set lt_prop='OR000000000000' where lt_prop='OR91000000000006' ;
update t_sitetech set st_prop='OR000000000000' where st_prop='OR91000000000006';


/* etiquettes */
update t_ltech set lt_etiquet = lt_codeext;
update t_ltech set lt_codeext = null;
update t_ptech set pt_etiquet = pt_codeext;
update t_ptech set pt_codeext =null;
update t_ebp set bp_etiquet = bp_codeext;
update t_ebp set bp_codeext = null;
update t_cable set cb_etiquet = cb_codeext;

/*t_cableline*/
update t_cableline set cl_geolqlt=null;
delete from t_cableline where st_length (geom) = 0;
--update t_cableline set cl_long = ST_Length(geom); 

/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_ban_id=null;
update t_adresse set ad_y_ban=null;
update t_adresse set ad_x_ban=null;
update t_adresse set ad_prio = '0';
update t_adresse set ad_ietat = 'CI';
update t_adresse set ad_racc = '7' where ad_racc = '' ;
update t_adresse set ad_iaccgst = '0' where ad_itypeim  = '' ;
update t_adresse set ad_itypeim  = 
	case 
		when ad_nblhab + ad_nblpro > 4 then 'I'
		else 'P'
	end ;
update t_adresse set ad_rep=null where ad_rep like 'NEW%';
update t_adresse set ad_imneuf='0'; 
update t_adresse set ad_hexacle = null;
update t_adresse set ad_hexaclv = null;

update t_adresse set ad_isole = case 
    when (select cl_long from t_cableline where cl_cb_code = (select cb_code from t_cable where cb_nd2 = (select nd_code from t_noeud where nd_codeext = t_adresse.ad_batcode))) > 100 then '1'
    else '0'
end;


/*t_baie*/
update t_baie set ba_prop = 'OR033001001714';
update t_baie set ba_gest = 'OR033001001714';


update t_baie set ba_rf_code = case
	when (select lt_st_code from t_ltech where t_ltech.lt_code = t_baie.ba_lt_code) = (select st_code from t_sitetech where t_sitetech.st_typelog = 'NRO' limit 1) then 'RF033000000026'
    when (select mat_ref from IMPORT_BPE where IMPORT_BPE.noe_type = 'SRO' and IMPORT_BPE.mat_ref = 'PM 28'
     limit 1) is not null then 'RF033000000238'
    when  (select mat_ref from IMPORT_BPE where IMPORT_BPE.noe_type = 'SRO' and IMPORT_BPE.mat_ref = 'PM 40'
     limit 1) is not null then 'RF033000000239'
    else null
end;

update t_baie set ba_nb_u = case
	when (select lt_st_code from t_ltech where t_ltech.lt_code = t_baie.ba_lt_code) = (select st_code from t_sitetech where t_sitetech.st_typelog = 'NRO' limit 1) then '42'
    when (select mat_ref from IMPORT_BPE where IMPORT_BPE.noe_type = 'SRO' and IMPORT_BPE.mat_ref = 'PM 28'
     limit 1) is not null then '28'
    when  (select mat_ref from IMPORT_BPE where IMPORT_BPE.noe_type = 'SRO' and IMPORT_BPE.mat_ref = 'PM 40'
     limit 1) is not null then '40'
    else null
end;

update t_baie set ba_type = 'BAIE';

/*t_ebp*/
update t_ebp set bp_statut='EXE';
update t_ebp set bp_prop='OR033001001714' ;
update t_ebp set bp_gest = 'OR033001000259' ;
update t_ebp set bp_proptyp = 'CST';
update t_ebp set bp_ca_nb = (
  select max(t_cassette.cs_num)
  from t_cassette
  where t_cassette.cs_bp_code = t_ebp.bp_code
);

update t_ebp set bp_etiquet = case
     when bp_typelog = 'PTO' then 'OO-XXXX-XXXX'
     else (select IDMET99 from IMPORT_BPE where IMPORT_BPE.noe_codext = t_ebp.bp_etiquet) --récup des IDMET codes
     end; 

update t_ebp set bp_codeext = 
COALESCE(
    (select PF99 from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet),
    t_ebp.bp_codeext
);   --récup des PF codes

update t_ebp set bp_rf_code = case 
	when bp_typelog='PTO' then 'RF033000000028'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) in ('Telenco','PB Telenco') then 'RF033000001596'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'Black box' then 'RF033000000230'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'T1' then 'RF033000000201'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'T1,5' then 'RF033000000290'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'T2' then 'RF033000000203'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'BPI 144' then 'RF033000000201'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'BPI 36' then 'RF033000000200'
	when (select mat_ref from IMPORT_BPE where IMPORT_BPE.IDMET99 = t_ebp.bp_etiquet) = 'PB imb' then 'RF033000000234'
	else null
	end;

/*t_fibre*/
update t_fibre set fo_type = (case
    when (select cb_typelog from t_cable where t_cable.cb_code = t_fibre.fo_cb_code) = 'DI' then 'G657'
    else 'G652'
  end
);

/*t_cassette*/
update t_cassette
set cs_nb_pas = case
    when (select noe_pose from IMPORT_BPE where IMPORT_BPE.IDMET99 = (select bp_etiquet from t_ebp where t_ebp.bp_code = t_cassette.cs_bp_code limit 1) limit 1) in ('POT-AC', 'POT-BT', 'POT-FT') then '6'
    else '12'
end;

update t_cassette set cs_face = case when cs_num > 0 then 'Face A' else 'FDB' end;
update t_cassette set cs_rf_code = 'RF033000000027';

/*t_cheminement*/
update t_cheminement set cm_r1_code = substr(cm_code, 3, 2);
update t_cheminement set cm_statut='EXE';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;

-- Mise à jour de cm_gest_do cm_prop_do en fonction de la colonne proprio sur la base FibReady
update t_cheminement set cm_prop_do = case
	when cm_avct = 'C' then 'OR033001001714' -- RAUV
	when cm_avct = 'E' and cm_typ_imp = '1' then 'OR033002000000' -- ENEDIS
	when ((cm_avct = 'E' and cm_typ_imp = '0') or (cm_avct = 'E' and cm_typ_imp = '7')) 
	and (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'ORANGE' then 'OR033001001581' -- Orange

	when ((cm_avct = 'E' and cm_typ_imp = '0') or (cm_avct = 'E' and cm_typ_imp = '7')) 
	and (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'ATHD' then 'OR033001000259' -- ATHD

	else 'OR033001002690' -- TIERS
    --when (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'ENEDIS' then 'OR033002000000' -- ENEDIS
    --when (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'ORANGE' then 'OR033001001581' -- Orange
    --when (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'ATHD' then 'OR033001000259' -- ATHD
    --when (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'RAUV' then 'OR033001001714' -- RAUV
    --when (select proprio from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code) = 'TIERS' then 'OR033001002690' -- TIERS
    --else null
end;

update t_cheminement set cm_gest_do = cm_prop_do ;

update t_cheminement set cm_r2_code = (select cm_r2_code from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code);
update t_cheminement set cm_r3_code = (select cm_r3_code from FR.t_cheminement where FR.t_cheminement.cm_code = t_cheminement.cm_code);

-- update t_cheminement set cm_gest_do = (case
--	when cm_avct = 'C' then 'OR033001001714' /*RAUV*/
--	when cm_avct = 'E' and cm_typ_imp = '1' then 'OR033002000000' /*enedis*/
--	when (cm_avct = 'E' and cm_typ_imp = '0') or (cm_avct = 'E' and cm_typ_imp = '7') then 'OR033001001581' /*orange*/
--	else 'OR033001002690' /*TIERS*/
--	end); 

update t_cheminement set cm_charge = (case
	when cm_mod_pos = 'TRA' then '0.6'
	when cm_mod_pos = 'MIC' then '0.3'
	when cm_mod_pos = 'FON' then null
	when cm_mod_pos = 'FOR' then '1.2'
end); 

update t_cheminement set cm_etat=null;

/*t_conduite*/
update t_conduite set cd_statut = 'EXE' ;
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'OR033001001714' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033001002690'
end);

update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'OR033001001714' 
--when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
--when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
--when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033001002690'

else null --MCD: Gestionnaire du fourreau à renseigner Si GC à créer
end);

update t_conduite set cd_type = (case
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_compo like '%PVC%') then 'PVC' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_compo like '%PEHD%') then 'PEHD' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_typ_imp='0' or cm_typ_imp='1' or cm_typ_imp='2') then 'AER' 
when cd_avct='E' then 'NC'
end);

update t_conduite set cd_avct =(case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'C'
else 'E'
end);

update t_conduite set cd_dia_ext = substr((select cm_compo from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code),instr((select cm_compo from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code),'/')+1)
	where cd_type ='PVC' or cd_type='PEHD';

update t_conduite set cd_proptyp=null;
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;

/*t_ptech*/
update t_ptech set pt_statut='EXE';
update t_ptech set pt_codeext = pt_etiquet;

update t_ptech set pt_prop = (
    case
        when TEMP_INFRA_POINTS.inf_propri = 'ENEDIS' then 'OR033002000000' -- ENEDIS
        when TEMP_INFRA_POINTS.inf_propri = 'ORANGE' then 'OR033001001581' -- Orange
        when TEMP_INFRA_POINTS.inf_propri = 'ATHD' then 'OR033001000259' -- ATHD
        when TEMP_INFRA_POINTS.inf_propri = 'RAUV' then 'OR033001001714' -- RAUV
        when TEMP_INFRA_POINTS.inf_propri = 'TIERS' or t_ptech.pt_typephy = 'F' then 'OR033001002690' -- TIERS
        else null
    end
) from TEMP_INFRA_POINTS where TEMP_INFRA_POINTS.inf_num = t_ptech.pt_codeext;

--update t_ptech set pt_prop = 'OR033001002690' where pt_typephy = 'F'; 

update t_ptech set pt_gest = 
	(case
		when pt_prop = 'OR033001002690' then 'OR000000000000'
		else pt_prop
	end);

update t_ptech set pt_a_haut = null where pt_avct = 'E';
update t_ptech set pt_secu = '0' where pt_avct = 'C' and pt_typephy = 'C';

/*t_ltech*/
update t_ltech set lt_statut='EXE';
update t_ltech set lt_prop ='OR033001001714';
update t_ltech set lt_gest ='OR033001001714';
update t_ltech set lt_proptyp ='CST';

update t_ltech set lt_elec= (case
	when (select st_typelog from t_sitetech where st_code=lt_st_code)='NRO' then 1
	else 0 end);

update t_ltech set lt_clim = 'SANS' where lt_st_code in (select st_code from t_sitetech where st_typelog='SRO');
update t_ltech set lt_clim = 'CLIM' where lt_st_code in (select st_code from t_sitetech where st_typelog='NRO');
update t_ltech set lt_clim = 'SANS' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_etiquet = 'LT_VERTICALITE' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_prop = 'OR000000000000' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_gest = 'OR000000000000' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');

/*t_sitetech*/
update t_sitetech set st_statut='EXE';
update t_sitetech set st_codeext = (select inf_num from IMPORT_BPE where IMPORT_BPE.noe_type in ('NRO','SRO')); 

--sro/nro
update t_sitetech set st_prop ='OR033001001714' where st_typelog in ('NRO','SRO');
update t_sitetech set st_gest ='OR033001001714' where st_typelog in ('NRO','SRO');
update t_sitetech set st_proptyp ='CST' where st_typelog in ('NRO','SRO');
update t_sitetech set st_nom = (select noe_num from IMPORT_BPE where IMPORT_BPE.noe_type = t_sitetech.st_typelog and t_sitetech.st_typelog in ('NRO', 'SRO')) where st_typelog in ('NRO', 'SRO');
update t_sitetech set st_avct = 'C' where st_typelog in ('NRO','SRO');

--immeubles 
update t_sitetech set st_prop ='OR000000000000' where st_typelog = 'CLIENT';
update t_sitetech set st_gest ='OR000000000000' where st_typelog = 'CLIENT';
update t_sitetech set st_proptyp ='OCC' where st_typelog = 'CLIENT';
update t_sitetech set st_nom =(select ad_batcode from t_adresse where st_ad_code = ad_code) where st_typelog ='CLIENT';

/*t_noeud */
update t_noeud set nd_codeext = (case
        when exists (select 1 from t_suf where t_suf.sf_nd_code = t_noeud.nd_code)
        	then (select ad_batcode from t_adresse where t_adresse.ad_code = (select sf_ad_code from t_suf where t_suf.sf_nd_code = t_noeud.nd_code limit 1))
        when exists (select 1 from t_ptech where t_ptech.pt_nd_code = t_noeud.nd_code) 
        	then (select pt_codeext from t_ptech where t_ptech.pt_nd_code = t_noeud.nd_code limit 1)
        else nd_codeext 
    end);

--TR
update t_noeud set nd_r3_code=NULL where nd_r3_code='00';

/* t_znro */
update t_znro set zn_nrotype = 'PON';
update t_znro set zn_etat = 'DP';

/*t_zsro*/
update t_zsro set zs_r3_code = t_noeud.nd_codeext from t_noeud where t_zsro.zs_nd_code = t_noeud.nd_code;
update t_zsro set zs_refpm = zs_r3_code;
update t_zsro set zs_nblogmt=(select count(sf_code) from t_suf);
update t_zsro set zs_etatpm = 'EC';
update t_zsro set zs_typeemp = 'ADR';
update t_zsro set zs_typeing = 'mono';
update t_zsro set zs_actif = '0';
update t_zsro set zs_capamax = (case
	when zs_nblogmt <  406 then '405'
	when zs_nblogmt > 405 then '612'
end);

/* t_zpbo */
update t_zpbo set zp_r3_code = t_zsro.zs_r3_code from t_zsro;


/*t_cable*/
update t_cable set cb_modulo=6 where cb_typelog='DI';
update t_cable set cb_modulo=12 where cb_typelog='TR' OR cb_typelog='CO';
update t_cable set cb_modulo=2 where cb_typelog='RA';
update t_cable set cb_proptyp = 'CST';

update t_cable set cb_statut='EXE';
update t_cable set cb_etat=null;

update t_cable set cb_rf_code =
case 
	when cb_capafo ='1' then 'RF033000000309'
	when cb_capafo ='6' then 'RF033000000584'
	when cb_capafo ='12' then 'RF033000000585'
	when cb_capafo ='24' then 'RF033000000586'
	when cb_capafo ='36' then 'RF033000000587'
	when cb_capafo ='48' then 'RF033000000588'
	when cb_capafo ='72' then 'RF033000000589'
	when cb_capafo ='144' then 'RF033000000597'
	when cb_capafo ='288' then 'RF033000000102'
	when cb_capafo ='432' then 'RF033000000660'
	when cb_capafo ='576' then 'RF033000000661'
	when cb_capafo ='720' then 'RF033000000662'
end ;

update t_cable set cb_capafo ='2' where cb_capafo='1';
update t_cable set cb_prop = 'OR033001001714';
update t_cable set cb_gest = 'OR033001000259';

update t_cable set cb_codeext = cb_etiquet;
update t_cable set cb_etiquet = case 
	when cb_typelog ='RA' then 'OO-XXXX-XXXX'
	else (select CAB99 from IMPORT_BPE where IMPORT_BPE.cab_codext = t_cable.cb_etiquet)
	end
where cb_typelog is not null;  

--r1
update t_cable set cb_r1_code = substr(cb_codeext, 1, 2);
update t_cable set cb_r3_code=null;
-- update t_cable set cb_fo_disp=cb_fo_util-(select nblr_cum from import_bpe where cb_etiquet = cab_codext) where cb_typelog='DI'; --(Nicolas)
-- update t_cable set cb_fo_util=(select nblr_cum from import_bpe where cb_etiquet = cab_codext) where cb_typelog='DI';


/* t_baie suite*/
--
--update t_baie set ba_rf_code = 'RF033000000026' where ba_etiquet like '%RTO%';
--update t_baie set ba_rf_code = 'RF033000000238' where ba_etiquet like '%PMT%' and ( select ti_placemt from t_tiroir where ti_placemt = 26);
--update t_baie set ba_rf_code = 'RF033000000239' where ba_etiquet like '%PMT%' and ( select ti_placemt from t_tiroir where ti_placemt = 38);
--update t_baie set ba_rf_code = 'RF033000000026' where ba_etiquet like '%PMT%' and ( select ti_placemt from t_tiroir where ti_placemt = 40);

update t_baie set ba_nb_u = (case
	when ba_rf_code = 'RF033000000239' then '40'
	when ba_rf_code = 'RF033000000238' then '28'
	when ba_rf_code = 'RF033000000026' then '42'
	when ba_rf_code = 'RF033000001355' then '40'
end);
--

/* t_fibre */
update t_fibre set fo_proptyp='CST';
update t_fibre set fo_code_ext = null; 
update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='DI');
update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='RA');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='TR');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='CO');

/* t_position */
update t_position set ps_preaff = (case 
when ps_comment = 'ABONNE' then  'ABONNE'
end);

update t_position set ps_cs_code = NULL where ps_ti_code != '' or (ps_ti_code != '' and ps_ti_code is not null) ; --pas de K7 dans les tiroirs

delete from t_position where ps_fonct='';
update t_position set ps_fonct='AT' where ps_ti_code in (select ti_code from t_tiroir where ti_placemt='1');


/* t_baie */

--update t_baie set ba_codeext=null;
--update t_baie set ba_prop='OR033001001714';
--update t_baie set ba_gest='OR033001001714';
--update t_baie set ba_proptyp='CST';
--update t_baie set ba_type='BAIE';
--update t_baie set ba_haut = null; 
--update t_baie set ba_larg = null;
--update t_baie set ba_prof = null; 

--update t_baie set ba_etiquet = IMPORT_BPE.PT99 from IMPORT_BPE where IMPORT_BPE.noe_type in ('SRO', 'NRO');
--update t_baie set ba_etiquet = ba_etiquet || '/Porte ' || 
               --case
                   --when t_baie.rowid = 1 then 'Droite'
                   --when t_baie.rowid = 2 then 'Gauche'
                --end;

/* t_tiroir */

--update t_tiroir set ti_codeext = t_baie.ba_etiquet from t_baie where t_baie.ba_code = t_tiroir.ti_ba_code ;
--update  t_tiroir set ti_codeext = ti_codeext || '/Slot ' || t_tiroir.ti_etiquet;
--update  t_tiroir set ti_etiquet = ti_codeext;

/*t_ropt */
DELETE FROM t_ropt; 


/* t_cassette */
delete from t_cassette_patch201 where cs_ti_code is null;
update t_cassette set cs_bp_code= null where cs_code in ( select cs_code from t_cassette_patch201);
delete from t_cassette_patch201;
delete from t_cassette where cs_bp_code is null;

update t_cassette set cs_face= 'A' where cs_num > 0;
update t_cassette set cs_face = 'FDB' where cs_num = 0 and cs_type = 'P'; 

/*sup SRO NRO t_cable_patche*/
update t_cable_patch201 set cb_bp1 = NULL where cb_bp1 in (select bp_code from t_ebp where bp_typelog='SRO' or bp_typelog='NRO');
update t_cable_patch201 set cb_bp2 = NULL where cb_bp2 in (select bp_code from t_ebp where bp_typelog='SRO' or bp_typelog='NRO');


/* sup NRO dans t_sitetech, t_ltech et t_adresse */

-- désactiver les contraintes de clé étrangère
pragma foreign_keys = OFF;

-- vérifier si 'Transport' existe dans t_cable
delete from t_adresse where ad_batcode like '%NRO%' and not exists (select 1 from t_cable where cb_typelog = 'TR');

delete from t_baie where ba_code not in (select ti_ba_code from t_tiroir);

delete from t_tiroir where ti_ba_code in (select ba_code from t_baie) and exists (select 1 from t_cable where cb_typelog = 'TR');
delete from t_tiroir where ti_codeext like '%NRO%' and not exists (select 1 from t_cable where cb_typelog = 'TR');

delete from t_ltech where lt_st_code in (select st_code from t_sitetech where st_typelog = 'NRO') and not exists (select 1 from t_cable where cb_typelog = 'TR');
delete from t_sitetech where st_typelog = 'NRO' and not exists (select 1 from t_cable where cb_typelog = 'TR');

-- supprimer les sro et nro dans t_ebp
delete from t_ebp where bp_typelog = 'SRO';
delete from t_ebp where bp_etiquet like '%NRO%';

-- réactiver les contraintes de clé étrangère
pragma foreign_keys = ON;


/* t_love*/

delete from t_love where lv_long = '0';

/* t_suf*/
update t_suf set sf_comment = null;
update t_suf set sf_local = null; 
update t_suf set sf_comment = 'Futur prise' where sf_ad_code in ( select ad_code from t_adresse where ad_imneuf='0');


/* champs a vider */
update t_adresse set ad_typzone=null;
update t_adresse set ad_geolsrc=null; 
update t_adresse set ad_creadat=null; 
update t_adresse set ad_gest=null;
update t_adresse set ad_comment=null; 
update t_baie set ba_creadat=null;
update t_ebp set bp_creadat=null;
update t_cable set cb_creadat=null;
update t_cab_cond set cc_creadat=null;
update t_conduite set cd_creadat=null;
/*update t_conduite set cd_r2_code=null;*/
update t_cableline set cl_creadat=null;
update t_cableline set cl_long=null;
update t_cableline set cl_comment=null; 
update t_cheminement set cm_creadat=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_geolqlt=null;
update t_cheminement set cm_geolsrc=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_long=null;
update t_cassette set cs_creadat=null;
update t_cassette set cs_nb_pas=null;
update t_cond_chem set dm_creadat=null;
update t_fibre set fo_color=null;
update t_fibre set fo_creadat=null;
update t_fibre set fo_proptyp=null;
update t_fibre set fo_reper=null;
update t_ltech set lt_creadat=null;
update t_ltech set lt_dateins=null;
update t_ltech set lt_datemes=null;
update t_ltech set lt_proptyp=null;
update t_love set lv_creadat=null;
update t_noeud set nd_creadat=null;
update t_noeud set nd_geolqlt=null;
update t_noeud set nd_voie=null; 
update t_noeud set nd_r3_code=null; 
update t_position set ps_creadat=null;
update t_ptech set pt_creadat=null;
update t_suf set sf_creadat=null;
update t_sitetech set st_codeext=null;
update t_sitetech set st_creadat=null;
update t_sitetech set st_etat=null;
update t_tiroir set ti_creadat=null;
update t_znro set zn_creadat=null;
update t_znro set zn_nrotype=null;
update t_zpbo set zp_creadat=null;
update t_zsro set zs_creadat=null;
update t_zsro set zs_nbcolmt=null;
update t_zsro set zs_typeing=null;

/* Maj l_tech_patch_201 pour sro et nro */
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in (select lt_code from t_ltech_patch201);
update t_ltech_patch201 set lt_bat = 'NA';

/* mise a jour PTO */
update t_cable set cb_etiquet = 'OO-XXXX-XXXX' where cb_typelog='RA';
update t_cable set cb_rf_code = 'RF033000000309' where cb_typelog='RA';


/* collecte mutualis dans distri transport */
update t_cable set cb_typelog='CT' where cb_typelog='CO';

--Mise à jour du nd_r3_code
update t_noeud set nd_r3_code= null where nd_r2_code = nd_r3_code;


END TRANSACTION;