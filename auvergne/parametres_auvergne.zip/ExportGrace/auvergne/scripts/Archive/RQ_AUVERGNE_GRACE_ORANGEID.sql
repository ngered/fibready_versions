﻿--renseigne le champ bp_etiquet avec idmet orange
--renseigne le st_nom asvec idreg orange

-- attache la base fibready
--ATTACH DATABASE 'c:/NoDrive/Documents/Etudes/Auvergne/test_grace_pilote/DATA/63087_QRD_PMZ_73413.fbt' as FR;

-- création vue tags/noeuds
DROP VIEW IF EXISTS FR.FBT_ORANGE_ID ;

CREATE VIEW FR.FBT_ORANGE_ID as
SELECT 
       [FR].[T_TAG].[TAG_NAME], 
       [FR].[L_TAG_ENTITY].[TAG_VALUE], 
       [FR].[L_FBT_GRA].[GRA_TBL], 
       [FR].[L_FBT_GRA].[CODEXT], 
       [FR].[NOEUDS].[TYPE] as [NOE_TYPE]
FROM   [FR].[L_TAG_ENTITY]
       INNER JOIN [FR].[T_TAG] ON [FR].[L_TAG_ENTITY].[TAG_KEY] = [FR].[T_TAG].[TAG_ID]
       INNER JOIN [FR].[L_FBT_GRA] ON [FR].[L_TAG_ENTITY].[ENT_KEY] = [FR].[L_FBT_GRA].[FBT_KEY]
       INNER JOIN [FR].[NOEUDS] ON [FR].[L_FBT_GRA].[FBT_KEY] = [FR].[NOEUDS].[NOEID]
WHERE  [FR].[L_FBT_GRA].[FBT_TBL] = 'NOEUDS';


-- maj t_ebp / idmet
Update main.t_ebp 
set bp_etiquet= (select tag_value from FR.FBT_ORANGE_ID 
where gra_tbl='T_EBP' and codext = bp_codeext and tag_name='IDMET' and [NOE_TYPE] <> 'PA')
where bp_etiquet is null or bp_etiquet='' ;

-- maj t_ebp / idreg pour PA
Update main.t_ebp 
set bp_etiquet= (select tag_value from FR.FBT_ORANGE_ID 
where gra_tbl='T_EBP' and codext = bp_codeext and tag_name='IDREG' and [NOE_TYPE] = 'PA')
where bp_etiquet is null or bp_etiquet='';

-- maj t_sitetech / idreg
Update main.t_sitetech 
set st_nom= (select tag_value from FR.FBT_ORANGE_ID 
where gra_tbl='T_SITETECH' and codext = st_codeext and tag_name='IDREG') 
where st_nom is null or st_nom='';

-- supprime la vue et détache base fibready
DROP VIEW IF EXISTS FR.FBT_ORANGE_ID ;
--DETACH FR;