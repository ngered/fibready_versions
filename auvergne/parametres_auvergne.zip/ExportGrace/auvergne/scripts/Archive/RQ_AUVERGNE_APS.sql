﻿begin transaction;

/*Organisme */
update t_ebp set bp_gest='OR91000000000002';
update t_cable set cb_gest='OR91000000000002';

--OR033001000259 AUVERGNE TRES HAUT DEBIT

/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);
update t_adresse set ad_comment =  substr (ad_comment , (length (ad_comment)/2)) ;
update t_adresse set ad_ban_id=null;
update t_adresse set ad_nbprhab=null;
update t_adresse set ad_nbprpro=null;
update t_adresse set ad_itypeim=null;
update t_adresse set ad_typzone=null;
update t_adresse set ad_numero=null where ad_numero=0;
update t_adresse set ad_racc=null where ad_nblhab=0 and ad_nblpro=0;
update t_adresse set ad_nat=null where ad_nblhab=0 and ad_nblpro=0;
update t_adresse set ad_creadat=datetime(ad_creadat);
update t_adresse set ad_isole=null where ad_nblhab=0 and ad_nblpro=0;
update t_adresse set ad_nombat=(select ADR_DENOM from IMPORT_BAL where t_adresse.ad_batcode=IMPORT_BAL.noe_codext);

/*t_noeud */
update t_noeud set nd_r3_code=nd_r2_code || '_0' || substr(nd_code,6,2);
update t_noeud set nd_geolqlt=null;
update t_noeud set nd_voie=null;
update t_noeud set nd_r4_code=null;
update t_noeud set nd_creadat=datetime(nd_creadat);


/*t_cableline*/
update t_cableline set cl_geolqlt=null;
update t_cableline set cl_creadat=datetime(cl_creadat);

/*t_cheminement*/
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_etat=null;
update t_cheminement set cm_creadat=datetime(cm_creadat);

/*t_conduite*/
--update t_conduite set cd_statut = null ;
--update t_conduite set cd_r1_code = null ;
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'OR033001002022' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'OR033001002022' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);

update t_conduite set cd_type = (case
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_compo like '%PVC%') then 'PVC' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_compo like '%PEHD%') then 'PEHD' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_typ_imp='0' or cm_typ_imp='1' or cm_typ_imp='2') then 'AER' 
when cd_avct='E' then 'NC'
end);

update t_conduite set cd_dia_ext = substr((select cm_compo from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code),instr((select cm_compo from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code),'/')+1)
	where cd_type ='PVC' or cd_type='PEHD';

update t_conduite set cd_proptyp=null;
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;


/*t_zpbo*/
update t_zpbo set zp_r3_code=zp_r2_code || '_0' || substr(zp_code,6,2);
--update t_zpbo set zp_capamax= (case 
--								when zp_capamax =1 then 2
--								when zp_capamax =2 then 3
--								when (zp_capamax<=5 and zp_capamax >2) then 6
--								when (zp_capamax <=10 and zp_capamax >5) then 12
--								else zp_capamax
--							end);
update t_zpbo set zp_creadat=datetime(zp_creadat);

/*t_zsro*/
update t_zsro set zs_r3_code=zs_r2_code || '_0' || substr(zs_code,6,2);
update t_zsro set zs_refpm='ES-TEC-'||zs_r2_code||substr(zs_code,6,2);
update t_zsro set zs_nblogmt=null;
update t_zsro set zs_nbcolmt=null;
update t_zsro set zs_creadat=datetime(zs_creadat);

/*t_znro*/
update t_znro set  zn_r4_code =null;
update t_znro set zn_creadat=datetime(zn_creadat);

/*t_cable*/
update t_cable set cb_capafo=2, cb_modulo=2, cb_fo_util=null, cb_fo_disp=null where (cb_typelog='RA');
update t_cable set cb_r3_code=cb_r2_code || '_0' || substr(cb_code,6,2);
update t_cable set cb_r4_code=null;
update t_cable set cb_creadat=datetime(cb_creadat);

/*t_ebp*/
delete from t_ebp where bp_typelog in ('NRO','SRO');
update t_ebp set bp_ca_nb=null;
update t_ebp set bp_creadat=datetime(bp_creadat);

/* t_cable_patch201 */
update t_cable_patch201 set cb_bp1 = null where cb_bp1 not in (select bp_code from t_ebp);
update t_cable_patch201 set cb_bp2 = null where cb_bp2 not in (select bp_code from t_ebp);


/* t_ltech */
--update t_ltech set lt_statut = (select bp_statut from t_ebp where bp_lt_code = lt_code) where lt_codeext not like 'ES-BP%';
--update t_ltech set lt_statut ='AVP' where lt_codeext like 'ES-BP%'; --statut pour les SRO et NRO
--update t_ltech set lt_statut='AVP';
update t_ltech set lt_creadat=datetime(lt_creadat);


/* t_sitetech */
update t_sitetech set st_prop='OR91000000000001' where st_typelog='SRO' or  st_typelog='NRO' ;
update t_sitetech set st_prop=null where st_typelog='CLIENT';
update t_sitetech set st_statut = (select lt_statut from t_ltech where lt_st_code = st_code );
update t_sitetech set st_etat=null;
update t_sitetech set st_nom =null where st_nom ='PBO_imm';
update t_sitetech set st_creadat=datetime(st_creadat);

/* t_ptech */
update t_ptech set pt_typelog = 'T' where pt_code not in (select bp_pt_code from t_ebp where bp_typelog in ('PBO'));
update t_ptech set pt_typelog = 'R' where pt_code in (select bp_pt_code from t_ebp where bp_typelog in ('PBR','PBO','PRE'));

update t_ptech set pt_creadat=datetime(pt_creadat);
update t_organisme set or_creadat=datetime(or_creadat);
update t_reference set rf_creadat=datetime(rf_creadat);
update t_suf set sf_creadat=datetime(sf_creadat);


end transaction;