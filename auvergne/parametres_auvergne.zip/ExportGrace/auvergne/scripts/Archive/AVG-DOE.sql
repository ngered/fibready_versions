﻿begin transaction;
create view baie as select ba_code as ba_code,ba_codeext as ba_codeext, ba_lt_code as ba_lt_code, ba_statut as ba_statut, ba_rf_code as ba_ref from t_baie ;
insert into t_baie(ba_code,ba_codeext,ba_etiquet, ba_lt_code, ba_prop, ba_gest, ba_proptyp, ba_statut, ba_rf_code, ba_type) 
                select substr(ba_code,1,13)||'2',ba_codeext,'1', ba_lt_code, 'OR033001002022','OR033001001506', 'CST', ba_statut,ba_ref,'BAIE' from baie;
drop view baie;
end transaction;

begin transaction;

/* maj Orange */
update t_cable set cb_prop='OR033001001581' where cb_prop='OR91000000000003';
update t_ebp set bp_prop='OR033001001581' where bp_prop='OR91000000000003';
update t_ptech set pt_prop='OR033001001581' where pt_prop='OR91000000000003';
update t_ltech set lt_prop='OR033001001581' where lt_prop='OR91000000000003';
update t_sitetech set st_prop='OR033001001581' where st_prop='OR91000000000003';

/* maj enedis */
update t_cable set cb_prop='OR033002000000' where cb_prop='OR91000000000004';
update t_ebp set bp_prop='OR033002000000' where bp_prop='OR91000000000004';
update t_ptech set pt_prop='OR033002000000' where pt_prop='OR91000000000004';
update t_ltech set lt_prop='OR033002000000' where lt_prop='OR91000000000004';
update t_sitetech set st_prop='OR033002000000' where st_prop='OR91000000000004';

/*maj RAUV*/
update t_cable set cb_prop='OR033001001714' where cb_prop='OR91000000000001';
update t_ebp set bp_prop='OR033001001714' where bp_prop='OR91000000000001';
update t_ptech set pt_prop='OR033001001714' where pt_prop='OR91000000000001';
update t_ltech set lt_prop='OR033001001714' where lt_prop='OR91000000000001';
update t_sitetech set st_prop='OR033001001714' where st_prop='OR91000000000001';

/*maj ATHD*/
update t_cable set cb_prop='OR033001000259' where cb_prop='OR91000000000002';
update t_ebp set bp_prop='OR033001000259' where bp_prop='OR91000000000002';
update t_ptech set pt_prop='OR033001000259' where pt_prop='OR91000000000002';
update t_ltech set lt_prop='OR033001000259' where lt_prop='OR91000000000002';
update t_sitetech set st_prop='OR033001000259' where st_prop='OR91000000000002';


/*maj TIERS*/
update t_cable set cb_prop='OR000000000000' where cb_prop='OR91000000000006' ;
update t_ebp set bp_prop='OR000000000000' where bp_prop='OR91000000000006' ;
update t_ptech set pt_prop='OR000000000000' where pt_prop='OR91000000000006' ;
update t_ltech set lt_prop='OR000000000000' where lt_prop='OR91000000000006' ;
update t_sitetech set st_prop='OR000000000000' where st_prop='OR91000000000006';


/* gest */
update t_ptech set pt_gest=pt_prop;
update t_cable set cb_gest=cb_prop;


/* etiquettes */
update t_ltech set lt_etiquet = lt_codeext;
update t_ltech set lt_codeext = null;
update t_ptech set pt_etiquet = pt_codeext;
update t_ptech set pt_codeext =null;
update t_ebp set bp_etiquet = bp_codeext;
update t_ebp set bp_codeext = null;
update t_cable set cb_etiquet = cb_codeext;



/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_ban_id=null;
update t_adresse set ad_y_ban=null;
update t_adresse set ad_x_ban=null;
update t_adresse set ad_prio = '0';
update t_adresse set ad_ietat = 'CI';
update t_adresse set ad_racc = '7' where ad_racc = '' ;
update t_adresse set ad_iaccgst = '0' where ad_itypeim  = '' ;
update t_adresse set ad_itypeim  = 'P' where ad_itypeim  = '' ;
update t_adresse set ad_rep=null where ad_rep like 'NEW%';
update t_adresse set ad_gest='OR000000000000' where ad_itypeim='I'; 
update t_adresse set ad_imneuf=1 where ad_nblhab + ad_nblpro = 0; 
--Insérer nb_pr_ftte dans ad_comment
update t_adresse set ad_comment=(select nb_pr_ftte from IMPORT_BAL where ad_batcode=noe_codext);
update t_adresse set ad_comment=null where ad_comment=0;

/* batcode NRO */
update t_adresse set ad_batcode= 'NA24NGE1300000000' where ad_batcode = 'NA_24585_CESI' ;
update t_adresse set ad_batcode= 'NA24NGE1400000000' where ad_batcode = 'NA_24035_FERI' ;
update t_adresse set ad_batcode= 'NA24NGE1500000000' where ad_batcode = 'NA_24150_CETE' ;
update t_adresse set ad_batcode= 'NA24NGE1700000000' where ad_batcode = 'NA_24081_GERI' ;
update t_adresse set ad_batcode= 'NA24NGE1800000000' where ad_batcode = 'SHL_24520_SARL';
update t_adresse set ad_batcode= 'NA24NGE1900000000' where ad_batcode = 'NA_24516_CETO' ;
update t_adresse set ad_batcode= 'NA24NGE2300000000' where ad_batcode = 'NA_24550_CEXI' ;
update t_adresse set ad_batcode= 'NA24NGE4600000000' where ad_batcode = 'NA_24067_FERA' ;
update t_adresse set ad_batcode= 'NA24NGE4800000000' where ad_batcode = 'NA_24356_TANA' ;
update t_adresse set ad_batcode= 'NA24NGE5600000000' where ad_batcode = 'NA_24396_ROTO' ;
update t_adresse set ad_batcode= 'NA24NGE3600000000' where ad_batcode = 'NA_24068_DEFI' ;
update t_adresse set ad_batcode= 'NA24NGE4700000000' where ad_batcode = 'NA_24362_TANE' ;
update t_adresse set ad_batcode= 'NA24NGE1200000000' where ad_batcode = 'NA_24257_CERU' ;

/* batcode SRO */
--13
update t_adresse set ad_batcode= 'NA24NGE1301000000' where ad_batcode = 'NA_24386_BAWE' ;
update t_adresse set ad_batcode= 'NA24NGE1302000000' where ad_batcode = 'NA_24039_BAWO' ;
update t_adresse set ad_batcode= 'NA24NGE1303000000' where ad_batcode = 'NA_24585_BAWI' ;
update t_adresse set ad_batcode= 'NA24NGE1304000000' where ad_batcode = 'NA_24585_BAWA' ;
update t_adresse set ad_batcode= 'NA24NGE1305000000' where ad_batcode = 'NA_24585_BAWU' ;
--14
update t_adresse set ad_batcode= 'NA24NGE1401000000' where ad_batcode = 'NA_24035_BAZE' ;
update t_adresse set ad_batcode= 'NA24NGE1402000000' where ad_batcode = 'NA_24293_BAXO' ;
update t_adresse set ad_batcode= 'NA24NGE1403000000' where ad_batcode = 'NA_24360_BAWY' ;
update t_adresse set ad_batcode= 'NA24NGE1404000000' where ad_batcode = 'NA_24538_BAZY' ;
update t_adresse set ad_batcode= 'NA24NGE1405000000' where ad_batcode = 'NA_24538_BAXU' ;
update t_adresse set ad_batcode= 'NA24NGE1406000000' where ad_batcode = 'NA_24478_BAXA' ;
update t_adresse set ad_batcode= 'NA24NGE1407000000' where ad_batcode = 'NA_24035_BAZO' ;
update t_adresse set ad_batcode= 'NA24NGE1408000000' where ad_batcode = 'NA_24035_BAXE' ;
update t_adresse set ad_batcode= 'NA24NGE1409000000' where ad_batcode = 'NA_24035_BAXI' ;
update t_adresse set ad_batcode= 'NA24NGE1410000000' where ad_batcode = 'NA_24438_BAXY' ;
--15
update t_adresse set ad_batcode= 'NA24NGE1501000000' where ad_batcode = 'NA_24063_BECE' ;
update t_adresse set ad_batcode= 'NA24NGE1502000000' where ad_batcode = 'NA_24488_BEDA' ;
update t_adresse set ad_batcode= 'NA24NGE1503000000' where ad_batcode = 'NA_24150_BEBE' ;
update t_adresse set ad_batcode= 'NA24NGE1504000000' where ad_batcode = 'NA_24300_BEBI' ;
update t_adresse set ad_batcode= 'NA24NGE1505000000' where ad_batcode = 'NA_24450_BEBU' ;
update t_adresse set ad_batcode= 'NA24NGE1506000000' where ad_batcode = 'NA_24152_BECA' ;
update t_adresse set ad_batcode= 'NA24NGE1507000000' where ad_batcode = 'NA_24091_BECI' ;
update t_adresse set ad_batcode= 'NA24NGE1508000000' where ad_batcode = 'NA_24152_BEBO' ;
update t_adresse set ad_batcode= 'NA24NGE1509000000' where ad_batcode = 'NA_24091_BECU' ;
update t_adresse set ad_batcode= 'NA24NGE1510000000' where ad_batcode = 'NA_24091_BECO' ;
update t_adresse set ad_batcode= 'NA24NGE1511000000' where ad_batcode = 'NA_24395_BEBY' ;
--17
update t_adresse set ad_batcode= 'NA24NGE1701000000' where ad_batcode = 'NA_24089_BEHY' ;
update t_adresse set ad_batcode= 'NA24NGE1702000000' where ad_batcode = 'NA_24081_BEHU' ;
update t_adresse set ad_batcode= 'NA24NGE1703000000' where ad_batcode = 'NA_24432_BEHO' ;
update t_adresse set ad_batcode= 'NA24NGE1704000000' where ad_batcode = 'NA_24574_BEJE' ;
update t_adresse set ad_batcode= 'NA24NGE1705000000' where ad_batcode = 'NA_24207_BEKI' ;
update t_adresse set ad_batcode= 'NA24NGE1706000000' where ad_batcode = 'NA_24574_BEKA' ;
update t_adresse set ad_batcode= 'NA24NGE1707000000' where ad_batcode = 'NA_24082_BEHE' ;
update t_adresse set ad_batcode= 'NA24NGE1708000000' where ad_batcode = 'NA_24082_BEJY' ;
update t_adresse set ad_batcode= 'NA24NGE1709000000' where ad_batcode = 'NA_24471_BEJI' ;
update t_adresse set ad_batcode= 'NA24NGE1710000000' where ad_batcode = 'NA_24082_BEKE' ;
update t_adresse set ad_batcode= 'NA24NGE1711000000' where ad_batcode = 'NA_24512_BEJO' ;
update t_adresse set ad_batcode= 'NA24NGE1712000000' where ad_batcode = 'NA_24074_BEJA' ;
update t_adresse set ad_batcode= 'NA24NGE1713000000' where ad_batcode = 'NA_24081_BEHA' ;
update t_adresse set ad_batcode= 'NA24NGE1714000000' where ad_batcode = 'NA_24081_BEJU' ;
--18
update t_adresse set ad_batcode= 'NA24NGE1827000000' where ad_batcode = 'NA_24086_BOMA' ;
update t_adresse set ad_batcode= 'NA24NGE1828000000' where ad_batcode = 'NA_24577_BOLU' ;
update t_adresse set ad_batcode= 'NA24NGE1829000000' where ad_batcode = 'NA_24587_BOLI' ;
update t_adresse set ad_batcode= 'NA24NGE1830000000' where ad_batcode = 'NA_24587_BOME' ;
update t_adresse set ad_batcode= 'NA24NGE1831000000' where ad_batcode = 'NA_24355_BOLO' ;
--19
update t_adresse set ad_batcode= 'NA24NGE1901000000' where ad_batcode = 'NA_24050_BELO' ;
update t_adresse set ad_batcode= 'NA24NGE1902000000' where ad_batcode = 'NA_24516_BEKY' ;
update t_adresse set ad_batcode= 'NA24NGE1903000000' where ad_batcode = 'NA_24341_BELA' ;
update t_adresse set ad_batcode= 'NA24NGE1904000000' where ad_batcode = 'NA_24392_BELU' ;
update t_adresse set ad_batcode= 'NA24NGE1905000000' where ad_batcode = 'NA_24412_BELI' ;
update t_adresse set ad_batcode= 'NA24NGE1906000000' where ad_batcode = 'NA_24215_BEME' ;
update t_adresse set ad_batcode= 'NA24NGE1907000000' where ad_batcode = 'NA_24412_BELE' ;
update t_adresse set ad_batcode= 'NA24NGE1908000000' where ad_batcode = 'NA_24317_BELY' ;
update t_adresse set ad_batcode= 'NA24NGE1909000000' where ad_batcode = 'NA_24516_BEMA' ;
update t_adresse set ad_batcode= 'NA24NGE1910000000' where ad_batcode = 'NA_24516_BEKU' ;
--23
update t_adresse set ad_batcode= 'NA24NGE2301000000' where ad_batcode = 'NA_24473_BENA' ;
update t_adresse set ad_batcode= 'NA24NGE2302000000' where ad_batcode = 'NA_24491_BEMY' ;
update t_adresse set ad_batcode= 'NA24NGE2303000000' where ad_batcode = 'NA_24324_BEPI' ;
update t_adresse set ad_batcode= 'NA24NGE2304000000' where ad_batcode = 'NA_24020_BEPA' ;
update t_adresse set ad_batcode= 'NA24NGE2305000000' where ad_batcode = 'NA_24241_BENY' ;
update t_adresse set ad_batcode= 'NA24NGE2306000000' where ad_batcode = 'NA_24188_BENE' ;
update t_adresse set ad_batcode= 'NA24NGE2307000000' where ad_batcode = 'NA_24550_BEMI' ;
update t_adresse set ad_batcode= 'NA24NGE2308000000' where ad_batcode = 'NA_24019_BENO' ;
update t_adresse set ad_batcode= 'NA24NGE2309000000' where ad_batcode = 'NA_24018_BENU' ;
update t_adresse set ad_batcode= 'NA24NGE2310000000' where ad_batcode = 'NA_24550_BENI' ;
update t_adresse set ad_batcode= 'NA24NGE2311000000' where ad_batcode = 'NA_24550_BEMO' ;
update t_adresse set ad_batcode= 'NA24NGE2313000000' where ad_batcode = 'NA_24550_BEPE' ;
--46
update t_adresse set ad_batcode= 'NA24NGE4601000000' where ad_batcode = 'NA_24558_BIWU' ;
update t_adresse set ad_batcode= 'NA24NGE4602000000' where ad_batcode = 'NA_24240_BIWA' ;
update t_adresse set ad_batcode= 'NA24NGE4603000000' where ad_batcode = 'NA_24015_BIWO' ;
update t_adresse set ad_batcode= 'NA24NGE4604000000' where ad_batcode = 'NA_24067_BIWE' ;
update t_adresse set ad_batcode= 'NA24NGE4605000000' where ad_batcode = 'NA_24067_BIVE' ;
update t_adresse set ad_batcode= 'NA24NGE4606000000' where ad_batcode = 'NA_24240_BIVA' ;
update t_adresse set ad_batcode= 'NA24NGE4607000000' where ad_batcode = 'NA_24076_BIWI' ;
update t_adresse set ad_batcode= 'NA24NGE4608000000' where ad_batcode = 'NA_24067_BITY' ;
update t_adresse set ad_batcode= 'NA24NGE4609000000' where ad_batcode = 'NA_24067_BIVU' ;
update t_adresse set ad_batcode= 'NA24NGE4610000000' where ad_batcode = 'NA_24067_BIVI' ;
update t_adresse set ad_batcode= 'NA24NGE4611000000' where ad_batcode = 'NA_24067_BIVY' ;
update t_adresse set ad_batcode= 'NA24NGE4612000000' where ad_batcode = 'NA_24067_BIWY' ;
--48
update t_adresse set ad_batcode= 'NA24NGE4802000000' where ad_batcode = 'NA_24217_BOBA' ;
update t_adresse set ad_batcode= 'NA24NGE4803000000' where ad_batcode = 'NA_24356_BIZO' ;
update t_adresse set ad_batcode= 'NA24NGE4804000000' where ad_batcode = 'NA_24356_BIZA' ;
update t_adresse set ad_batcode= 'NA24NGE4805000000' where ad_batcode = 'NA_24356_BIZU' ;
update t_adresse set ad_batcode= 'NA24NGE4806000000' where ad_batcode = 'NA_24330_BIZE' ;
update t_adresse set ad_batcode= 'NA24NGE4807000000' where ad_batcode = 'NA_24330_BIZY' ;
update t_adresse set ad_batcode= 'NA24NGE4808000000' where ad_batcode = 'NA_24261_BOBE' ;
update t_adresse set ad_batcode= 'NA24NGE4809000000' where ad_batcode = 'NA_24261_BIZI' ;
--56
update t_adresse set ad_batcode= 'NA24NGE5601000000' where ad_batcode = 'NA_24036_BONY' ;
update t_adresse set ad_batcode= 'NA24NGE5602000000' where ad_batcode = 'NA_24006_BOPO' ;
update t_adresse set ad_batcode= 'NA24NGE5603000000' where ad_batcode = 'NA_24006_BOPI' ;
update t_adresse set ad_batcode= 'NA24NGE5604000000' where ad_batcode = 'NA_24510_BOPE' ;
update t_adresse set ad_batcode= 'NA24NGE5605000000' where ad_batcode = 'NA_24087_BONA' ;
update t_adresse set ad_batcode= 'NA24NGE5606000000' where ad_batcode = 'NA_24142_BOPA' ;
update t_adresse set ad_batcode= 'NA24NGE5607000000' where ad_batcode = 'NA_24142_BONO' ;
update t_adresse set ad_batcode= 'NA24NGE5608000000' where ad_batcode = 'NA_24142_BONI' ;
update t_adresse set ad_batcode= 'NA24NGE5608000000' where ad_batcode = 'NA_24268_BONE' ;
update t_adresse set ad_batcode= 'NA24NGE5610000000' where ad_batcode = 'NA_24396_BOMY' ;
update t_adresse set ad_batcode= 'NA24NGE5611000000' where ad_batcode = 'NA_24396_BONU' ;
update t_adresse set ad_batcode= 'NA24NGE5612000000' where ad_batcode = 'NA_24396_BOMU' ;
update t_adresse set ad_batcode= 'NA24NGE5613000000' where ad_batcode = 'NA_24396_BOMO' ;
update t_adresse set ad_batcode= 'NA24NGE5614000000' where ad_batcode = 'NA_24396_BOMI' ;


/*t_ebp*/
update t_ebp set bp_gest = bp_prop ;
update t_ebp set bp_proptyp = 'CST';
update t_ebp set bp_ca_nb = null;
update t_ebp set bp_avct='S' where bp_statut='REC';
update t_ebp set bp_etiquet = 'OO-XXXX-XXXX' where bp_typelog='PTO'; 


/*t_ptech*/
update t_ptech set pt_a_haut = '8' where pt_typephy = 'A';
update t_ptech set pt_a_haut = null where pt_avct = 'E';
update t_ptech set pt_secu = '0' where pt_avct = 'C' and pt_typephy = 'C';
update t_ptech set pt_avct='S' where pt_statut='REC';

/*t_ltech*/
update t_ltech set lt_prop ='OR033001002022';
update t_ltech set lt_gest ='OR033001002022';
update t_ltech set lt_proptyp ='CST';

update t_ltech set lt_elec= (case
	when (select st_typelog from t_sitetech where st_code=lt_st_code)='NRO' then 1
	else 0 end);

update t_ltech set lt_clim = 'SANS' where lt_st_code in (select st_code from t_sitetech where st_typelog='SRO');
update t_ltech set lt_clim = 'CLIM' where lt_st_code in (select st_code from t_sitetech where st_typelog='NRO');
update t_ltech set lt_clim = 'SANS' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_etiquet = 'LT_VERTICALITE' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_prop = 'OR000000000000' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_gest = 'OR000000000000' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');

/*t_sitetech*/
--update t_sitetech set st_statut='REC';
--sro/nro
update t_sitetech set st_prop ='OR033001002022' where st_typelog in ('NRO','SRO');
update t_sitetech set st_gest ='OR033001002022' where st_typelog in ('NRO','SRO');
update t_sitetech set st_proptyp ='CST' where st_typelog in ('NRO','SRO');
update t_sitetech set st_nom =st_codeext where st_typelog in ('NRO','SRO');
--immeubles 
update t_sitetech set st_prop ='OR000000000000' where st_typelog = 'CLIENT';
update t_sitetech set st_gest ='OR000000000000' where st_typelog = 'CLIENT';
update t_sitetech set st_proptyp ='OCC' where st_typelog = 'CLIENT';
update t_sitetech set st_nom =(select ad_batcode from t_adresse where st_ad_code = ad_code) where st_typelog ='CLIENT';--David
--
update t_sitetech set st_avct='S' where st_statut='REC';

update t_ltech set lt_statut=(select st_statut from t_sitetech where st_code=lt_st_code); 


/*t_noeud */
update t_noeud set nd_geolqlt=null;
update t_noeud set nd_codeext=null;

update t_noeud set nd_r1_code='24';
/* r2_code */
update t_noeud set nd_r2_code='NA_24585_CESI' where nd_r2_code='13';
update t_noeud set nd_r2_code='NA_24035_FERI' where nd_r2_code='14';
update t_noeud set nd_r2_code='NA_24150_CETE' where nd_r2_code='15';
update t_noeud set nd_r2_code='NA_24081_GERI' where nd_r2_code='17';
update t_noeud set nd_r2_code='SHL_24520_SARL' where nd_r2_code='18';
update t_noeud set nd_r2_code='NA_24516_CETO' where nd_r2_code='19';
update t_noeud set nd_r2_code='NA_24550_CEXI' where nd_r2_code='23';
update t_noeud set nd_r2_code='NA_24067_FERA' where nd_r2_code='46';
update t_noeud set nd_r2_code='NA_24356_TANA' where nd_r2_code='48';
update t_noeud set nd_r2_code='NA_24396_ROTO' where nd_r2_code='56';
/* r3_code */
--13
update t_noeud set nd_r3_code='NA_24386_BAWE' where nd_r2_code='NA_24585_CESI' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24039_BAWO' where nd_r2_code='NA_24585_CESI' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24585_BAWI' where nd_r2_code='NA_24585_CESI' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24585_BAWA' where nd_r2_code='NA_24585_CESI' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24585_BAWU' where nd_r2_code='NA_24585_CESI' and nd_r3_code='05';
--14
update t_noeud set nd_r3_code='NA_24035_BAZE' where nd_r2_code='NA_24035_FERI' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24293_BAXO' where nd_r2_code='NA_24035_FERI' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24360_BAWY' where nd_r2_code='NA_24035_FERI' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24538_BAZY' where nd_r2_code='NA_24035_FERI' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24538_BAXU' where nd_r2_code='NA_24035_FERI' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24478_BAXA' where nd_r2_code='NA_24035_FERI' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24035_BAZO' where nd_r2_code='NA_24035_FERI' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24035_BAXE' where nd_r2_code='NA_24035_FERI' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24035_BAXI' where nd_r2_code='NA_24035_FERI' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24438_BAXY' where nd_r2_code='NA_24035_FERI' and nd_r3_code='10';
--15
update t_noeud set nd_r3_code='NA_24063_BECE' where nd_r2_code='NA_24150_CETE' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24488_BEDA' where nd_r2_code='NA_24150_CETE' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24150_BEBE' where nd_r2_code='NA_24150_CETE' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24300_BEBI' where nd_r2_code='NA_24150_CETE' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24450_BEBU' where nd_r2_code='NA_24150_CETE' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24152_BECA' where nd_r2_code='NA_24150_CETE' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24091_BECI' where nd_r2_code='NA_24150_CETE' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24152_BEBO' where nd_r2_code='NA_24150_CETE' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24091_BECU' where nd_r2_code='NA_24150_CETE' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24091_BECO' where nd_r2_code='NA_24150_CETE' and nd_r3_code='10';
update t_noeud set nd_r3_code='NA_24395_BEBY' where nd_r2_code='NA_24150_CETE' and nd_r3_code='11';
--17
update t_noeud set nd_r3_code='NA_24089_BEHY' where nd_r2_code='NA_24081_GERI' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24081_BEHU' where nd_r2_code='NA_24081_GERI' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24432_BEHO' where nd_r2_code='NA_24081_GERI' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24574_BEJE' where nd_r2_code='NA_24081_GERI' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24207_BEKI' where nd_r2_code='NA_24081_GERI' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24574_BEKA' where nd_r2_code='NA_24081_GERI' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24082_BEHE' where nd_r2_code='NA_24081_GERI' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24082_BEJY' where nd_r2_code='NA_24081_GERI' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24471_BEJI' where nd_r2_code='NA_24081_GERI' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24082_BEKE' where nd_r2_code='NA_24081_GERI' and nd_r3_code='10';
update t_noeud set nd_r3_code='NA_24512_BEJO' where nd_r2_code='NA_24081_GERI' and nd_r3_code='11';
update t_noeud set nd_r3_code='NA_24074_BEJA' where nd_r2_code='NA_24081_GERI' and nd_r3_code='12';
update t_noeud set nd_r3_code='NA_24081_BEHA' where nd_r2_code='NA_24081_GERI' and nd_r3_code='13';
update t_noeud set nd_r3_code='NA_24081_BEJU' where nd_r2_code='NA_24081_GERI' and nd_r3_code='14';
--18
update t_noeud set nd_r3_code='NA_24086_BOMA' where nd_r2_code='SHL_24520_SARL' and nd_r3_code='27';
update t_noeud set nd_r3_code='NA_24577_BOLU' where nd_r2_code='SHL_24520_SARL' and nd_r3_code='28';
update t_noeud set nd_r3_code='NA_24587_BOLI' where nd_r2_code='SHL_24520_SARL' and nd_r3_code='29';
update t_noeud set nd_r3_code='NA_24587_BOME' where nd_r2_code='SHL_24520_SARL' and nd_r3_code='30';
update t_noeud set nd_r3_code='NA_24355_BOLO' where nd_r2_code='SHL_24520_SARL' and nd_r3_code='31';
--19
update t_noeud set nd_r3_code='NA_24050_BELO' where nd_r2_code='NA_24516_CETO' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24516_BEKY' where nd_r2_code='NA_24516_CETO' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24341_BELA' where nd_r2_code='NA_24516_CETO' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24392_BELU' where nd_r2_code='NA_24516_CETO' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24412_BELI' where nd_r2_code='NA_24516_CETO' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24215_BEME' where nd_r2_code='NA_24516_CETO' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24412_BELE' where nd_r2_code='NA_24516_CETO' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24317_BELY' where nd_r2_code='NA_24516_CETO' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24516_BEMA' where nd_r2_code='NA_24516_CETO' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24516_BEKU' where nd_r2_code='NA_24516_CETO' and nd_r3_code='10';
--23
update t_noeud set nd_r3_code='NA_24473_BENA' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24491_BEMY' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24324_BEPI' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24020_BEPA' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24241_BENY' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24188_BENE' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24550_BEMI' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24019_BENO' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24018_BENU' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24550_BENI' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='10';
update t_noeud set nd_r3_code='NA_24550_BEMO' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='11';
update t_noeud set nd_r3_code='NA_24550_BEPE' where nd_r2_code='NA_24550_CEXI' and nd_r3_code='13';
--46
update t_noeud set nd_r3_code='NA_24558_BIWU' where nd_r2_code='NA_24067_FERA' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24240_BIWA' where nd_r2_code='NA_24067_FERA' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24015_BIWO' where nd_r2_code='NA_24067_FERA' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24067_BIWE' where nd_r2_code='NA_24067_FERA' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24067_BIVE' where nd_r2_code='NA_24067_FERA' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24240_BIVA' where nd_r2_code='NA_24067_FERA' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24076_BIWI' where nd_r2_code='NA_24067_FERA' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24067_BITY' where nd_r2_code='NA_24067_FERA' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24067_BIVU' where nd_r2_code='NA_24067_FERA' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24067_BIVI' where nd_r2_code='NA_24067_FERA' and nd_r3_code='10';
update t_noeud set nd_r3_code='NA_24067_BIVY' where nd_r2_code='NA_24067_FERA' and nd_r3_code='11';
update t_noeud set nd_r3_code='NA_24067_BIWY' where nd_r2_code='NA_24067_FERA' and nd_r3_code='12';
--48
update t_noeud set nd_r3_code='NA_24217_BOBA' where nd_r2_code='NA_24356_TANA' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24356_BIZO' where nd_r2_code='NA_24356_TANA' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24356_BIZA' where nd_r2_code='NA_24356_TANA' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24356_BIZU' where nd_r2_code='NA_24356_TANA' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24330_BIZE' where nd_r2_code='NA_24356_TANA' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24330_BIZY' where nd_r2_code='NA_24356_TANA' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24261_BOBE' where nd_r2_code='NA_24356_TANA' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24261_BIZI' where nd_r2_code='NA_24356_TANA' and nd_r3_code='09';
--56
update t_noeud set nd_r3_code='NA_24036_BONY' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='01';
update t_noeud set nd_r3_code='NA_24006_BOPO' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='02';
update t_noeud set nd_r3_code='NA_24006_BOPI' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='03';
update t_noeud set nd_r3_code='NA_24510_BOPE' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='04';
update t_noeud set nd_r3_code='NA_24087_BONA' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='05';
update t_noeud set nd_r3_code='NA_24142_BOPA' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='06';
update t_noeud set nd_r3_code='NA_24142_BONO' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='07';
update t_noeud set nd_r3_code='NA_24142_BONI' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='08';
update t_noeud set nd_r3_code='NA_24268_BONE' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='09';
update t_noeud set nd_r3_code='NA_24396_BOMY' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='10';
update t_noeud set nd_r3_code='NA_24396_BONU' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='11';
update t_noeud set nd_r3_code='NA_24396_BOMU' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='12';
update t_noeud set nd_r3_code='NA_24396_BOMO' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='13';
update t_noeud set nd_r3_code='NA_24396_BOMI' where nd_r2_code='NA_24396_ROTO' and nd_r3_code='14';
--TR
update t_noeud set nd_r3_code=NULL where nd_r3_code='00';


/*t_cableline*/
update t_cableline set cl_geolqlt=null;
delete from t_cableline where st_length (geom) = 0;
update t_cableline set cl_long = st_length (geom) where cl_long = 0;

/*t_cheminement*/
update t_cheminement set cm_r1_code = '24';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;

update t_cheminement set cm_gest_do = NULL;

update t_cheminement set cm_prop_do = (case 
when cm_prop_do = '24' then  'OR033001002022' 
when cm_prop_do = 'ORANGE' then 'OR033001001581'
when cm_prop_do = 'ENEDIS' then 'OR033002000000'
when cm_prop_do = 'PRIVE' then 'OR033002100041'
when cm_prop_do = 'RIP1G' then 'OR033001002022' 
end);

update t_cheminement set cm_charge = (case
	when cm_mod_pos = 'TRA' then '0.6'
	when cm_mod_pos = 'MIC' then '0.4'
	when cm_mod_pos = 'FON' then '0.8'
end); 
update t_cheminement set cm_etat=null;
update t_cheminement set cm_avct='S' where cm_avct='C' and cm_statut='REC';

/* t_znro */
update t_znro set zn_nrotype = 'PON';
update t_znro set zn_etat = 'DP';

--r2
update t_znro set zn_r2_code='NA_24585_CESI' where zn_r2_code='13';
update t_znro set zn_r2_code='NA_24035_FERI' where zn_r2_code='14';
update t_znro set zn_r2_code='NA_24150_CETE' where zn_r2_code='15';
update t_znro set zn_r2_code='NA_24081_GERI' where zn_r2_code='17';
update t_znro set zn_r2_code='SHL_24520_SARL' where zn_r2_code='18';
update t_znro set zn_r2_code='NA_24516_CETO' where zn_r2_code='19';
update t_znro set zn_r2_code='NA_24550_CEXI' where zn_r2_code='23';
update t_znro set zn_r2_code='NA_24067_FERA' where zn_r2_code='46';
update t_znro set zn_r2_code='NA_24356_TANA' where zn_r2_code='48';
update t_znro set zn_r2_code='NA_24396_ROTO' where zn_r2_code='56';

/*t_zsro*/
/*update t_zsro set zs_capamax=null;*/
/*update t_zsro set zs_nblogmt=null;*/
update t_zsro set zs_nblogmt=(select count(sf_code) from t_suf);
update t_zsro set zs_capamax = (case
	when zs_nblogmt <  499 then '499'
	when zs_nblogmt > 499 then '720'
end);
update t_zsro set zs_etatpm = 'EC';
update t_zsro set zs_typeemp = 'ADR';
update t_zsro set zs_typeing = 'mono';
update t_zsro set zs_actif = '0';
update t_zsro set zs_r1_code = '24';
update t_zsro set zs_r2_code='NA_24585_CESI' where zs_r2_code='13';
update t_zsro set zs_r2_code='NA_24035_FERI' where zs_r2_code='14';
update t_zsro set zs_r2_code='NA_24150_CETE' where zs_r2_code='15';
update t_zsro set zs_r2_code='NA_24081_GERI' where zs_r2_code='17';
update t_zsro set zs_r2_code='SHL_24520_SARL' where zs_r2_code='18';
update t_zsro set zs_r2_code='NA_24516_CETO' where zs_r2_code='19';
update t_zsro set zs_r2_code='NA_24550_CEXI' where zs_r2_code='23';
update t_zsro set zs_r2_code='NA_24067_FERA' where zs_r2_code='46';
update t_zsro set zs_r2_code='NA_24356_TANA' where zs_r2_code='48';
update t_zsro set zs_r2_code='NA_24396_ROTO' where zs_r2_code='56';
--update t_zsro set zs_r3_code = zs_refpm;
/* r3_code */
--13
update t_zsro set zs_r3_code='NA_24386_BAWE' where zs_r2_code='NA_24585_CESI' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24039_BAWO' where zs_r2_code='NA_24585_CESI' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24585_BAWI' where zs_r2_code='NA_24585_CESI' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24585_BAWA' where zs_r2_code='NA_24585_CESI' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24585_BAWU' where zs_r2_code='NA_24585_CESI' and zs_r3_code='05';
--14
update t_zsro set zs_r3_code='NA_24035_BAZE' where zs_r2_code='NA_24035_FERI' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24293_BAXO' where zs_r2_code='NA_24035_FERI' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24360_BAWY' where zs_r2_code='NA_24035_FERI' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24538_BAZY' where zs_r2_code='NA_24035_FERI' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24538_BAXU' where zs_r2_code='NA_24035_FERI' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24478_BAXA' where zs_r2_code='NA_24035_FERI' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24035_BAZO' where zs_r2_code='NA_24035_FERI' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24035_BAXE' where zs_r2_code='NA_24035_FERI' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24035_BAXI' where zs_r2_code='NA_24035_FERI' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24438_BAXY' where zs_r2_code='NA_24035_FERI' and zs_r3_code='10';
--15
update t_zsro set zs_r3_code='NA_24063_BECE' where zs_r2_code='NA_24150_CETE' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24488_BEDA' where zs_r2_code='NA_24150_CETE' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24150_BEBE' where zs_r2_code='NA_24150_CETE' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24300_BEBI' where zs_r2_code='NA_24150_CETE' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24450_BEBU' where zs_r2_code='NA_24150_CETE' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24152_BECA' where zs_r2_code='NA_24150_CETE' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24091_BECI' where zs_r2_code='NA_24150_CETE' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24152_BEBO' where zs_r2_code='NA_24150_CETE' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24091_BECU' where zs_r2_code='NA_24150_CETE' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24091_BECO' where zs_r2_code='NA_24150_CETE' and zs_r3_code='10';
update t_zsro set zs_r3_code='NA_24395_BEBY' where zs_r2_code='NA_24150_CETE' and zs_r3_code='11';
--17
update t_zsro set zs_r3_code='NA_24089_BEHY' where zs_r2_code='NA_24081_GERI' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24081_BEHU' where zs_r2_code='NA_24081_GERI' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24432_BEHO' where zs_r2_code='NA_24081_GERI' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24574_BEJE' where zs_r2_code='NA_24081_GERI' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24207_BEKI' where zs_r2_code='NA_24081_GERI' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24574_BEKA' where zs_r2_code='NA_24081_GERI' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24082_BEHE' where zs_r2_code='NA_24081_GERI' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24082_BEJY' where zs_r2_code='NA_24081_GERI' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24471_BEJI' where zs_r2_code='NA_24081_GERI' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24082_BEKE' where zs_r2_code='NA_24081_GERI' and zs_r3_code='10';
update t_zsro set zs_r3_code='NA_24512_BEJO' where zs_r2_code='NA_24081_GERI' and zs_r3_code='11';
update t_zsro set zs_r3_code='NA_24074_BEJA' where zs_r2_code='NA_24081_GERI' and zs_r3_code='12';
update t_zsro set zs_r3_code='NA_24081_BEHA' where zs_r2_code='NA_24081_GERI' and zs_r3_code='13';
update t_zsro set zs_r3_code='NA_24081_BEJU' where zs_r2_code='NA_24081_GERI' and zs_r3_code='14';
--18
update t_zsro set zs_r3_code='NA_24086_BOMA' where zs_r2_code='SHL_24520_SARL' and zs_r3_code='27';
update t_zsro set zs_r3_code='NA_24577_BOLU' where zs_r2_code='SHL_24520_SARL' and zs_r3_code='28';
update t_zsro set zs_r3_code='NA_24587_BOLI' where zs_r2_code='SHL_24520_SARL' and zs_r3_code='29';
update t_zsro set zs_r3_code='NA_24587_BOME' where zs_r2_code='SHL_24520_SARL' and zs_r3_code='30';
update t_zsro set zs_r3_code='NA_24355_BOLO' where zs_r2_code='SHL_24520_SARL' and zs_r3_code='31';
--19
update t_zsro set zs_r3_code='NA_24050_BELO' where zs_r2_code='NA_24516_CETO' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24516_BEKY' where zs_r2_code='NA_24516_CETO' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24341_BELA' where zs_r2_code='NA_24516_CETO' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24392_BELU' where zs_r2_code='NA_24516_CETO' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24412_BELI' where zs_r2_code='NA_24516_CETO' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24215_BEME' where zs_r2_code='NA_24516_CETO' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24412_BELE' where zs_r2_code='NA_24516_CETO' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24317_BELY' where zs_r2_code='NA_24516_CETO' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24516_BEMA' where zs_r2_code='NA_24516_CETO' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24516_BEKU' where zs_r2_code='NA_24516_CETO' and zs_r3_code='10';
--23
update t_zsro set zs_r3_code='NA_24473_BENA' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24491_BEMY' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24324_BEPI' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24020_BEPA' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24241_BENY' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24188_BENE' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24550_BEMI' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24019_BENO' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24018_BENU' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24550_BENI' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='10';
update t_zsro set zs_r3_code='NA_24550_BEMO' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='11';
update t_zsro set zs_r3_code='NA_24550_BEPE' where zs_r2_code='NA_24550_CEXI' and zs_r3_code='13';
--46
update t_zsro set zs_r3_code='NA_24558_BIWU' where zs_r2_code='NA_24067_FERA' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24240_BIWA' where zs_r2_code='NA_24067_FERA' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24015_BIWO' where zs_r2_code='NA_24067_FERA' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24067_BIWE' where zs_r2_code='NA_24067_FERA' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24067_BIVE' where zs_r2_code='NA_24067_FERA' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24240_BIVA' where zs_r2_code='NA_24067_FERA' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24076_BIWI' where zs_r2_code='NA_24067_FERA' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24067_BITY' where zs_r2_code='NA_24067_FERA' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24067_BIVU' where zs_r2_code='NA_24067_FERA' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24067_BIVI' where zs_r2_code='NA_24067_FERA' and zs_r3_code='10';
update t_zsro set zs_r3_code='NA_24067_BIVY' where zs_r2_code='NA_24067_FERA' and zs_r3_code='11';
update t_zsro set zs_r3_code='NA_24067_BIWY' where zs_r2_code='NA_24067_FERA' and zs_r3_code='12';
--48
update t_zsro set zs_r3_code='NA_24217_BOBA' where zs_r2_code='NA_24356_TANA' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24356_BIZO' where zs_r2_code='NA_24356_TANA' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24356_BIZA' where zs_r2_code='NA_24356_TANA' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24356_BIZU' where zs_r2_code='NA_24356_TANA' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24330_BIZE' where zs_r2_code='NA_24356_TANA' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24330_BIZY' where zs_r2_code='NA_24356_TANA' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24261_BOBE' where zs_r2_code='NA_24356_TANA' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24261_BIZI' where zs_r2_code='NA_24356_TANA' and zs_r3_code='09';
--56
update t_zsro set zs_r3_code='NA_24036_BONY' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='01';
update t_zsro set zs_r3_code='NA_24006_BOPO' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='02';
update t_zsro set zs_r3_code='NA_24006_BOPI' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='03';
update t_zsro set zs_r3_code='NA_24510_BOPE' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='04';
update t_zsro set zs_r3_code='NA_24087_BONA' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='05';
update t_zsro set zs_r3_code='NA_24142_BOPA' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='06';
update t_zsro set zs_r3_code='NA_24142_BONO' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='07';
update t_zsro set zs_r3_code='NA_24142_BONI' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='08';
update t_zsro set zs_r3_code='NA_24268_BONE' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='09';
update t_zsro set zs_r3_code='NA_24396_BOMY' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='10';
update t_zsro set zs_r3_code='NA_24396_BONU' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='11';
update t_zsro set zs_r3_code='NA_24396_BOMU' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='12';
update t_zsro set zs_r3_code='NA_24396_BOMO' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='13';
update t_zsro set zs_r3_code='NA_24396_BOMI' where zs_r2_code='NA_24396_ROTO' and zs_r3_code='14';



/* t_zpbo */
--r1
update t_zpbo set zp_r1_code = '24';
--r2
update t_zpbo set zp_r2_code='NA_24585_CESI' where zp_r2_code='13';
update t_zpbo set zp_r2_code='NA_24035_FERI' where zp_r2_code='14';
update t_zpbo set zp_r2_code='NA_24150_CETE' where zp_r2_code='15';
update t_zpbo set zp_r2_code='NA_24081_GERI' where zp_r2_code='17';
update t_zpbo set zp_r2_code='SHL_24520_SARL' where zp_r2_code='18';
update t_zpbo set zp_r2_code='NA_24516_CETO' where zp_r2_code='19';
update t_zpbo set zp_r2_code='NA_24550_CEXI' where zp_r2_code='23';
update t_zpbo set zp_r2_code='NA_24067_FERA' where zp_r2_code='46';
update t_zpbo set zp_r2_code='NA_24356_TANA' where zp_r2_code='48';
update t_zpbo set zp_r2_code='NA_24396_ROTO' where zp_r2_code='56';
--r3
--13
update t_zpbo set zp_r3_code='NA_24386_BAWE' where zp_r2_code='NA_24585_CESI' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24039_BAWO' where zp_r2_code='NA_24585_CESI' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24585_BAWI' where zp_r2_code='NA_24585_CESI' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24585_BAWA' where zp_r2_code='NA_24585_CESI' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24585_BAWU' where zp_r2_code='NA_24585_CESI' and zp_r3_code='05';
--14
update t_zpbo set zp_r3_code='NA_24035_BAZE' where zp_r2_code='NA_24035_FERI' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24293_BAXO' where zp_r2_code='NA_24035_FERI' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24360_BAWY' where zp_r2_code='NA_24035_FERI' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24538_BAZY' where zp_r2_code='NA_24035_FERI' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24538_BAXU' where zp_r2_code='NA_24035_FERI' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24478_BAXA' where zp_r2_code='NA_24035_FERI' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24035_BAZO' where zp_r2_code='NA_24035_FERI' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24035_BAXE' where zp_r2_code='NA_24035_FERI' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24035_BAXI' where zp_r2_code='NA_24035_FERI' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24438_BAXY' where zp_r2_code='NA_24035_FERI' and zp_r3_code='10';
--15
update t_zpbo set zp_r3_code='NA_24063_BECE' where zp_r2_code='NA_24150_CETE' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24488_BEDA' where zp_r2_code='NA_24150_CETE' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24150_BEBE' where zp_r2_code='NA_24150_CETE' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24300_BEBI' where zp_r2_code='NA_24150_CETE' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24450_BEBU' where zp_r2_code='NA_24150_CETE' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24152_BECA' where zp_r2_code='NA_24150_CETE' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24091_BECI' where zp_r2_code='NA_24150_CETE' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24152_BEBO' where zp_r2_code='NA_24150_CETE' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24091_BECU' where zp_r2_code='NA_24150_CETE' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24091_BECO' where zp_r2_code='NA_24150_CETE' and zp_r3_code='10';
update t_zpbo set zp_r3_code='NA_24395_BEBY' where zp_r2_code='NA_24150_CETE' and zp_r3_code='11';
--17
update t_zpbo set zp_r3_code='NA_24089_BEHY' where zp_r2_code='NA_24081_GERI' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24081_BEHU' where zp_r2_code='NA_24081_GERI' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24432_BEHO' where zp_r2_code='NA_24081_GERI' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24574_BEJE' where zp_r2_code='NA_24081_GERI' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24207_BEKI' where zp_r2_code='NA_24081_GERI' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24574_BEKA' where zp_r2_code='NA_24081_GERI' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24082_BEHE' where zp_r2_code='NA_24081_GERI' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24082_BEJY' where zp_r2_code='NA_24081_GERI' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24471_BEJI' where zp_r2_code='NA_24081_GERI' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24082_BEKE' where zp_r2_code='NA_24081_GERI' and zp_r3_code='10';
update t_zpbo set zp_r3_code='NA_24512_BEJO' where zp_r2_code='NA_24081_GERI' and zp_r3_code='11';
update t_zpbo set zp_r3_code='NA_24074_BEJA' where zp_r2_code='NA_24081_GERI' and zp_r3_code='12';
update t_zpbo set zp_r3_code='NA_24081_BEHA' where zp_r2_code='NA_24081_GERI' and zp_r3_code='13';
update t_zpbo set zp_r3_code='NA_24081_BEJU' where zp_r2_code='NA_24081_GERI' and zp_r3_code='14';
--18
update t_zpbo set zp_r3_code='NA_24086_BOMA' where zp_r2_code='SHL_24520_SARL' and zp_r3_code='27';
update t_zpbo set zp_r3_code='NA_24577_BOLU' where zp_r2_code='SHL_24520_SARL' and zp_r3_code='28';
update t_zpbo set zp_r3_code='NA_24587_BOLI' where zp_r2_code='SHL_24520_SARL' and zp_r3_code='29';
update t_zpbo set zp_r3_code='NA_24587_BOME' where zp_r2_code='SHL_24520_SARL' and zp_r3_code='30';
update t_zpbo set zp_r3_code='NA_24355_BOLO' where zp_r2_code='SHL_24520_SARL' and zp_r3_code='31';
--19
update t_zpbo set zp_r3_code='NA_24050_BELO' where zp_r2_code='NA_24516_CETO' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24516_BEKY' where zp_r2_code='NA_24516_CETO' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24341_BELA' where zp_r2_code='NA_24516_CETO' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24392_BELU' where zp_r2_code='NA_24516_CETO' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24412_BELI' where zp_r2_code='NA_24516_CETO' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24215_BEME' where zp_r2_code='NA_24516_CETO' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24412_BELE' where zp_r2_code='NA_24516_CETO' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24317_BELY' where zp_r2_code='NA_24516_CETO' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24516_BEMA' where zp_r2_code='NA_24516_CETO' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24516_BEKU' where zp_r2_code='NA_24516_CETO' and zp_r3_code='10';
--23
update t_zpbo set zp_r3_code='NA_24473_BENA' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24491_BEMY' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24324_BEPI' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24020_BEPA' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24241_BENY' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24188_BENE' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24550_BEMI' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24019_BENO' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24018_BENU' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24550_BENI' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='10';
update t_zpbo set zp_r3_code='NA_24550_BEMO' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='11';
update t_zpbo set zp_r3_code='NA_24550_BEPE' where zp_r2_code='NA_24550_CEXI' and zp_r3_code='13';
--46
update t_zpbo set zp_r3_code='NA_24558_BIWU' where zp_r2_code='NA_24067_FERA' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24240_BIWA' where zp_r2_code='NA_24067_FERA' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24015_BIWO' where zp_r2_code='NA_24067_FERA' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24067_BIWE' where zp_r2_code='NA_24067_FERA' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24067_BIVE' where zp_r2_code='NA_24067_FERA' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24240_BIVA' where zp_r2_code='NA_24067_FERA' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24076_BIWI' where zp_r2_code='NA_24067_FERA' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24067_BITY' where zp_r2_code='NA_24067_FERA' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24067_BIVU' where zp_r2_code='NA_24067_FERA' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24067_BIVI' where zp_r2_code='NA_24067_FERA' and zp_r3_code='10';
update t_zpbo set zp_r3_code='NA_24067_BIVY' where zp_r2_code='NA_24067_FERA' and zp_r3_code='11';
update t_zpbo set zp_r3_code='NA_24067_BIWY' where zp_r2_code='NA_24067_FERA' and zp_r3_code='12';
--48
update t_zpbo set zp_r3_code='NA_24217_BOBA' where zp_r2_code='NA_24356_TANA' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24356_BIZO' where zp_r2_code='NA_24356_TANA' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24356_BIZA' where zp_r2_code='NA_24356_TANA' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24356_BIZU' where zp_r2_code='NA_24356_TANA' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24330_BIZE' where zp_r2_code='NA_24356_TANA' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24330_BIZY' where zp_r2_code='NA_24356_TANA' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24261_BOBE' where zp_r2_code='NA_24356_TANA' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24261_BIZI' where zp_r2_code='NA_24356_TANA' and zp_r3_code='09';
--56
update t_zpbo set zp_r3_code='NA_24036_BONY' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='01';
update t_zpbo set zp_r3_code='NA_24006_BOPO' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='02';
update t_zpbo set zp_r3_code='NA_24006_BOPI' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='03';
update t_zpbo set zp_r3_code='NA_24510_BOPE' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='04';
update t_zpbo set zp_r3_code='NA_24087_BONA' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='05';
update t_zpbo set zp_r3_code='NA_24142_BOPA' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='06';
update t_zpbo set zp_r3_code='NA_24142_BONO' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='07';
update t_zpbo set zp_r3_code='NA_24142_BONI' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='08';
update t_zpbo set zp_r3_code='NA_24268_BONE' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='09';
update t_zpbo set zp_r3_code='NA_24396_BOMY' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='10';
update t_zpbo set zp_r3_code='NA_24396_BONU' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='11';
update t_zpbo set zp_r3_code='NA_24396_BOMU' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='12';
update t_zpbo set zp_r3_code='NA_24396_BOMO' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='13';
update t_zpbo set zp_r3_code='NA_24396_BOMI' where zp_r2_code='NA_24396_ROTO' and zp_r3_code='14';

/*t_cable*/
--update t_cable set cb_modulo=12 where cb_capafo>72 and cb_typelog='DI';--Aude le 24/03: dangereux car modifie les DE
--update t_cable set cb_modulo=6 where cb_capafo<96 and cb_typelog='DI';--Aude le 24/03: dangereux car modifie les DE
--update t_cable set cb_modulo=12 where cb_typelog='TR' OR cb_typelog='CO';--Aude le 24/03: dangereux car modifie les DE
update t_cable set cb_modulo=2 where cb_typelog='RA';
update t_cable set cb_proptyp = 'CST';

update t_cable set cb_etat=null;

update t_cable set cb_r3_code='' where cb_typelog='TR';
update t_cable set cb_r3_code='' where cb_typelog='CO';

update t_cable set cb_capafo='2' where cb_capafo='1';
--r1
update t_cable set cb_r1_code = '24';
--r2
update t_cable set cb_r2_code='NA_24585_CESI' where cb_r2_code='13';
update t_cable set cb_r2_code='NA_24035_FERI' where cb_r2_code='14';
update t_cable set cb_r2_code='NA_24150_CETE' where cb_r2_code='15';
update t_cable set cb_r2_code='NA_24081_GERI' where cb_r2_code='17';
update t_cable set cb_r2_code='SHL_24520_SARL' where cb_r2_code='18';
update t_cable set cb_r2_code='NA_24516_CETO' where cb_r2_code='19';
update t_cable set cb_r2_code='NA_24550_CEXI' where cb_r2_code='23';
update t_cable set cb_r2_code='NA_24067_FERA' where cb_r2_code='46';
update t_cable set cb_r2_code='NA_24356_TANA' where cb_r2_code='48';
update t_cable set cb_r2_code='NA_24396_ROTO' where cb_r2_code='56';
----r3
--13
update t_cable set cb_r3_code='NA_24386_BAWE' where cb_r2_code='NA_24585_CESI' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24039_BAWO' where cb_r2_code='NA_24585_CESI' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24585_BAWI' where cb_r2_code='NA_24585_CESI' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24585_BAWA' where cb_r2_code='NA_24585_CESI' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24585_BAWU' where cb_r2_code='NA_24585_CESI' and cb_r3_code='05';
--14
update t_cable set cb_r3_code='NA_24035_BAZE' where cb_r2_code='NA_24035_FERI' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24293_BAXO' where cb_r2_code='NA_24035_FERI' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24360_BAWY' where cb_r2_code='NA_24035_FERI' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24538_BAZY' where cb_r2_code='NA_24035_FERI' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24538_BAXU' where cb_r2_code='NA_24035_FERI' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24478_BAXA' where cb_r2_code='NA_24035_FERI' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24035_BAZO' where cb_r2_code='NA_24035_FERI' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24035_BAXE' where cb_r2_code='NA_24035_FERI' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24035_BAXI' where cb_r2_code='NA_24035_FERI' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24438_BAXY' where cb_r2_code='NA_24035_FERI' and cb_r3_code='10';
--15
update t_cable set cb_r3_code='NA_24063_BECE' where cb_r2_code='NA_24150_CETE' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24488_BEDA' where cb_r2_code='NA_24150_CETE' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24150_BEBE' where cb_r2_code='NA_24150_CETE' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24300_BEBI' where cb_r2_code='NA_24150_CETE' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24450_BEBU' where cb_r2_code='NA_24150_CETE' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24152_BECA' where cb_r2_code='NA_24150_CETE' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24091_BECI' where cb_r2_code='NA_24150_CETE' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24152_BEBO' where cb_r2_code='NA_24150_CETE' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24091_BECU' where cb_r2_code='NA_24150_CETE' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24091_BECO' where cb_r2_code='NA_24150_CETE' and cb_r3_code='10';
update t_cable set cb_r3_code='NA_24395_BEBY' where cb_r2_code='NA_24150_CETE' and cb_r3_code='11';
--17
update t_cable set cb_r3_code='NA_24089_BEHY' where cb_r2_code='NA_24081_GERI' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24081_BEHU' where cb_r2_code='NA_24081_GERI' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24432_BEHO' where cb_r2_code='NA_24081_GERI' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24574_BEJE' where cb_r2_code='NA_24081_GERI' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24207_BEKI' where cb_r2_code='NA_24081_GERI' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24574_BEKA' where cb_r2_code='NA_24081_GERI' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24082_BEHE' where cb_r2_code='NA_24081_GERI' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24082_BEJY' where cb_r2_code='NA_24081_GERI' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24471_BEJI' where cb_r2_code='NA_24081_GERI' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24082_BEKE' where cb_r2_code='NA_24081_GERI' and cb_r3_code='10';
update t_cable set cb_r3_code='NA_24512_BEJO' where cb_r2_code='NA_24081_GERI' and cb_r3_code='11';
update t_cable set cb_r3_code='NA_24074_BEJA' where cb_r2_code='NA_24081_GERI' and cb_r3_code='12';
update t_cable set cb_r3_code='NA_24081_BEHA' where cb_r2_code='NA_24081_GERI' and cb_r3_code='13';
update t_cable set cb_r3_code='NA_24081_BEJU' where cb_r2_code='NA_24081_GERI' and cb_r3_code='14';
--18
update t_cable set cb_r3_code='NA_24086_BOMA' where cb_r2_code='SHL_24520_SARL' and cb_r3_code='27';
update t_cable set cb_r3_code='NA_24577_BOLU' where cb_r2_code='SHL_24520_SARL' and cb_r3_code='28';
update t_cable set cb_r3_code='NA_24587_BOLI' where cb_r2_code='SHL_24520_SARL' and cb_r3_code='29';
update t_cable set cb_r3_code='NA_24587_BOME' where cb_r2_code='SHL_24520_SARL' and cb_r3_code='30';
update t_cable set cb_r3_code='NA_24355_BOLO' where cb_r2_code='SHL_24520_SARL' and cb_r3_code='31';
--19
update t_cable set cb_r3_code='NA_24050_BELO' where cb_r2_code='NA_24516_CETO' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24516_BEKY' where cb_r2_code='NA_24516_CETO' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24341_BELA' where cb_r2_code='NA_24516_CETO' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24392_BELU' where cb_r2_code='NA_24516_CETO' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24412_BELI' where cb_r2_code='NA_24516_CETO' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24215_BEME' where cb_r2_code='NA_24516_CETO' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24412_BELE' where cb_r2_code='NA_24516_CETO' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24317_BELY' where cb_r2_code='NA_24516_CETO' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24516_BEMA' where cb_r2_code='NA_24516_CETO' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24516_BEKU' where cb_r2_code='NA_24516_CETO' and cb_r3_code='10';
--23
update t_cable set cb_r3_code='NA_24473_BENA' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24491_BEMY' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24324_BEPI' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24020_BEPA' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24241_BENY' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24188_BENE' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24550_BEMI' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24019_BENO' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24018_BENU' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24550_BENI' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='10';
update t_cable set cb_r3_code='NA_24550_BEMO' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='11';
update t_cable set cb_r3_code='NA_24550_BEPE' where cb_r2_code='NA_24550_CEXI' and cb_r3_code='13';
--46
update t_cable set cb_r3_code='NA_24558_BIWU' where cb_r2_code='NA_24067_FERA' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24240_BIWA' where cb_r2_code='NA_24067_FERA' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24015_BIWO' where cb_r2_code='NA_24067_FERA' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24067_BIWE' where cb_r2_code='NA_24067_FERA' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24067_BIVE' where cb_r2_code='NA_24067_FERA' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24240_BIVA' where cb_r2_code='NA_24067_FERA' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24076_BIWI' where cb_r2_code='NA_24067_FERA' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24067_BITY' where cb_r2_code='NA_24067_FERA' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24067_BIVU' where cb_r2_code='NA_24067_FERA' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24067_BIVI' where cb_r2_code='NA_24067_FERA' and cb_r3_code='10';
update t_cable set cb_r3_code='NA_24067_BIVY' where cb_r2_code='NA_24067_FERA' and cb_r3_code='11';
update t_cable set cb_r3_code='NA_24067_BIWY' where cb_r2_code='NA_24067_FERA' and cb_r3_code='12';
--48
update t_cable set cb_r3_code='NA_24217_BOBA' where cb_r2_code='NA_24356_TANA' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24356_BIZO' where cb_r2_code='NA_24356_TANA' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24356_BIZA' where cb_r2_code='NA_24356_TANA' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24356_BIZU' where cb_r2_code='NA_24356_TANA' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24330_BIZE' where cb_r2_code='NA_24356_TANA' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24330_BIZY' where cb_r2_code='NA_24356_TANA' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24261_BOBE' where cb_r2_code='NA_24356_TANA' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24261_BIZI' where cb_r2_code='NA_24356_TANA' and cb_r3_code='09';
--56
update t_cable set cb_r3_code='NA_24036_BONY' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='01';
update t_cable set cb_r3_code='NA_24006_BOPO' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='02';
update t_cable set cb_r3_code='NA_24006_BOPI' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='03';
update t_cable set cb_r3_code='NA_24510_BOPE' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='04';
update t_cable set cb_r3_code='NA_24087_BONA' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='05';
update t_cable set cb_r3_code='NA_24142_BOPA' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='06';
update t_cable set cb_r3_code='NA_24142_BONO' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='07';
update t_cable set cb_r3_code='NA_24142_BONI' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='08';
update t_cable set cb_r3_code='NA_24268_BONE' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='09';
update t_cable set cb_r3_code='NA_24396_BOMY' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='10';
update t_cable set cb_r3_code='NA_24396_BONU' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='11';
update t_cable set cb_r3_code='NA_24396_BOMU' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='12';
update t_cable set cb_r3_code='NA_24396_BOMO' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='13';
update t_cable set cb_r3_code='NA_24396_BOMI' where cb_r2_code='NA_24396_ROTO' and cb_r3_code='14';

update t_cable set cb_fo_disp=cb_fo_util-(select nblr_cum from import_bpe where cb_etiquet = cab_codext) where cb_typelog='DI'; -- (Nicolas)
update t_cable set cb_fo_util=(select nblr_cum from import_bpe where cb_etiquet = cab_codext) where cb_typelog='DI';

update t_cable set cb_avct ='S' where cb_statut = 'REC';


/*t_conduite*/
update t_conduite set cd_statut = (select cm_statut from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code); --Aude le 24/03: statut prend celui du t_cheminement
update t_conduite set cd_r1_code = '24' ;
update t_conduite set cd_prop = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'OR033001002022' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);
update t_conduite set cd_gest = (case 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where (cm_avct='C' or cm_avct='S')) then 'OR033001002022' 
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (0,7,9,10)) then 'OR033001001581'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (1)) then 'OR033002000000'
when cd_code in(select dm_cd_code from t_cond_chem join t_cheminement on (dm_cm_code = cm_code) where cm_avct='E' and cm_typ_imp in (2,3)) then 'OR033002100041'
end);

update t_conduite set cd_dia_ext = substr((select cm_compo from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code),instr((select cm_compo from t_cheminement, t_cond_chem where dm_cm_code = cm_code and dm_cd_code=cd_code),'/')+1)
	where cd_type ='PVC' or cd_type='PEHD';


update t_conduite set cd_proptyp=null;
update t_conduite set cd_long=null;
update t_conduite set cd_nbcable=null;

update t_conduite set cd_avct='S' where cd_statut = 'REC';

/* t_baie */
update t_baie set ba_codeext=null;
update t_baie set ba_prop='OR033001002022';
update t_baie set ba_gest='OR033001002022';
update t_baie set ba_proptyp='CST';
update t_baie set ba_type='BAIE';


update t_baie set ba_etiquet = (case
when ba_lt_code in(select lt_code from t_ltech where lt_st_code in(select st_code from t_sitetech where st_typelog = 'SRO')) then 'PMT-' || 
	substr(replace((select lt_etiquet from  t_ltech where ba_lt_code= lt_code),'_','-'),instr((select lt_etiquet from  t_ltech where ba_lt_code= lt_code),'_')+1) || '-Baie' || ba_etiquet 
when ba_lt_code in(select lt_code from t_ltech where lt_st_code in(select st_code from t_sitetech where st_typelog = 'NRO')) then 'RTO-' || 
	substr(replace((select lt_etiquet from  t_ltech where ba_lt_code= lt_code),'_','-'),instr((select lt_etiquet from  t_ltech where ba_lt_code= lt_code),'_')+1) || '-Baie' || ba_etiquet
end);

/* t_tiroir */
update t_tiroir set ti_prop='OR033001002022';
update t_tiroir set ti_type='TIROIR';
update t_tiroir set ti_placemt = ti_etiquet;
update t_tiroir set ti_etiquet=(select ba_etiquet from t_baie where ti_ba_code=ba_code) ||'_'|| ti_etiquet;
update t_tiroir set ti_taille = '3';
update t_tiroir set ti_rf_code = 'RF033000000254';
--tiroir de lovage
update t_tiroir set ti_rf_code = 'RF033000001409' where ti_placemt=1; 
update t_tiroir set ti_taille = '1' where ti_placemt=1;
update t_tiroir set ti_etiquet = 'TDC-ACCES-' || substr(ti_etiquet,11,4) || '-01-LOVAGE' where ti_etiquet like 'PMT%' and ti_placemt=1;
update t_tiroir set ti_etiquet = 'TDC-TRANS-' || substr(ti_etiquet,11,4) || '-01-LOVAGE' where ti_etiquet like 'RTO%' and ti_placemt=1;
--tiroir de collecte
update t_tiroir set ti_etiquet = 'TDC-COLLE-' || substr(ti_etiquet,11,4) || '-02' where ti_etiquet like 'RTO%' and ti_placemt=41;
update t_tiroir set ti_etiquet = 'TDC-COLLE-' || substr(ti_etiquet,11,4) || '-01' where ti_etiquet like 'RTO%' and ti_placemt=42;
update t_tiroir set ti_taille = 1 where ti_placemt > 39;
update t_tiroir set ti_rf_code ='RF033000000331' where ti_placemt > 39;
--tiroir de transport du NRO 
update t_tiroir set ti_etiquet = 'TDC-TRANS-' || substr(ti_etiquet,11,4) || '-' || substr(('00' || ti_placemt),-2) where ti_etiquet like 'RTO%' and ti_placemt <> 41 and ti_placemt <> 42;
--tiroir de transport du SRO
update t_tiroir set ti_etiquet = 'TDC-TRANS-' || substr(ti_etiquet,11,4) || '-01' where ti_etiquet like 'PMT%' and (ti_placemt =26 or ti_placemt = 38) ;
update t_tiroir set ti_rf_code = 'RF033000000254'  where ti_etiquet like 'PMT%' and (ti_placemt = 26 or ti_placemt=38);
--tiroir de distribution du SRO
update t_tiroir set ti_etiquet = 'TDC-ACCES-' || substr(ti_etiquet,11,4) || '-' || substr(('00' || ti_placemt),-2) where ti_etiquet like 'PMT%' and ti_placemt < 26 ;
update t_tiroir set ti_rf_code = 'RF033000000254' where ti_etiquet like 'PMT%' and ti_placemt < 26 ;
--ti_placemt
update t_tiroir set ti_placemt = (case
	when ti_placemt = 1 then 1
	when ti_placemt = 2 then 2
	when ti_placemt = 3 then 5
	when ti_placemt = 4 then 8
	when ti_placemt = 5 then 11
	when ti_placemt = 6 then 14
	when ti_placemt = 7 then 17
	when ti_placemt = 8 then 20
	when ti_placemt = 9 then 23
	when ti_placemt = 10 then 26
	when ti_placemt = 11 then 29
	when ti_placemt = 12 then 32
	when ti_placemt = 13 then 35
	when ti_placemt = 14 then 38
	when ti_placemt > 14 then ti_placemt
end) ;


/* t_baie suite*/
--
update t_baie set ba_rf_code = 'RF033000000026' where ba_etiquet like '%RTO%';
update t_baie set ba_rf_code = 'RF033000000238' where ba_etiquet like '%PMT%' and ( select ti_placemt from t_tiroir where ti_placemt = 26) ;
update t_baie set ba_rf_code = 'RF033000000239' where ba_etiquet like '%PMT%' and ( select ti_placemt from t_tiroir where ti_placemt = 38);
update t_baie set ba_rf_code = 'RF033000000026' where ba_etiquet like '%PMT%' and ( select ti_placemt from t_tiroir where ti_placemt = 40);
--
update t_baie set ba_nb_u = (case
	when ba_rf_code = 'RF033000000239' then '40'
	when ba_rf_code = 'RF033000000238' then '28'
	when ba_rf_code = 'RF033000000026' then '42'
	when ba_rf_code = 'RF033000001355' then '40'
end);


/* t_fibre */
update t_fibre set fo_proptyp='CST';
update t_fibre set fo_code_ext = null; 
update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='DI');
update t_fibre set fo_type = 'G657' where fo_cb_code in (select cb_code from t_cable where cb_typelog='RA');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='TR');
update t_fibre set fo_type = 'G652' where fo_cb_code in (select cb_code from t_cable where cb_typelog='CO');

/* t_position */
update t_position set ps_preaff = (case 
when ps_comment = 'ABONNE' then  'ABONNE'
end);

update t_position set ps_cs_code = NULL where ps_ti_code != '' or (ps_ti_code != '' and ps_ti_code is not null); --pas de K7 dans les tiroirs

delete from t_position where ps_fonct='';
update t_position set ps_fonct='AT' where ps_ti_code in (select ti_code from t_tiroir where ti_placemt='1');


/* t_ropt */
DELETE FROM t_ropt; 


/* t_cassette */
delete from t_cassette_patch201 where cs_ti_code is null;
update t_cassette set cs_bp_code= null where cs_code in ( select cs_code from t_cassette_patch201);
delete from t_cassette_patch201;
delete from t_cassette where cs_bp_code is null;

update t_cassette set cs_face= 'A' where cs_num > 0;
update t_cassette set cs_face = 'FDB' where cs_num = 0 and cs_type = 'P'; 

/*sup SRO NRO t_cable_patche*/
update t_cable_patch201 set cb_bp1 = NULL where cb_bp1 in (select bp_code from t_ebp where bp_typelog='SRO' or bp_typelog='NRO');
update t_cable_patch201 set cb_bp2 = NULL where cb_bp2 in (select bp_code from t_ebp where bp_typelog='SRO' or bp_typelog='NRO');

/* sup SRO et NRO dans t_ebp */
delete from t_ebp where bp_typelog='SRO';
delete from t_ebp where bp_typelog='NRO';


/* t_love*/

delete from t_love where lv_long = '0';

/* t_suf*/
update t_suf set sf_comment = 'Futur prise' where sf_ad_code in ( select ad_code from t_adresse where ad_imneuf='0');


/* champs a vider */
update t_adresse set ad_typzone=null;
update t_adresse set ad_geolsrc=null; 
update t_adresse set ad_creadat=null;
update t_baie set ba_creadat=null;
update t_ebp set bp_creadat=null;
update t_cable set cb_creadat=null;
update t_cab_cond set cc_creadat=null;
update t_conduite set cd_creadat=null;
/*update t_conduite set cd_r2_code=null;*/
update t_cableline set cl_creadat=null;
update t_cableline set cl_long=null;
update t_cableline set cl_comment=null; 
update t_cheminement set cm_creadat=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_geolqlt=null;
update t_cheminement set cm_geolsrc=null;
update t_cheminement set cm_gest_do=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_long=null;
update t_cassette set cs_creadat=null;
update t_cassette set cs_nb_pas=null;
update t_cond_chem set dm_creadat=null;
update t_fibre set fo_color=null;
update t_fibre set fo_creadat=null;
update t_fibre set fo_proptyp=null;
update t_fibre set fo_reper=null;
update t_ltech set lt_creadat=null;
update t_ltech set lt_dateins=null;
update t_ltech set lt_datemes=null;
update t_ltech set lt_proptyp=null;
update t_love set lv_creadat=null;
update t_noeud set nd_creadat=null;
update t_noeud set nd_geolqlt=null;
update t_noeud set nd_voie=null; 
update t_position set ps_creadat=null;
update t_ptech set pt_creadat=null;
update t_suf set sf_creadat=null;
update t_sitetech set st_codeext=null;
update t_sitetech set st_creadat=null;
update t_sitetech set st_etat=null;
update t_tiroir set ti_creadat=null;
update t_znro set zn_creadat=null;
update t_znro set zn_nrotype=null;
update t_zpbo set zp_creadat=null;
update t_zsro set zs_creadat=null;
update t_zsro set zs_nbcolmt=null;
update t_zsro set zs_typeing=null;
update t_cable set cb_codeext = null;

/* Maj l_tech_patch_201 pour sro et nro */
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in (select lt_code from t_ltech_patch201);

update t_ltech_patch201 set lt_bat = 'NA';

/* mise a jour PTO */
update t_cable set cb_etiquet = 'OO-XXXX-XXXX' where cb_typelog='RA';
update t_cable set cb_rf_code = 'RF033000000309' where cb_typelog='RA';


/* collecte mutualis dans distri transport */
update t_cable set cb_typelog='CT' where cb_typelog='CO';

--Mise à jour du nd_r3_code
update t_noeud set nd_r3_code= null where nd_r2_code = nd_r3_code;

end transaction;