-- maj import_bpe
update import_bpe set mat_ref=(select equipment from noeuds where noeid=import_bpe.id);
update import_bpe set mat_capa=(select capacity from noeuds where noeid=import_bpe.id);


-- Maj rf_code baie (en rapport avec fihier mode_baies.xlsx de la config GRACE
update import_bpe set rf_code = 'RF033000000238' where noe_type in ('SRO','PM') and mat_ref='PM 28';
update import_bpe set rf_code = 'RF033000000239' where noe_type in ('SRO','PM') and mat_ref='PM 40';
update import_bpe set rf_code = 'RF033000000026' where noe_type in ('NRO');
-- Maj capa k7
update noeuds set mat_k7_cap = 12 where noe_type='EQU' and type<>'PDT' and substr(pose,1,3)<>'POT';
update noeuds set mat_k7_cap = 6 where noe_type='EQU' and type<>'PDT' and substr(pose,1,3)='POT';

-- PBO,PRE,PBR
update noeuds set equipment = 'Black box' where substr(pose,1,3)='CHB' and type in ('PBR','PBO','PRE');
update noeuds set equipment = 'PB Telenco' where substr(pose,1,3) in ('POT','FAC') and type in ('PBR','PBO','PRE');
update noeuds set equipment = 'PB imb' where substr(pose,1,3) in ('IMM') and type in ('PBR','PBO','PRE','PEP') and NBLR>0;

-- PEP sout + câble de passage =<36FO : Black box 
update noeuds set equipment = 'Black box' where substr(pose,1,3)='CHB' and type in ('PEP') 
and (select cab_capa from cables where cab_id=cab_amont_key)<=36
and (posoncab>1 and posoncab<(select max(posoncab) from noeuds as n2 where n2.cab_amont_key=cab_amont_key))
and (select count(noeid) from noeuds as n3 where n3.cab_amont_key=cab_amont_key and type<>'PDT')>1;

-- PEP aer/fac + câble de passage =<48FO : Telenco
update noeuds set equipment = 'Telenco' where substr(pose,1,3)in('POT','FAC') and type in ('PEP') 
and (select cab_capa from cables where cab_id=cab_amont_key)<=48
and (posoncab>1 and posoncab<(select max(posoncab) from noeuds as n2 where n2.cab_amont_key=cab_amont_key))
and (select count(noeid) from noeuds as n3 where n3.cab_amont_key=cab_amont_key and type<>'PDT')>1;

-- maj capa boitier <T2 
update noeuds set capacity=36 where lower(equipment)='black box';
update noeuds set capacity=48 where lower(equipment) like '%telenco%';
update noeuds set capacity=144 where lower(equipment)='t1';
update noeuds set capacity=144 where lower(equipment)='t1.5';
update noeuds set capacity =(select mat_capa from import_bpe where id=noeid);
update noeuds set  capacity = (select cab_capa from cables where cab_id = cab_amont_key) where equipment='T2';

-- BPI immeuble
update noeuds set equipment ='BPI 144' where pose in('IMM','IMB') and capacity=144;
update noeuds set equipment ='BPI 36' where pose in('IMM','IMB') and capacity=36;

-- autre PEP
update noeuds set equipment = 'T2' where substr(pose,1,3)in('POT','FAC','CHB') and type in ('PEP') and (equipment is null or equipment='');
update noeuds set equipment = 'T1' where type='PA' and substr(pose,1,3)in('CHB') ;
update noeuds set equipment = 'T1.5' where type='PA' and substr(pose,1,3) not in('CHB') ;

-- Maj rf_code bpe/t_ebp
update import_bpe set mat_ref = (select equipment from noeuds where noeid = id);
update import_bpe set rf_code ='RF033000000203' where mat_ref ='T2';
update import_bpe set rf_code ='RF033000000201' where mat_ref ='T1';
update import_bpe set rf_code ='RF033000000290' where mat_ref ='T1,5';
update import_bpe set rf_code ='RF033000000230' where mat_ref ='Black box';
update import_bpe set rf_code ='RF033000001596' where mat_ref ='PB Telenco';
update import_bpe set rf_code ='RF033000001596' where mat_ref ='Telenco';
update import_bpe set rf_code ='RF033000000201' where mat_ref ='BPI 144';
update import_bpe set rf_code ='RF033000000200' where mat_ref ='BPI 36';
update import_bpe set rf_code ='RF033000000234' where mat_ref ='PB imb';
update import_bpe set rf_code ='RF033000000238' where mat_ref ='PM 28';
update import_bpe set rf_code ='RF033000000239' where mat_ref ='PM 40';


-- Maj rf_code cables/t_cable
update import_cables set rf_code ='RF033000000309' where cab_modulo <=2;
update import_cables set rf_code ='RF033000000584' where cab_capa =6;
update import_cables set rf_code ='RF033000000585' where cab_capa =12;
update import_cables set rf_code ='RF033000000586' where cab_capa =24;
update import_cables set rf_code ='RF033000000587' where cab_capa =36;
update import_cables set rf_code ='RF033000000588' where cab_capa =48;
update import_cables set rf_code ='RF033000000589' where cab_capa =72;
update import_cables set rf_code ='RF033000000597' where cab_capa =144;
update import_cables set rf_code ='RF033000000102' where cab_capa =288;
update import_cables set rf_code ='RF033000000660' where cab_capa =432;
update import_cables set rf_code ='RF033000000661' where cab_capa =576;
update import_cables set rf_code ='RF033000000662' where cab_capa =720;
update import_cables set rf_code ='RF033000000309' where cab_modulo =1;


