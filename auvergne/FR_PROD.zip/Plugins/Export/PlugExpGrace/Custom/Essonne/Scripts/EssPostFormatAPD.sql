﻿begin transaction;
/*statut pro */
update t_cable set cb_statut='PRO' where cb_statut<>'DIA';
update t_ebp set bp_statut='PRO' where bp_statut<>'DIA';
update t_ptech set pt_statut='PRO' where pt_statut<>'DIA';
update t_ltech set lt_statut='PRO' where lt_statut<>'DIA';
update t_sitetech set st_statut='PRO' where st_statut<>'DIA';
update t_cheminement set cm_statut='PRO' where cm_statut<>'DIA';
update t_conduite set cd_statut='PRO' where cd_statut<>'DIA';
end transaction;

begin transaction;
/*statut avp */
update t_cable set cb_statut='AVP' where cb_statut='DIA';
update t_ebp set bp_statut='AVP' where bp_statut='DIA';
update t_ptech set pt_statut='AVP' where pt_statut='DIA';
update t_ltech set lt_statut='AVP' where lt_statut='DIA';
update t_sitetech set st_statut='AVP' where st_statut='DIA';
update t_cheminement set cm_statut='AVP' where cm_statut='DIA';
update t_conduite set cd_statut='AVP' where cd_statut='DIA';


/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);

/*t_noeud */
update t_noeud set nd_geolqlt=null;


/*t_cableline*/
update t_cableline set cl_geolqlt=null;

/*t_cheminement*/
update t_cheminement set cm_compo='';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;

/*t_zpbo*/
/*update t_zpbo set zp_capamax=null;*/

/*t_zsro*/
/*update t_zsro set zs_capamax=null;
update t_zsro set zs_nblogmt=null;
update t_zsro set zs_nbcolmt=null;*/

/*t_znro*/

/*t_cable*/
delete from t_fibre;
delete from t_position;
end transaction;


