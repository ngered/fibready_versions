﻿begin transaction;
	/*sitetech*/
    update t_sitetech set st_codeext='ES-TEC-' || (select nd_r3_code from t_noeud where nd_code = st_nd_code) where st_typelog='SRO' or st_typelog='NRO';

	
	/*t_ltech*/
	update t_ltech set lt_codeext='';
	update t_ltech set lt_codeext=(select replace(st_codeext,'ES-ST','ES-LT') ||(select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code);
	
	/*t_baie*/
	update t_baie set ba_codeext='';
	update t_baie set ba_codeext= (select replace(lt_codeext,'ES-LT','ES-ARM') || '-' || (select count(*)+1 from t_baie where ba_lt_code=lt_code and ba_codeext<>'') from t_ltech where lt_code = ba_lt_code);
  update t_baie set ba_etiquet=substr(ba_codeext,-6);
	
	/*t_tiroir*/
	update t_tiroir set ti_codeext='';
	update t_tiroir set ti_codeext=(select replace(ba_codeext,'ES-ARM','ES-TI') || '-' || (select count(*)+1 from t_tiroir where ti_ba_code=ba_code and ba_codeext<>'') from t_baie where ba_code =ti_ba_code);
	
	/*t_ebp*/
	update t_ebp set bp_codeext='';
	update t_ebp set bp_codeext=(select replace(pt_codeext,'ES-PT','ES-BP') ||'-' || (select count(*)+1 from t_ebp where bp_pt_code=pt_code and bp_codeext<>'') from t_ptech where pt_code =bp_pt_code);
end transaction;
