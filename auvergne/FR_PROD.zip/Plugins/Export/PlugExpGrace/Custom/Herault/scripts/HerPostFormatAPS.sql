﻿begin transaction;
/*statut avp */
update t_cable set cb_statut='AVP' where cb_statut='DIA';
update t_ebp set bp_statut='AVP' where bp_statut='DIA';
update t_ptech set pt_statut='AVP' where pt_statut='DIA';
update t_ltech set lt_statut='AVP' where lt_statut='DIA';
update t_sitetech set st_statut='AVP' where st_statut='DIA';
update t_cheminement set cm_statut='AVP' where cm_statut='DIA';
update t_conduite set cd_statut='AVP' where cd_statut='DIA';



/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep);
update t_adresse set ad_commune=upper(ad_commune);
update t_adresse set ad_nomvoie=upper(ad_nomvoie);
update t_adresse set ad_geolqlt=null;
update t_adresse set ad_x_parc=null;
update t_adresse set ad_y_parc=null;
update t_adresse set ad_nat=null;
update t_adresse set ad_distinf=null;
update t_adresse set ad_x_ban=X(geom);
update t_adresse set ad_y_ban=Y(geom);
/*update t_adresse set ad_ietat='CI';*/


update t_sitetech set st_nom=st_codeext;
update t_sitetech set st_prop='OR34000000000004' where st_typelog='SRO' or st_typelog='NRO';
update t_sitetech set st_gest='OR34000000000004'where st_typelog='SRO' or st_typelog='NRO';
update t_sitetech set st_etat='OK';

/*t_noeud */
update t_noeud set nd_r1_code="HERAULT THD";
update t_noeud set nd_r2_code=(select nd_codeext from t_noeud, t_znro where zn_nd_code=nd_code limit 1);
update t_noeud set nd_geolqlt=null;



/*t_cableline*/
update t_cable set cb_r1_code="HERAULT THD";
update t_cable set cb_r2_code=(select nd_codeext from t_noeud, t_znro where zn_nd_code=nd_code limit 1);
update t_cableline set cl_geolqlt=null;

/*t_cheminement*/
update t_cheminement set cm_compo='';
update t_cheminement set cm_cddispo=null;
update t_cheminement set cm_fo_util=null;
update t_cheminement set cm_charge=null;
update t_cheminement set cm_larg=null;
update t_cheminement set cm_lgreel=null;
update t_cheminement set cm_geolqlt=null;


/*t_zpbo*/
update t_zpbo set zp_r1_code="HERAULT THD";
update t_zpbo set zp_r2_code=(select nd_codeext from t_noeud, t_znro where zn_nd_code=nd_code limit 1);
update t_zpbo set zp_r3_code=(select nd_codeext from t_noeud, t_zsro where zs_nd_code=nd_code and st_contains( t_zsro.geom,t_zpbo.geom) limit 1);
/*update t_zpbo set zp_capamax=null;*/

/*t_zsro*/
/*update t_zsro set zs_capamax=null;*/
update t_zsro set zs_r1_code="HERAULT THD";
update t_zsro set zs_r2_code=(select nd_codeext from t_noeud, t_znro where zn_nd_code=nd_code limit 1);
update t_zsro set zs_r3_code=(select nd_codeext from t_noeud where zs_nd_code=nd_code limit 1);
update t_zsro set zs_r4_code='ANNEE1';
update t_zsro set zs_refpm=(select st_codeext from t_sitetech, t_noeud where zs_nd_code=nd_code and st_nd_code=nd_code limit 1);
update t_zsro set zs_ad_code=(select st_ad_code from t_sitetech, t_noeud where zs_nd_code=nd_code and st_nd_code=nd_code limit 1);
update t_zsro set zs_dateins=null;
update t_zsro set zs_nbcolmt=null;
update t_zsro set zs_typeemp='ADR';
update t_zsro set zs_capamax=460 where zs_nblogmt<=460;
update t_zsro set zs_capamax=800 where zs_nblogmt>460;
update t_zsro set zs_typeing='MONO';
update t_zsro set zs_nblogmt =(select count(sf_code) from t_suf,t_zpbo where sf_zp_code=zp_code and zp_zs_code=zs_code);
update t_zsro set zs_actif=0;

/*t_znro*/
update t_znro set zn_r1_code="HERAULT THD";
update t_znro set zn_r2_code=(select nd_codeext from t_noeud, t_znro where zn_nd_code=nd_code limit 1);
update t_znro set zn_r3_code=null;
update t_znro set zn_r4_code='ANNEE1';
update t_znro set  zn_nroref =(select st_codeext from t_sitetech, t_noeud, t_znro where zn_nd_code=nd_code and st_nd_code=nd_code limit 1);

/*t_cable*/
update t_cable set cb_r1_code="HERAULT THD";
update t_cable set cb_r2_code=(select nd_codeext from t_noeud, t_znro where zn_nd_code=nd_code limit 1);
update t_cable set cb_r3_code=cb_r2_code || '_0' || substr(cb_code,6,2);
update t_cable set cb_modulo=6 where (cb_typelog='DI' || cb_typelog='TR') and cb_capafo<96;
update t_cable set cb_modulo=12 where (cb_typelog='DI' || cb_typelog='TR') and cb_capafo>=96;
update t_cable set cb_modulo=1 where (cb_typelog='RA');
update t_cable set cb_gest='OR34000000000004';
update t_cable set cb_etat='OK';
end transaction;


