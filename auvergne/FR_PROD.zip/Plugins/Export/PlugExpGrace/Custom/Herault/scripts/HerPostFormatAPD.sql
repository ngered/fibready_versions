﻿begin transaction;

/*statut pro */
update t_cable set cb_statut='PRO' where cb_statut<>'DIA';
update t_ebp set bp_statut='PRO' where bp_statut<>'DIA';
update t_ptech set pt_statut='PRO' where pt_statut<>'DIA';
update t_ltech set lt_statut='PRO' where lt_statut<>'DIA';
update t_sitetech set st_statut='PRO' where st_statut<>'DIA';
update t_cheminement set cm_statut='PRO' where cm_statut<>'DIA';
update t_conduite set cd_statut='PRO' where cd_statut<>'DIA';

/*statut avp */
update t_cable set cb_statut='AVP' where cb_statut='DIA';
update t_ebp set bp_statut='AVP' where bp_statut='DIA';
update t_ptech set pt_statut='AVP' where pt_statut='DIA';
update t_ltech set lt_statut='AVP' where lt_statut='DIA';
update t_sitetech set st_statut='AVP' where st_statut='DIA';
update t_cheminement set cm_statut='AVP' where cm_statut='DIA';
update t_conduite set cd_statut='AVP' where cd_statut='DIA';

/*t_adresse*/
update t_adresse set ad_ietat='CI';

/*t_conduite*/
update t_zsro set zs_etatpm='EC';
update t_znro set zn_etatlpm='EC';
update t_znro set zn_etat='EC';

end transaction;


