begin transaction;
/* maj orange */
update t_cable set cb_prop='OR34000000000002' where cb_prop='OR91000000000002';
update t_ebp set bp_prop='OR34000000000002' where bp_prop='OR91000000000002';
update t_ptech set pt_prop='OR34000000000002' where pt_prop='OR91000000000002';
update t_ltech set lt_prop='OR34000000000002' where lt_prop='OR91000000000002';
update t_sitetech set st_prop=='OR34000000000002' where st_prop='OR91000000000002';

/* maj enedis */
update t_cable set cb_prop='OR34000000000001' where cb_prop='OR91000000000004';
update t_ebp set bp_prop='OR34000000000001' where bp_prop='OR91000000000004';
update t_ptech set pt_prop='OR34000000000001' where pt_prop='OR91000000000004';
update t_ltech set lt_prop='OR34000000000001' where lt_prop='OR91000000000004';
update t_sitetech set st_prop=='OR34000000000001' where st_prop='OR91000000000004';

/*maj client*/
update t_cable set cb_prop='OR34000000000004' where cb_prop='OR91000000000002' or cb_prop='OR91000000000001';
update t_ebp set bp_prop='OR34000000000004' where bp_prop='OR91000000000002' or bp_prop='OR91000000000001';
update t_ptech set pt_prop='OR34000000000004' where pt_prop='OR91000000000002' or pt_prop='OR91000000000001';
update t_ltech set lt_prop='OR34000000000004' where lt_prop='OR91000000000002' or lt_prop='OR91000000000001';
update t_sitetech set st_prop=='OR34000000000004' where st_prop='OR91000000000002' or st_prop='OR91000000000001';

/*maj indertemine*/
update t_cable set cb_prop='OR34000000000004' where cb_prop='OR91000000000006' ;
update t_ebp set bp_prop='OR34000000000004' where bp_prop='OR91000000000006' ;
update t_ptech set pt_prop='OR34000000000004' where pt_prop='OR91000000000006' ;
update t_ltech set lt_prop='OR34000000000004' where lt_prop='OR91000000000006' ;
update t_sitetech set st_prop=='OR34000000000004' where st_prop='OR91000000000006';

End transaction;
