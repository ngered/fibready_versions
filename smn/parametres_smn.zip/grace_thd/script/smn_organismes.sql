PRAGMA foreign_keys = OFF;

--t_ptech
update t_ptech set pt_prop='OR900000000027' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='INDETERMINE');
update t_ptech set pt_prop='OR900000000001' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='ENEDIS');
update t_ptech set pt_prop='OR900000000016' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='ORANGE');
update t_ptech set pt_prop='OR900000000010' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='SEINE MARITIME NUMERIQUE');
update t_ptech set pt_prop='OR000000000017' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='LES COPROPRIETAIRES' or proprio ='PRIVE');
update t_ptech set pt_user='OR900000000010';
update t_ptech set pt_gest=pt_prop where pt_prop in (select or_code from t_organisme);

--t_sitetech
update t_sitetech set st_proptyp='CST';
update t_sitetech set st_prop='OR900000000010', st_gest='OR900000000010', st_user ='OR900000000010' ;
update t_sitetech set st_etat ='OK';
update t_sitetech set st_proptyp='CST';

--t_ltech
UPDATE t_ltech SET lt_gest = t_sitetech.st_gest FROM t_sitetech WHERE t_ltech.lt_st_code = t_sitetech.st_code;
UPDATE t_ltech SET lt_prop = t_sitetech.st_prop FROM t_sitetech WHERE t_ltech.lt_st_code = t_sitetech.st_code;
update t_ltech set lt_prop='OR000000000017', lt_gest='OR000000000017' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');
update t_ltech set lt_user='OR900000000010';

--t_ebp
update t_ebp set bp_prop='OR900000000010', bp_gest='OR900000000010', bp_user='OR900000000010';
update t_ebp set bp_proptyp='CST', bp_etat='OK';

--t_cable
update t_cable set  cb_prop='OR900000000010', cb_gest='OR900000000010', cb_user='OR900000000010', cb_proptyp='CST';
PRAGMA foreign_keys = ON;

--t_baie
update t_baie set ba_prop='OR900000000010', ba_gest='OR900000000010', ba_user='OR900000000010';