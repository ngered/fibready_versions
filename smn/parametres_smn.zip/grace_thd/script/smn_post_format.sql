PRAGMA foreign_keys = OFF;

--t_adresse
update t_adresse set ad_ietat='EC' where ad_ietat='EN_PROJET';
update t_adresse set ad_ietat='DE' where ad_ietat='DEPLOYE' or ad_ietat='SITE DEPLOYE';
update t_adresse set ad_nomvoie = (select ad_nomvoie from t_adresse as a2 where ad_nomvoie is not null and ad_nomvoie<>'' order by st_distance(a2.geom,geom)  limit 1);
update t_adresse set ad_nomvoie = upper(ad_nomvoie);
update t_adresse set ad_commune = (select ad_commune from t_adresse as a2 where ad_commune is not null and ad_commune<>'' order by st_distance(a2.geom,geom)  limit 1);
update t_adresse set ad_commune = upper(ad_commune);
update t_adresse set ad_x_ban = round(st_x(geom),2), ad_y_ban = round(st_y(geom),2);
update t_adresse set ad_hexacle =(select cle from import_bal inner join noeuds on noeuds.lri_key = import_bal.id
                                                             inner join l_fbt_gra on noeuds.noeid = l_fbt_gra.fbt_key
                                                             where lower(fbt_tbl)='noeuds' and lower(gra_tbl)='t_adresse'
                                                             and gra_code=ad_code);
update t_adresse set ad_hexaclv =(select matricule from import_bal inner join noeuds on noeuds.lri_key = import_bal.id
                                                             inner join l_fbt_gra on noeuds.noeid = l_fbt_gra.fbt_key
                                                             where lower(fbt_tbl)='noeuds' and lower(gra_tbl)='t_adresse'
                                                             and gra_code=ad_code);
update t_adresse set ad_numero=0 where ad_numero is null;
update t_adresse set ad_section='NC' where ad_section is null or ad_section='';
update t_adresse set ad_idpar='NC' where ad_idpar is null or ad_idpar='';
update t_adresse set ad_prio=false where ad_prio is null or ad_prio='';
update t_adresse set ad_geolsrc='RELEVE';
update t_adresse set ad_iaccgst=true where instr('oui,1', lower((select convention from import_bal inner join noeuds on noeuds.lri_key = import_bal.id
                                                             inner join l_fbt_gra on noeuds.noeid = l_fbt_gra.fbt_key
                                                             where lower(fbt_tbl)='noeuds' and lower(gra_tbl)='t_adresse'
                                                             and gra_code=ad_code)))>0;
update t_adresse set ad_iaccgst=false where ad_iaccgst is null;


--t_noeud
update t_noeud set nd_r1_code='DSP1';
update t_noeud set nd_r2_code='MS6';
update t_noeud set nd_codeext=null; --vider la colonne nd_codeext
update t_noeud set nd_type_ep= 'OPT', nd_geolmod='INDT', nd_geolsrc='SIG NGE';
update t_noeud set nd_type='SH ' where nd_type='SH';
update t_noeud set nd_voie = (select n2.nd_voie from t_noeud as n2 where n2.nd_voie is not null and n2.nd_voie<>'' order by st_distance(n2.geom,geom)  limit 1) where nd_voie is null or nd_voie='';
update t_noeud set nd_voie = upper(nd_voie);

--valeur nd_coderat = nd_code NRO
update t_noeud set nd_coderat=(select st_nd_code from t_sitetech where st_typelog='NRO');

--t_ptech
update t_ptech set pt_etiquet = pt_codeext;

update t_ptech set pt_nature = (select type_ptech from temp_infra_points where code_ptech = pt_codeext);
update t_ptech set pt_nature='PBOI' where pt_nature='PBOIS';
update t_ptech set pt_statut='REC';
update t_ptech set pt_avct='E';
update t_ptech set pt_a_haut=5 where pt_typephy='F';
update t_ptech set pt_a_haut=(select pt_a_haut from x_t_ptech where x_t_ptech.pt_codeext = t_ptech.pt_codeext) where pt_typephy='A';
update t_ptech set pt_a_haut=0 where pt_typephy='C';
update t_ptech set pt_etat='OK';
update t_ptech set pt_dateins=pt_creadat;
update t_ptech set pt_a_dtetu =pt_creadat;
update t_ptech set pt_secu=False;

-- pour renseigner hauteur et rf_code
update t_ptech set pt_rf_code=(select rf_code from t_reference where rf_type='PT' and instr(rf_design,'CHAMBRE')>0 and instr(rf_design,pt_nature)>0) where pt_typephy='C';
update t_ptech set pt_rf_code='RF000000000075' where instr('L1C,L2C,L3C',pt_nature)>1;
update t_ptech set pt_rf_code=(select rf_code from t_reference where rf_type='PT' and instr(rf_design,'POTEAU BOIS')>0 and instr(rf_design,pt_a_haut ||'M')>0)where pt_typephy='A'  and pt_nature='PBOI';
update t_ptech  set pt_rf_code='RF000000000078' where pt_typephy='A'  and pt_nature='PBOI' and pt_rf_code is null or pt_rf_code='';
update t_ptech set pt_rf_code='RF000000002115' where pt_typephy='A' and pt_nature='PMET';
update t_ptech  set pt_rf_code='RF000000000079' where pt_typephy='A'  and pt_nature='PBET';
update t_ptech set pt_a_struc='Simple' where pt_prop='OR900000000010' and  instr('PBOI,PIND',pt_nature)>0;
update t_ptech set pt_gest_do='OR760000001759'; -- gestionnaire de voie = commune g�n�rique (� affiner)
-- update t_noeud set nd_voie = (select ad_nomvoie from t_adresse where ad_code in (select pt_ad_code from t_ptech where pt_nd_code=nd_code));

--t_sitetech
update t_noeud set nd_voie = (select ad_nomvoie from t_adresse where ad_code in (select st_ad_code from t_sitetech where st_nd_code=nd_code)) where (nd_type='ST' or nd_type='SH') and nd_voie is null;
update t_sitetech set st_dateins=date('now');
update t_sitetech set st_proptyp='CST';
update t_sitetech set st_etat ='OK';
update t_sitetech set st_proptyp='CST';
update t_sitetech set st_statut='REC';
--maj nom et codeext depuis donn�es d'entr�e
UPDATE t_sitetech 
SET st_nom = (
    SELECT numnoe 
    FROM noeuds 
    WHERE noeid = (
        SELECT fbt_key 
        FROM l_fbt_gra 
        WHERE fbt_tbl = 'NOEUDS' 
            AND gra_tbl = 'T_SITETECH' 
            AND gra_code = st_code
    )
) where st_typelog='SRO' or st_typelog='NRO';

UPDATE t_sitetech 
SET st_codeext = (
    SELECT noe_codext 
    FROM noeuds 
    WHERE noeid = (
        SELECT fbt_key 
        FROM l_fbt_gra 
        WHERE fbt_tbl = 'NOEUDS' 
            AND gra_tbl = 'T_SITETECH' 
            AND gra_code = st_code
    )
)where st_typelog='SRO' or st_typelog='NRO';

-- maj nblines
update noeuds set nblr = (select count(*) from liens_cabfib where connector='-#' and noe_key=noeid) where nblr=0;
update t_sitetech set st_nblines = (select st_nblines from x_t_sitetech where x_t_sitetech.st_codeext = t_sitetech.st_codeext) + (select count(*) from fr.liens_cabfib where connector='-#') where instr('SRO,NRO',st_typelog)>0;
update t_sitetech set st_nblines = (select nblr from noeuds,t_ltech, l_fbt_gra where noeid=fbt_key and lt_code = gra_code and lower(fbt_tbl)='noeuds' and lower(gra_tbl)='t_ltech' and lt_st_code=st_code) where instr('SRO,NRO',st_typelog)=0;

-- maj t_noeud d�pend de la maj t_nom de t_sitetech
update t_noeud set nd_r3_code=(select st_nom from t_sitetech where st_typelog='NRO');
update t_noeud set nd_r4_code=(select st_nom from t_sitetech where st_typelog='SRO');


--suppression adresse nro et SRO
update t_sitetech set st_ad_code=null where st_typelog='SRO' or st_typelog='NRO';
delete from t_adresse where ad_code not in(select sf_ad_code from t_suf) and ad_code not in (select pt_ad_code from t_ptech where pt_ad_code is not null) and ad_code not in (select st_ad_code from t_sitetech where st_ad_code is not null);

--t_ltech
update t_ltech set lt_proptyp='CST', lt_dateins=date('now');
update t_ltech set lt_elec=False, lt_clim='SANS';
UPDATE t_ltech SET lt_gest = t_sitetech.st_gest FROM t_sitetech WHERE t_ltech.lt_st_code = t_sitetech.st_code;
UPDATE t_ltech SET lt_prop = t_sitetech.st_prop FROM t_sitetech WHERE t_ltech.lt_st_code = t_sitetech.st_code;
update t_ltech set lt_statut='REC';
delete from t_ltech where lt_st_code not in (select st_code from t_sitetech);
update t_ltech set lt_codeext =(select st_codeext from t_sitetech where st_code = lt_st_code);
update t_ltech set lt_etiquet=lt_codeext;
update t_ltech_patch201 set lt_bat = (select ad_nomvoie from t_adresse, t_sitetech, t_ltech where st_ad_code = ad_code and st_code=lt_st_code and t_ltech.lt_code=t_ltech_patch201.lt_code); 
UPDATE t_ltech_patch201 
SET lt_bat = (
    SELECT n2.nd_voie 
    FROM t_noeud as n1
    INNER JOIN t_sitetech ON n1.nd_code = t_sitetech.st_nd_code
    INNER JOIN t_ltech ON t_sitetech.st_code = t_ltech.lt_st_code
    INNER JOIN t_ltech_patch201 as p1 ON t_ltech.lt_code = p1.lt_code
    CROSS JOIN t_noeud as n2  -- or add a proper JOIN condition here
    WHERE t_ltech_patch201.lt_code = p1.lt_code
      AND n2.nd_voie IS NOT NULL 
      AND n2.nd_voie <> ''
    ORDER BY st_distance(n2.geom, n1.geom)
    LIMIT 1);

--t_ebp
update t_ebp set bp_statut='REC';
update t_ebp set bp_proptyp='CST', bp_etat='OK';
update t_ebp set bp_avct='E';
delete from t_ebp where bp_typelog='NRO' or bp_typelog='SRO';
update t_ebp set bp_etiquet=bp_codeext;
update t_ebp set bp_rf_code='RF000000000083' where bp_typelog='PTO';--rf_code de la pto
update t_ebp set bp_rf_code='RF000000000093' where instr('PBO,BPE',bp_typelog)>0 and bp_pt_code in(select pt_code from t_ptech where pt_typephy='C') and (bp_rf_code is null or bp_rf_code='');
update t_ebp set bp_rf_code='RF000000000092' where (bp_rf_code is null or bp_rf_code='') and bp_code in 
        (select gra_code from l_fbt_gra 
        INNER JOIN noeuds ON l_fbt_gra.fbt_key = noeuds.noeid
        where instr(equipment ,'PBO NG Point de Branchement Optique pour facade ou poteau (PBO Taille 1)')>0
        and lower(fbt_tbl)='noeuds' and lower(gra_tbl)='t_ebp');
update t_ebp set bp_rf_code='RF000000000038' where (bp_rf_code is null or bp_rf_code='') and bp_code in 
        (select gra_code from l_fbt_gra 
        INNER JOIN noeuds ON l_fbt_gra.fbt_key = noeuds.noeid
        where instr(equipment ,'BPE T1')>0 and substr(pose,1,3)='CHB'
        and lower(fbt_tbl)='noeuds' and lower(gra_tbl)='t_ebp');
update t_ebp set bp_rf_code='RF000000000038' where instr('PBO,BPE',bp_typelog)>0 and bp_pt_code in(select pt_code from t_ptech where pt_typephy='A') and (bp_rf_code is null or bp_rf_code='');

--t_suf
update t_suf set sf_racco='RB',sf_oper='OR900000000010';
update t_noeud set nd_voie = (select ad_nomvoie from t_adresse where ad_code in (select sf_ad_code from t_suf where sf_nd_code=nd_code)) where nd_type='SF';

--t_cheminement
update t_cheminement set cm_gest_do=null where cm_gest_do='CG76';
update t_cheminement set cm_prop_do=null where cm_prop_do='CG76';
update t_cheminement set cm_geolmod = 'INDT' where cm_geolmod is null or cm_geolmod = '';
update t_cheminement set cm_creadat= date('now') where cm_creadat is null;
update t_cheminement set cm_mod_pos='NC' where cm_mod_pos is null or cm_mod_pos='';
update t_cheminement set cm_passage='NC';
update t_cheminement set cm_nature='NC';
update t_cheminement set cm_r1_code=(select nd_r1_code from t_noeud limit 1);  --where cm_r1_code is null or cm_r1_code='';
update t_cheminement set cm_r2_code=(select nd_r2_code from t_noeud limit 1); --where cm_r2_code is null or cm_r1_code='';
update t_cheminement set cm_r3_code=(select st_nom from t_sitetech where st_typelog='NRO') where cm_r1_code is null or cm_r3_code='';
update t_cheminement set cm_r4_code=(select st_nom from t_sitetech where st_typelog='SRO') where cm_r1_code is null or cm_r4_code='';
update t_cheminement set cm_majsrc='FIBREADY_138N';
update t_cheminement set cm_geolsrc='SIG NGE';
update t_cheminement set cm_long = st_length(geom) where cm_long<=0;
update t_cheminement set cm_lgreel = st_length(geom) where cm_lgreel<=0;


--t_cable
update t_cable set cb_statut='REC';
update t_cable set cb_avct='E' where cb_typelog='DI';
update t_cable set cb_etiquet = cb_codeext;
update t_cable set cb_etat='OK', cb_dateins=date('now');
update t_cable set cb_rf_code='RF000000000084' where cb_typelog='RA';
update t_cable set cb_diam=10, cb_color='NOIR';
update t_cable set cb_lgreel=(select st_length(geom) from t_cableline where cl_cb_code=cb_code);
update t_cable set cb_lgreel=10 where cb_lgreel is null and (cb_typelog='RA' or cb_code not in (select cl_cb_code from t_cableline)) ;
update t_cable set cb_r1_code=(select nd_r1_code from t_noeud limit 1);
update t_cable set cb_r2_code=(select nd_r2_code from t_noeud limit 1);
update t_cable set cb_r3_code=(select st_nom from t_sitetech where st_typelog='NRO');
update t_cable set cb_r4_code=(select st_nom from t_sitetech where st_typelog='SRO');

--t_cableline
update t_cableline set cl_geolmod='INDT', cl_geolsrc='SIG NGE', cl_majsrc='FR 138N', cl_geolqlt=0;

--t_zpbo
delete from t_zpbo where zp_nd_code is null or zp_nd_code='';
update t_zpbo set zp_r1_code=(select nd_r1_code from t_noeud limit 1);
update t_zpbo set zp_r2_code=(select nd_r2_code from t_noeud limit 1);
update t_zpbo set zp_r3_code=(select st_nom from t_sitetech where st_typelog='NRO');
update t_zpbo set zp_r4_code=(select st_nom from t_sitetech where st_typelog='SRO');

--t_znro
update t_znro set zn_r1_code=(select nd_r1_code from t_noeud limit 1);
update t_znro set zn_r2_code=(select nd_r2_code from t_noeud limit 1);
update t_znro set zn_r3_code=(select st_nom from t_sitetech where st_typelog='NRO');

--t_conduite
update t_conduite set cd_gest=null where cd_gest not in (select or_code from t_organisme);
update t_conduite set cd_prop=null where cd_prop not in (select or_code from t_organisme);
update t_conduite set cd_dateman=date('now');
update t_conduite set cd_etat='OK';
update t_conduite set cd_prop=(select cm_mut_org from t_cheminement, t_cond_chem where cm_code = dm_cm_code and dm_cd_code = cd_code) where cd_prop is null or cd_prop='';
update t_conduite set cd_gest=(select cm_mut_org from t_cheminement, t_cond_chem where cm_code = dm_cm_code and dm_cd_code = cd_code) where cd_gest is null or cd_gest='';
update t_conduite set cd_user='OR900000000010';
update t_conduite set cd_r1_code=(select nd_r1_code from t_noeud limit 1);
update t_conduite set cd_r2_code=(select nd_r2_code from t_noeud limit 1);
update t_conduite set cd_r3_code=(select st_nom from t_sitetech where st_typelog='NRO');
update t_conduite set cd_r4_code=(select st_nom from t_sitetech where st_typelog='SRO');

--t_position
delete from t_position where (ps_1 is null or ps_1='') and (ps_2 is null or ps_2='');
delete from t_position where ps_cs_code is not null and ps_cs_code not in(select cs_code from t_cassette);


--nettoyage surcapa
delete from t_position where ps_comment='SURCAPA' or ps_ti_code in(select ti_code from t_tiroir where instr('0,TD00',ti_etiquet)>0);
delete from t_cassette_patch201 where cs_code not in(select ps_cs_code from t_position);
delete from t_cassette where cs_code not in(select ps_cs_code from t_position);
delete from t_tiroir where ti_code not in(select ps_ti_code from t_position where ps_ti_code is not null) and ti_code not in(select cs_ti_code from t_cassette_patch201 where cs_ti_code is not null);

delete from t_tiroir where ti_code not in(select ti_code from t_cassette_patch201);
update t_position set ps_etat='OK';

--t_cassette
update t_cassette set cs_rf_code='RF000000000098' where cs_type='E';
update t_cassette set cs_rf_code='RF000000000099' where cs_type='C';
update t_cassette set cs_rf_code='RF000000000101' where cs_type='P';
delete from t_cassette where cs_bp_code is not null and cs_bp_code<>'' and cs_bp_code not in (select bp_code from t_ebp);
delete from t_cassette_patch201 where cs_code  not in (select cs_code from t_cassette);
delete from t_cassette_patch201 where cs_ti_code is null;

--tiroir
update t_tiroir set ti_type='TIROIR' where ti_type is null or ti_type='';
update t_tiroir set ti_comment = ti_etiquet;
update t_tiroir set ti_codeext = 'TD' || printf('%02d', ti_comment);
update t_tiroir set ti_etiquet = ti_codeext;
update t_tiroir set ti_rf_code ='RF000000000034', ti_taille=3, ti_prop='OR900000000010', ti_etat='OK', ti_placemt=0;

--baie
update t_baie set ba_type='BAIE' where ba_type is null or ba_type='';
update t_baie set ba_etiquet = 'B' || printf('%02d', ba_etiquet);
update t_baie set ba_etat = 'OK', ba_nb_u=0, ba_proptyp='CST';
update t_baie set ba_statut='REC';

--divers
update t_fibre set fo_proptyp='CST';
PRAGMA foreign_keys = ON;



