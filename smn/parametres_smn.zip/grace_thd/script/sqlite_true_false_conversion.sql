﻿
-- ================================================
-- REQUÊTES UPDATE
-- ================================================

BEGIN TRANSACTION;

UPDATE t_adresse SET ad_nat = 1 WHERE ad_nat = True;
UPDATE t_adresse SET ad_nat = 0 WHERE ad_nat = False;
UPDATE t_adresse SET ad_isole = 1 WHERE ad_isole = True;
UPDATE t_adresse SET ad_isole = 0 WHERE ad_isole = False;
UPDATE t_adresse SET ad_prio = 1 WHERE ad_prio = True;
UPDATE t_adresse SET ad_prio = 0 WHERE ad_prio = False;
UPDATE t_adresse SET ad_imneuf = 1 WHERE ad_imneuf = True;
UPDATE t_adresse SET ad_imneuf = 0 WHERE ad_imneuf = False;
UPDATE t_adresse SET ad_iaccgst = 1 WHERE ad_iaccgst = True;
UPDATE t_adresse SET ad_iaccgst = 0 WHERE ad_iaccgst = False;
UPDATE t_zsro SET zs_actif = 1 WHERE zs_actif = True;
UPDATE t_zsro SET zs_actif = 0 WHERE zs_actif = False;
UPDATE t_zsro SET zs_accgest = 1 WHERE zs_accgest = True;
UPDATE t_zsro SET zs_accgest = 0 WHERE zs_accgest = False;
UPDATE t_zsro SET zs_brassoi = 1 WHERE zs_brassoi = True;
UPDATE t_zsro SET zs_brassoi = 0 WHERE zs_brassoi = False;
UPDATE t_ltech SET lt_elec = 1 WHERE lt_elec = True;
UPDATE t_ltech SET lt_elec = 0 WHERE lt_elec = False;
UPDATE t_ptech SET pt_secu = 1 WHERE pt_secu = True;
UPDATE t_ptech SET pt_secu = 0 WHERE pt_secu = False;
UPDATE t_ptech SET pt_a_passa = 1 WHERE pt_a_passa = True;
UPDATE t_ptech SET pt_a_passa = 0 WHERE pt_a_passa = False;
UPDATE t_ptech SET pt_a_strat = 1 WHERE pt_a_strat = True;
UPDATE t_ptech SET pt_a_strat = 0 WHERE pt_a_strat = False;
UPDATE t_ptech SET pt_detec = 1 WHERE pt_detec = True;
UPDATE t_ptech SET pt_detec = 0 WHERE pt_detec = False;
UPDATE t_cheminement SET cm_fildtec = 1 WHERE cm_fildtec = True;
UPDATE t_cheminement SET cm_fildtec = 0 WHERE cm_fildtec = False;

-- Vérification après conversion :

COMMIT;
-- En cas de problème, utilisez : ROLLBACK;
