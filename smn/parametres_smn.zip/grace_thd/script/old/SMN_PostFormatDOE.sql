begin transaction;

/*
PRAGMA foreign_keys = OFF;
delete from t_tiroir where instr(lower(ti_comment),'optionnel')>0 and ti_code not in(select ps_ti_code from t_position where (ps_type is not null and ps_type<>''));
delete from t_cassette where cs_code in (select cs_code from t_cassette_patch201 where cs_ti_code not in(select ti_code from t_tiroir));
delete from t_position where (ps_type is not null and ps_type<>'') and ps_cs_code not in (select cs_code from t_cassette);
PRAGMA foreign_keys = ON;
*/

/*t_adresse*/
update t_adresse set ad_isole=null where ad_nblhab =0 and ad_nblpro=0;
update t_adresse set ad_ietat='DE' where ad_nblhab=0 and ad_nblpro=0;
update t_adresse set ad_iaccgst=0 where ad_itypeim='P';
update t_adresse set ad_gest = 'OR340000000394' where ad_itypeim= 'I';
update t_adresse set ad_iaccgst=1 where ad_itypeim='I';
update t_adresse set ad_nbprhab=null;--MCD: non demandé
update t_adresse set ad_nbprpro=null; --MCD: non demandé
update t_adresse set ad_numero=null where ad_numero=0;
--update t_adresse set ad_rep=null where ad_numero is null; --descativation le 29/06/2020 (Aude): les adresses null doivent avoir une lettre de Z à A, indiquée en DE
update t_adresse set ad_rep=null where ad_rep like 'NEW%';
update t_adresse set ad_idatcab = DATE ('NOW') where ad_code in (
	select distinct sf_ad_code from t_suf 
	left outer join t_zpbo_patch201 on sf_zp_code = zp_code
	left outer join t_ebp on zp_bp_code = bp_code 
	where bp_statut = 'REC'); --date de livraison de la première DOE

update t_adresse set ad_idatcom = date (ad_idatcab,'+3 month'); --idatcab + 3 mois
--ajout de l'information RL ou EXT dans ad_comment le 11/06/2020 (Aude)  En attente devis (ça devrait être ad_comment à renseigner (10/09/2020)
/*
update t_adresse set ad_comment=(select TYPE_DEPL from IMPORT_BAL where NOE_NUM=ad_batcode);
update t_adresse set ad_comment=null where ad_comment='IPE';
*/



/*t_cable*/
/*jointure grace a IMPORT_CABLE du 11/06/2020*/
update t_cable set cb_fo_disp=(select fibres_r from IMPORT_CABLES where code_cb=cb_codeext);
update t_cable set cb_fo_util=(select fibres_u from IMPORT_CABLES where code_cb=cb_codeext);
update t_cable set cb_lgreel=(select cb_lgreel from IMPORT_CABLES where code_cb=cb_codeext);
update t_cable set cb_lgreel = replace(cb_lgreel,",",".");
--cable de RAC: Aude le 18/06/2020
update t_cable set cb_fo_disp=0 where cb_typelog='RA';
update t_cable set cb_fo_util=1 where cb_typelog='RA';
--
update t_cable set cb_statut= (select cb_statut from t_cable as cab2 where cab2.cb_codeext=cb_codeext) where cb_statut='' and cb_typelog='RA' ;
update t_cable set cb_statut = 'AVP' where cb_typelog = 'RA';
update t_cable set cb_codeext = NULL where cb_typelog='RA'; --ajout le 07/01/2022 (Aude) pour forcer à vider le champ cb_codeext et cb_etiquet pour les cables de RACCO
update t_cable set cb_etiquet = cb_codeext;--étiquette équivalente au codeext
update t_cable set cb_proptyp= 'CST';--par défaut CST
update t_cable set cb_etat= (case
	when cb_statut='REC' then 'OK'
	else 'NC'
	end); --OK par défaut -- Aude la 12/11/2020:rectification: OK pour les REC, NC sinon 
update t_cable set cb_datemes = DATE('NOW') where cb_statut = 'REC' and cb_datemes is null;--prend la date du DOE
update t_cable set cb_avct ='E' where cb_statut='REC';--passe à E en DOE
update t_cable set cb_codeext=null where cb_typelog='RA'; --nettoyage des cb_codeext pour la livraison - pas de maintien des codes Grace

update t_cable set cb_rf_code = 'RF340000000166' where cb_codeext in (select code_cb from IMPORT_CABLES where commentair = 'PRE_FIBRE'); --Ajouté le 29/07/2021 pour les immeubles préfibrés



/*t_cableline*/
--update t_cableline set cl_geolmod = 'INDT'; --A REVOIR infos à faire remonter du terrain --MCD non demandé

/*t_cheminement*/
update t_cheminement set cm_r4_code=null; --MCD: à ne plus remplir
update t_cheminement set cm_geolmod = (case 
when cm_avct = 'C' and cm_typ_imp = '7' and cm_statut = 'REC' THEN 'DETC'
when cm_avct = 'C' and cm_typ_imp = '0' and cm_statut = 'REC'THEN 'DETC'
else 'INDT' --Aude le 13/11/2020: ajout de la contrainte REC
end); -- REGLE A CONFIRMER INDT pour les cheminements n'appartenant pas au département
--update t_cheminement set cm_datemes= DATE('NOW') where cm_avct ='C' and cm_statut = 'REC' and cm_datemes is null;non foncitonnel --date de mise en service = date du jour de la DOE pour le GC à créer
update t_cheminement set cm_datemes= DATE('NOW') where cm_avct ='C' and cm_statut = 'REC'  and (cm_datemes is null or cm_datemes = '');--date de mise en service = date du jour de la DOE pour le GC à créer
--update t_cheminement set cm_etat='OK' where cm_avct = 'C' and cm_typ_imp = '7' and cm_statut='REC'; --neuf donc OK pour le GC à créer
--update t_cheminement set cm_fildtec= 1 where cm_avct = 'C' and cm_typ_imp = '7' and cm_statut='REC'; --plynox pour le GC à créer --Aude le 13/11/2020: ajout de la contrainte REC
--update t_cheminement set cm_dtclass='A' where cm_avct = 'C' and cm_typ_imp = '7' and cm_statut='REC';--pour le GC à créer --Aude le 13/11/2020: ajout de la contrainte REC
--update t_cheminement set cm_geolqlt=0.4 where cm_avct = 'C' and cm_typ_imp = '7' and cm_statut='REC';--pour le GC à créer --Aude le 13/11/2020: ajout de la contrainte REC

--Aude le 13/11/2020: gestion fine des champs cm_etat, cm_fildtec, cm_dtclass, cm_geolqlt, cm_cddispo, cm_charge, cm_compo, cm_mod_pos
update t_cheminement set cm_etat=(case
	when cm_avct = 'C' and cm_statut='REC' then 'OK'
	else 'NC'
	end); 
update t_cheminement set cm_fildtec=(case
	when cm_avct = 'C' and cm_typ_imp = '7' and cm_statut='REC' then 1
	else null
	end);
update t_cheminement set cm_dtclass=(case
	when cm_avct = 'C' and cm_statut='REC' and cm_typ_imp = '7' then 'A'
	else null
	end); 
update t_cheminement set cm_geolqlt=(case
	when cm_avct = 'C' and cm_statut='REC' and cm_typ_imp = '7' then 0.4
	else null
	end);
update t_cheminement set cm_cddispo = null where cm_statut!='REC';	
update t_cheminement set cm_charge = null where cm_statut!='REC';
update t_cheminement set cm_compo = null where cm_statut!='REC' or cm_typ_imp!=7 or cm_avct !='C';

update t_cheminement set cm_mod_pos='TRA' where cm_mod_pos='TRADITIONNEL';
update t_cheminement set cm_mod_pos= null where cm_statut!='REC';


/*t_conduite*/
update t_conduite set cd_prop = 'OR340000000392' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='C';--proriétaire=departement pour tout ce qui est à construire
update t_conduite set cd_prop = 'OR340000000002' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=7 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=0);--ORANGE pour les conduites de type 7 existantes ou pour l'aérien ORANGE
update t_conduite set cd_prop = 'OR340000000001' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=1;--ENEDIS pour l'aérien ERDF
update t_conduite set cd_prop = 'OR340000000394' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--PRIVE pour les facades et le cheminement immeuble	
update t_conduite set cd_proptyp='OCC' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--OCC pour les facades et le cheminement immeuble	
update t_conduite set cd_user='OR340000000400' ; --utilisateur du fourreau est la DSP A VERIFIER
update t_conduite set cd_etat = 'OK' where cd_statut='REC';--ok pour bon état par défaut: MCD
update t_conduite set cd_datemes = DATE('NOW') where cd_statut = 'REC' and cd_datemes is null;--date de la DOE
update t_conduite set cd_nbcable=null;--pas demandé dans le MCD
update t_conduite set cd_type = 'NC' where cd_avct= 'E' or cd_statut !='REC';--cd_type nécessaire uniquement pour le GC à créer --Aude le 13/11/2020: regroupement des deux requêtes
--update t_conduite set cd_etat = 'NC' where cd_statut != 'REC';

/*t_ebp*/
update t_ebp set bp_etiquet = bp_codeext where bp_typelog<>'PTO';--etiquette = codeext de la BPE par défaut
update t_ebp set bp_codeext=null where bp_typelog='PTO'; --pas de codeext pour les PTO
update t_ebp set bp_statut = 'AVP' where bp_typelog='PTO';
update t_ebp set bp_etat = 'OK' where bp_statut='REC';--OK car on ne pose que du neuf
update t_ebp set bp_etat = 'NC' where bp_statut<>'REC';
update t_ebp set bp_datemes = DATE('NOW') where bp_statut='REC' and bp_datemes is null and bp_typelog='PBO' ;--date de livraison de la DOE uniquement pour les PBO
update t_ebp set bp_avct = 'E' where bp_statut ='REC';--passe à E pour le statut DOE
update t_ebp set bp_nb_pas = null; --vide pour tous les éléments grace à t_reference
update t_ebp set bp_ca_nb=null; --MCD: à vider

/* t_ptech */
--Reecriture du script du pt_proptyp à partir de TEMP_INFRA_POINT 11/06/2020 (AUDE)	+ deplacement en tête de partie pour que les GC soient pris en compte par la suite (pt_secu, pt_occp) le 18/06/2020
update t_ptech set pt_proptyp='LOC' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where contrat in('BLO','LOCATION'));
update t_ptech set pt_proptyp='OCC' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where contrat = 'OCCUPATION');
update t_ptech set pt_proptyp='CST' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where contrat = 'CONSTRUCTION');	
update t_ptech set pt_avct='C' where pt_proptyp='CST'; --pt_avct: forcer à C si construction même en REC le 11/06/2020 (Aude)

/*Aude le 04/09/2020 à la demande de Arnaud*/
update t_ptech set pt_prop='OR340000000392' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio='DELEGANT');
update t_ptech set pt_gest='OR340000000400' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where gestion='DSP');
update t_ptech set pt_prop='OR340000000395' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio='RIP EXISTANT');
update t_ptech set pt_gest='OR340000000395' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where gestion='RIP EXISTANT');
/*Aude la 02/11/2020 pour les facades qui sont des éléments existants privés --> en attente d'une validation Herault
update t_ptech set pt_prop='OR340000000394' where pt_typephy='F';
update t_ptech set pt_gest='OR340000000394' where pt_typephy='F';*/
--Ajout du proprio et gestionnaire PRIVE le 07/01/2022 (Aude)
update t_ptech set pt_prop='OR340000000394' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio='PRIVE');
update t_ptech set pt_gest='OR340000000394' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where gestion='PRIVE');

--update t_ptech set pt_gest_do='A REMPLIR' where pt_avct='C' and pt_gest_do is null;--A REMPLIR manuellement avec le gestionnaire de la voie là où il y a la mention A REMPLIR --A DEVELOPPER: utiliser les DE pour remplir ce cham^p
update t_ptech set pt_datemes = DATE('NOW') where pt_statut = 'REC' and pt_avct='C';--mise à jour du champ pt_datemes avec la date de la DOE si ptech est en CST -- Aude le 29/06/2020
update t_ptech set pt_etat = 'OK' where pt_prop='OR340000000392';--OK pour les points techniques à créer, appartenant à la DSP
update t_ptech set pt_typelog = 'T' where pt_code not in (select bp_pt_code from t_ebp where bp_typelog in ('BPE','PBO'));
update t_ptech set pt_typelog = 'R' where pt_code in (select bp_pt_code from t_ebp where bp_typelog in ('BPE','PBO'));
update t_ptech set pt_detec = 1 where pt_avct='C' and pt_typephy='C'; --pas de boitier pour plynox par défaut dans les chambres à créer
--update t_ptech set pt_occp='1.1' where pt_avct='C' and pt_typephy='C' and pt_code in (select bp_pt_code from t_ebp where bp_typelog='BPE');--par défaut = NON VIDE EXPLOITABLE car chambre neuve de la DSP
--update t_ptech set pt_occp='0' where pt_avct='C' and pt_typephy='C' and pt_code not in (select bp_pt_code from t_ebp where bp_typelog='BPE');--par défaut VIDE pour les chambres de la DSP sans BPE
update t_ptech set pt_occp='1.1' where pt_avct='C' and pt_typephy='C';--en attente de règles plus claires
update t_ptech set pt_secu='1' where pt_avct='C' and pt_typephy='C';--0 ou 1  A REMPLIR avec 1 pour les chambres sécurisées de la DSP
update t_ptech set pt_rf_code = null; --champ à ne pas remplir (MCD)
update t_ptech set pt_etiquet=pt_codeext where pt_proptyp='CST';

--pt_nature --recuperation type_ptech le 07/01/2022 (Aude)
update t_ptech set pt_nature = (CASE
	when pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where type_ptech like 'POTEAU BOIS%') then 'PBOI'
	when pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where type_ptech like 'POTEAU METALLIQUE%') then 'PMET'
	when pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where type_ptech like 'POTEAU BETON%') then 'PBET'
	when pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where type_ptech like 'POTELET%') then 'POTL'
	else pt_nature
	end);
	

/* t_noeud */ 
--deplacement après ptech pour récupérer les infos de chambres GC (Aude) LE 18/06/2020 -- Ajout de staut REC le 17/11/2020
update t_noeud set nd_dtclass='A' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C' and pt_statut='REC'); -- classe A pour le GC à créer: classe de précision
update t_noeud set nd_geolqlt=0.4 where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C' and pt_statut='REC'); -- 0.4 pour le GC à créer: précision du positionnement de l'objet
update t_noeud set nd_geolmod='DETC' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C' and pt_statut='REC'); -- mode d'implantation de l'objet ATTENTION A VERIFIER (LTRO: levé durant la pose; LVIS: levé après la pose; DETC: levé avec détection)



/* t_ltech */
update t_ltech set lt_proptyp = 'CST' where lt_st_code in (select st_code from t_sitetech where st_typelog='NRO' OR st_typelog = 'SRO'); --CST pour le NRO et le SRO
update t_ltech set lt_proptyp = 'OCC' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT');--OCC pour les immeubles
update t_ltech set lt_elec =null; --MCD: non demandée
update t_ltech set lt_clim =null; --MCD: non demandée
update t_ltech set lt_occp =null; --MCD: non demandée
update t_ltech set lt_statut = (select bp_statut from t_ebp where bp_lt_code = lt_code) where lt_gest='OR340000000394';--même statut que l'EBP où est le ltech
update t_ltech set lt_statut ='REC' where lt_gest='OR340000000400'; --statut à REC pour les SRO et NRO
update t_ltech set lt_local ='A REMPLIR' where lt_st_code in (select st_code from t_sitetech where st_typelog='CLIENT') and lt_statut='REC'; -- A REMPLIR pour les immeubles: positionnement de la BPI

--remplir lt_local à partir du champ lt_local à ajouter à la table BPE (string 255) ajouter le 07/01/2022, à valider
update t_ltech set lt_local= (select lt_local from IMPORT_BPE where code_bpe = (select bp_codeext from t_ebp where bp_lt_code = lt_code));


--modification du lt_etat à NC, sauf pour ce qui est construit au statut REC -> OK (Aude) le 07/01/2022
update t_ltech set lt_etat= (CASE
	when lt_statut='REC' and lt_proptyp = 'CST' then 'OK'
	else 'NC'
	end);


/* t_sitetech */
update t_sitetech set st_proptyp='OCC' where st_typelog='CLIENT'; --OCCUPATION par défaut
update t_sitetech set st_proptyp='CST' where st_typelog in ('NRO','SRO');
update t_sitetech set st_statut = (select lt_statut from t_ltech where lt_st_code = st_code ); --même statut que le ltech qui le porte
update t_sitetech set st_avct=null;--MCD: non demandé
update t_sitetech set st_etat='OK' where st_statut='REC';
update t_sitetech set st_etat='NC' where st_statut<>'REC';

update t_ltech set lt_codeext=(select replace(st_codeext,'HT-TEC','HT-LT') || '-01' from t_sitetech where st_code = lt_st_code) where lt_prop='OR340000000392';--Aude le 29/06/2020


/* t_suf */
update t_suf set sf_racco = 'RB' where sf_ad_code in (select ad_code from t_adresse where ad_isole = 0);--pour raccordable (liaison PM-PBO)
update t_suf set sf_racco = 'RD' where sf_ad_code in (select ad_code from t_adresse where ad_isole = 1);--pour raccordable sur demande
--update t_suf set sf_comment =
--	(select TYPE_DEPL from IMPORT_BAL where NOE_NUM= (select ad_batcode from t_adresse where sf_ad_code=ad_code)); A activer dés acceptation devis de la part de Covage!


/* t_zsro */
update t_zsro set zs_refpm=zs_r3_code; --équivalent à st_codeext pour les SRO
update t_zsro set zs_etatpm='DP'; -- passage à DP par défaut DOE
update t_zsro set zs_typeing ='MONO';--MONO par défaut 
update t_zsro set zs_dateins=DATE('NOW') where zs_dateins is null;--date du jour de la DOE si pas remplit en DE
--update t_zsro set zs_datcomr =substr(DATE('NOW'),1,4)||'-'||substr('0'||substr((DATE('NOW')),6,2)+3,-2)||'-'||substr(DATE('NOW'),9,2);
update t_zsro set zs_datcomr = date(zs_dateins,'+3 month');

/*t_znro*/
update t_znro set zn_etat='DP';--MCD: valeur par défaut DP car uniquement en DOE
update t_znro set zn_etatlpm=null;--MCD à vider

/*t_baie*/
update t_baie set ba_user = 'OR340000000400'; -- Herault THD par défaut
update t_baie set ba_proptyp='CST'; --construction par défaut
update t_baie set ba_statut = (select lt_statut from t_ltech where ba_lt_code = lt_code); --même staut que le local technique
update t_baie set ba_etat= 'OK' where ba_statut='REC'; -- OK par défaut car neuf quand statut est REC
update t_baie set ba_etat= 'NC' where ba_statut<>'REC'; --NC quand le statut n'est pas encore à REC
update t_baie set ba_type ='BAIE'; -- BAIE par défaut

update t_baie set  ba_rf_code = (select case 
when zs_nblogmt <= 460 then  'RF340000000003'
when zs_nblogmt > 460 then  'RF340000000004'
when zs_nblogmt=0 then null
end
from t_zsro 
join t_sitetech on  zs_nd_code= st_nd_code
join t_ltech on st_code = lt_st_code
join t_baie on  ba_lt_code = lt_code);

update t_baie set ba_rf_code='RF340000000001' where ba_lt_code in (select lt_code from t_ltech, t_sitetech where st_code=lt_st_code and st_typelog='NRO'); --reference de la baie pour le baie du NRO
update t_baie set ba_nb_u = (case
									when ba_rf_code ='RF340000000003'  then 28
									when ba_rf_code='RF340000000004' then 40
									when ba_rf_code='RF340000000001' then 40
								end); --nbre de u selon la reference de la baie
update t_baie set ba_codeext= 'HT-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code)|| '-' || substr('0' || ba_etiquet,-2);--increment du lt_codeext avec le prefixe HT-ARM- et le suffixe de l'étiquette de la baie02
update t_baie set ba_etiquet = ba_codeext;--par défaut l'étiquette de la baie est le codeext de la baie
update t_baie set ba_prop=(select st_prop from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code);--même propriétaire que le site technique
update t_baie set ba_gest=(select st_gest from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code); --même gestionnaire que le site technique

/* t_tiroir */
delete from t_tiroir where ti_ba_code='' or ti_ba_code=null;--supprimer les tiroirs qui ne correspondent pas à une baie
update t_tiroir set ti_codeext= 'HT-TIR-' || (select substr(ba_codeext,8,8) from t_baie where ti_ba_code = ba_code)||'-'||SUBSTR('00' || ti_etiquet,-2);--tiroir prend l'increment de la baie + numéro du tiroir
update t_tiroir set ti_prop= (select ba_prop from t_baie where ti_ba_code = ba_code);--propriétaire du tiroir = propriétaire de la baie
update t_tiroir set ti_etat = 'OK'; --on pose du neuf donc OK
--update t_tiroir set ti_taille ='3'; --3 par défaut: A corriger quand on aura tiroir de transport sur 2 U (utiliser la reference)

/*Gestion des tiroirs de transport: --Ajout Aude la 12/02/2021 */
update t_tiroir set ti_rf_code='RF340000000156' where ti_code = (select ti_code from t_tiroir join t_baie on ti_ba_code=ba_code where ba_nb_u=40 and ti_etiquet='13');--tiroir 48fo pour le tiroir 13 d'une baie 28U
update t_tiroir set ti_rf_code='RF340000000147' where ti_code = (select ti_code from t_tiroir join t_baie on ti_ba_code=ba_code where ba_nb_u=28 and ti_etiquet='09');--tiroir 96fo pour le tiroir 9 d'une baie 28U
update t_tiroir set ti_rf_code='RF340000000147' where ti_code = (select ti_code from t_tiroir join t_baie on ti_ba_code=ba_code where ba_nb_u=28 and ti_etiquet='10');--tiroir 96fo pour le tiroir 10 d'une baie 28U
update t_tiroir set ti_taille= (case	
									when ti_rf_code= 'RF340000000156' then 1
									when ti_rf_code= 'RF340000000147' then 2
									when ti_rf_code= 'RF340000000005' then 3
								end);--nbre de U selon la reference du tiroir					

/*t_cassette*/
delete from t_cassette_patch201 where cs_ti_code not in (select ti_code from t_tiroir);--supprime le cs_ti_code pour les tiroirs non existants 
update t_cassette set cs_face =null;--MCD: ne pas remplir
update t_cassette set cs_type=null;--MCD: ne pas remplir
update t_cassette set cs_bp_code=null where cs_bp_code not in (select bp_code from t_ebp);--vider les bp_code des cassettes dans les NRO et SRO

update t_cassette set cs_nb_pas=24 where cs_bp_code is null; --cassette de 24 dans les tiroirs
update t_cassette set cs_nb_pas=6 where cs_bp_code in (select bp_code from t_ebp where bp_rf_code in ('RF340000000167','RF340000000168')); --ajout le 29/07/2021 pour les immeubles préfibrés

update t_cassette set cs_nb_pas=null where cs_num=0;

/* t_fibre */
update t_fibre set fo_nincab = null;--pas demandé dans le MCD
update t_fibre set fo_type = 'G657';--par défaut
update t_fibre set fo_color = null;--pas demandé MCD
update t_fibre set fo_reper = null;--pas demandé MCD
update t_fibre set fo_code_ext = null;--pas demandé MCD

/*t_position*/ --Aude le 10/11/2020: traitement des tiroir 0
update t_position set ps_fonct='AT' where ps_ti_code in (select ti_code from t_tiroir where substr(ti_codeext ,17,2)='00');
update t_position set ps_type = 'SFU' where ps_fonct = 'EP';--ps_type depend de ps_fonct
update t_position set ps_type = 'CSA' where ps_fonct = 'CO';--ps_type depend de ps_fonct
update t_position set ps_type = null where ps_fonct = 'AT';--ps_type depend de ps_fonct

update t_cable_patch201 set cb_bp1=null where cb_bp1 not in (select bp_code from t_ebp);
update t_cable_patch201 set cb_bp2=null where cb_bp2 not in (select bp_code from t_ebp);

/*Aude le 02/11/2020: mise à jour du bp_typephy comme demandé par Covage*/
update t_ebp set bp_typephy = (case
	when bp_rf_code = 'RF340000000124' then 'B024'
	when bp_rf_code = 'RF340000000161' then 'B048'
	when bp_rf_code = 'RF340000000115' then 'B012'
	when bp_rf_code = 'RF340000000164' then 'B012'
	when bp_rf_code = 'RF340000000165' then 'B012'
	when bp_rf_code = 'RF340000000125' then 'B072'
	when bp_rf_code = 'RF340000000126' then 'B144'
	when bp_rf_code = 'RF340000000128' then 'B288'
	when bp_rf_code = 'RF340000000117' then 'B288'
	when bp_rf_code = 'RF340000000155' then 'B432'
	when bp_rf_code = 'RF340000000118' then 'B576'
	when bp_rf_code = 'RF340000000154' then 'AUTR'
	when bp_rf_code = 'RF340000000119' then 'B720'
	when bp_rf_code = 'RF340000000153' then 'AUTR'
	when bp_rf_code = 'RF340000000139' then 'B048'
	when bp_rf_code = 'RF340000000150' then 'AUTR'
	when bp_rf_code = 'RF340000000162' then 'B144'
	when bp_rf_code = 'RF340000000139' then 'B048'
	when bp_rf_code = 'RF340000000152' then 'B144'
	when bp_rf_code = 'RF340000000163' then 'AUTR'
	when bp_rf_code = 'RF340000000127' then 'AUTR'
	when bp_rf_code = 'RF340000000129' then 'AUTR'
	when bp_rf_code = 'RF340000000149' then 'AUTR'
	when bp_rf_code = 'RF340000000167' then 'AUTR' 
	when bp_rf_code = 'RF340000000168' then 'AUTR'
	when bp_rf_code = 'RF340000000169' then 'AUTR' -- modif anais 110722
end); -- + ajout des 3 dernières ref le 29/07/2021 pour les immeubles préfibrés

end transaction;

begin transaction;
--update t_sitetech set st_datemes =DATE('NOW') where st_statut = 'REC' and st_datemes is null; --lorsque datemes est vide, et que le statut est passé à REC, le champ prend la date du jour, si non vide, il garde la date précédente

--update t_ltech set lt_datemes = DATE('NOW') where lt_statut = 'REC' and lt_datemes is null;--prend la dat du jour la première fois que le statut passe à REC
update t_conduite set cd_datemes = DATE('NOW') where cd_statut = 'REC' and cd_datemes is null;--date de la DOE
update t_tiroir set ti_etiquet= ti_codeext;--tiquette du tiroir = codeext du tiroir en attente régles étiquettage 
end transaction;

begin transaction;
insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in ( select lt_code from t_ltech_patch201 ); -- corrige ltech_patch201 permet d'avoir le même nombre d'entités dans ltech et ltech_patch201
end transaction;

begin transaction; --Aude le 25/11/2020: supprimer les positions vides lorsque plus de positions pour une K7 que le cs_nb_pas
delete from t_position where ps_code in (select ps_code
from t_position 
join t_cassette on ps_cs_code=cs_code 
where (ps_1 is null or ps_1 = "") and (ps_2 is null or ps_2 = "") and ps_cs_code in (select cs_code from t_cassette where cs_nb_pas <(SELECT count(ps_code) from t_position where ps_cs_code=cs_code) and cs_num!=0 and cs_bp_code is not null)
and ps_numero > cs_nb_pas);
end transaction;


--begin transaction; --remplir les tables t_cassette_patch201 et t_ltech_patch201 avec tous les éléments (requêtes à suppr quand ce sera ok pour Rdeha)
--insert into t_cassette_patch201 (cs_code) select cs_code from t_cassette where cs_bp_code is not null;
--insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_prop='OR34000000000392';
--end transaction;

/*Si ils demandent à ce qu'on retire les conduites autres que celles créées*/
/*
begin transaction;
delete from t_conduite where cd_prop != 'OR34000000000395'; -- on ne garde que les conduites crées par HERAULT THD
delete from t_cond_chem where dm_cd_code not in (select cd_code from t_conduite);--reitrer les cond_chem qui n'appartiennet pas à des cheminement à créer
delete from t_cab_cond where cc_cd_code not in (select cd_code from t_conduite); --retirer les cab_cond qui n'appartiennet pas à des cheminement à créer
end transaction;*/