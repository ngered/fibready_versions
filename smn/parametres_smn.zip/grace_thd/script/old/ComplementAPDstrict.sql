begin transaction;
	update t_adresse set ad_ietat='CI';
	
	delete from t_fibre;--vider la table t_fibre pour strict APD seulement
	delete from t_position;--vider la table t_position pour strict APD seulement
	delete from t_ropt;--vider la table t_ropt pour strict APD seulement
end transaction;