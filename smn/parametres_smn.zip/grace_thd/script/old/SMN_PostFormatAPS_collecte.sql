﻿begin transaction;
/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep); --mettre en majuscule la répétition
update t_adresse set ad_commune=upper(ad_commune); --mettre en majuscule la commune 
update t_adresse set ad_nomvoie=upper(ad_nomvoie); --mettre en majuscule la voie
update t_adresse set ad_x_ban=X(geom); --remplir par la coordonnées x en lambert93
update t_adresse set ad_y_ban=Y(geom);--remplir par la coordonnées y en lambert93
update t_adresse set ad_numero = 0 where ad_numero is null ; -- remplace null par 0 pour les adresses sans numéro de voie
update t_adresse set ad_comment =  substr (ad_comment , (length (ad_comment)/2)) ; -- dédouble le champ commentaire qui a à l'origine les commentaires répétés 2 fois

/*t_noeud */
update t_noeud set nd_codeext=null; --vider la colonne nd_codeext
update t_noeud set nd_r1_code='HERAULT THD'; -- mettre HERAULT THD dans le r1_code
update t_noeud set nd_r2_code = null;
update t_noeud set nd_r3_code = null;	
update t_noeud set nd_type_ep= 'OPT'; 
update t_noeud set nd_coderat=null;

/*t_ebp*/
update t_ebp set bp_etiquet=null;


/*t_ptech*/
update t_ptech set pt_codeext = replace (substr (pt_codeext,1,12), 'HT-BPE','HT-PT'); 
update t_ptech set pt_etiquet = pt_codeext;
update t_ptech set pt_proptyp = (case
	when pt_avct = 'C' then 'CST'
	when pt_avct = 'E' and pt_typephy in ('A','C') then 'LOC'
	when pt_avct = 'E' and pt_typephy in ('I','F') then 'OCC'
	end);--pt_proptyp=CST pour le GC à créer; LOC pour l'existant et OCC pour les immeubles et facades

/*t_sitetech */
update  t_sitetech set st_codeext = (select ad_batcode from t_adresse where ad_code = st_ad_code);
update t_sitetech set st_prop='OR340000000392';
update t_sitetech set st_gest= 'OR340000000400';
update t_sitetech set st_nom='N034'||(select st_nom from t_sitetech where st_typelog='NRO')||'_S00' ;

/*t_cable*/
update t_cable set cb_r1_code='HERAULT THD'; --r1_code=HERAULT THD par défaut
update t_cable set cb_gest='OR340000000400';--gestionnaire du câble est HERAULT THD

/*t_cheminement*/
update t_cheminement set cm_r1_code = 'HERAULT THD'; --r1_code =HERAULT THD par défaut
update t_cheminement set cm_nature = (case
	when cm_typ_imp = '1' THEN 'ELE'
	else 'TEL'end);--remplissage de cm_nature avec ELE (electrique) pour le type implantation=1, sinon TEL (telecom) pour tous les autres cas

--delete from t_ebp where bp_typelog in ('NRO', 'SRO');
delete from t_cableline where cl_long=0;

end transaction;
