﻿begin transaction;

/* redha */
--> t_sitetech
update t_sitetech set st_prop='OR900000000010', st_gest='OR900000000010', st_user ='OR900000000010' where st_typelog in ('NRO','SRO');
update t_sitetech set st_prop='OR900000000010', st_gest='OR900000000010', st_user ='OR900000000010' ;
update t_sitetech set st_prop='OR000000000017', st_gest='OR000000000017' where st_typelog<>'CLIENT';
update t_sitetech set st_etat ='OK';
update t_sitetech set st_proptyp='CST';
update t_sitetech set st_nom=(select st_nom from t_sitetech where st_typelog='NRO') || '_S' || substr('000' || st_nom,-3) where st_typelog = 'SRO';

--> t_ebp
delete from t_ebp where bp_typelog in ('NRO','SRO');
update t_ebp set bp_prop='OR900000000010', bp_gest='OR900000000010', bp_user='OR900000000010';
update t_ebp set bp_proptyp='CST', bp_etat='OK';

--> t_cable
update t_cable set  cb_prop='OR900000000010', cb_gest='OR900000000010', cb_user='OR900000000010', cb_proptyp='CST';

--> t_noeud
update t_noeud set nd_r1_code='DSP1';
update t_noeud set nd_r2_code='MS4';
update t_noeud set nd_codeext=null; --vider la colonne nd_codeext
update t_noeud set nd_type_ep= 'OPT';
/*valeur par defaut nd_coderat*/
update t_noeud set nd_coderat = nd_code where nd_type='PT';
/*pour suf valeur nd_coderat = nd_code NRO*/
update t_noeud set nd_coderat=(select st_nd_code from t_sitetech where st_typelog='NRO') where nd_type<>'PT';
update t_noeud set nd_r3_code=(select st_nom from t_sitetech where st_typelog='NRO');
update t_noeud set nd_r4_code=(select st_nom from t_sitetech where st_typelog='SRO');
update t_noeud set nd_type_ep='OPT';

--> t_ptech
update t_ptech set pt_etiquet = pt_codeext;
update t_ptech set pt_prop='OR900000000027' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='INDERTEMINE');
update t_ptech set pt_prop='OR900000000001' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='ENEDIS');
update t_ptech set pt_prop='OR900000000016' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='ORANGE');
update t_ptech set pt_prop='OR900000000010' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='SEINE MARITIME NUMERIQUE');
update t_ptech set pt_prop='OR000000000017' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio ='LES COPROPRIETAIRES');
update t_ptech set pt_user='OR000000000010';
update t_ptech set pt_gest=pt_prop;
update t_ptech set pt_nature = (select type_ptech from temp_infra_points where code_ptech = pt_codeext);



/*t_adresse */
update t_adresse set ad_rep=upper(ad_rep); --mettre en majuscule la répétition
update t_adresse set ad_commune=upper(ad_commune); --mettre en majuscule la commune 
update t_adresse set ad_nomvoie=upper(ad_nomvoie); --mettre en majuscule la voie
update t_adresse set ad_x_ban=X(geom); --remplir par la coordonnées x en lambert93
update t_adresse set ad_y_ban=Y(geom);--remplir par la coordonnées y en lambert93
update t_adresse set ad_itypeim = (case 
	when substr (ad_batcode,1,6) = 'HT-BAT' and cast (ad_nblhab as INTEGER) + cast (ad_nblpro as INTEGER) >= 4 then 'I'
	when substr (ad_batcode,1,6)  = 'HT-BAT' and  cast (ad_nblhab as INTEGER) + cast (ad_nblpro as INTEGER) < 4 then 'P'
	when substr (ad_batcode,1,6)  = 'HT-TEC'then null
	end); -- calcul du caractère immeuble ou pavillon des bâtiments selon le nbre prises hab et le nbre prises pro
update t_adresse set ad_numero = 0 where ad_numero is null ; -- remplace null par 0 pour les adresses sans numéro de voie
--update t_adresse set ad_comment =  substr (ad_comment , (length (ad_comment)/2)) ; -- dédouble le champ commentaire qui a à l'origine les commentaires répétés 2 fois
update t_adresse set ad_comment = null; --Aude le 08/12/2020: vider complétement le ad_comment au cas où il reste des commentaires
update t_adresse set ad_typzone = null; --vide la colonne ad_typzone non demandée en APS

update t_adresse set ad_nbprhab=ad_nblhab;
update t_adresse set ad_nbprpro=ad_nblpro;
/*--ajout de l'information RL ou EXT dans ad_comment le 11/06/2020 (Aude)
update t_adresse set ad_comment=(select TYPE_DEPL from IMPORT_BAL where NOE_NUM=ad_batcode);
update t_adresse set ad_comment=null where ad_comment='IPE';
*/
/* Aude le 03/12/2020: ad_racc en cohérence avec FL (pas encore demandé)
update t_adresse set ad_racc=(case
	when (select MODE_RACCO from IMPORT_BAL where NOE_NUM=ad_batcode)="IMMEUBLE" then 3
	when (select MODE_RACCO from IMPORT_BAL where NOE_NUM=ad_batcode)="SOUTERRAIN" then 7
	when (select MODE_RACCO from IMPORT_BAL where NOE_NUM=ad_batcode)="AERIEN" then 0
	else 7
	end);*/
update t_adresse set ad_racc=7 where (ad_nblhab=0 and ad_nblpro=0);--mode de raccordement du SRO et NRO =7 par défaut




/*Patch reprojection IMB et reaffectation ndcode*/
/*initialisation base*/
PRAGMA foreign_keys = false;

/*effacement des tables temporaires si existante*/
drop table if exists tmp_IMM_idx;
drop table if exists AD_IMM_idx;
drop table if exists tmp_CHEM;

/*tab temp de base FR.FBT OR pour liaison avec base sortie Gr@ce*/

create table tmp_IMM_idx (
code_BPE_IMM_OR VARCHAR,
ROWID_BPE_IMM_OR INT,
GEOM_OR POINT);

insert into tmp_IMM_idx select NumNoe, noeId , Geometry from NOEUDS where pose='IMM' and substr(NumNoe,14,2)='01';

/*tab temp de base Gr@ce.tmp */

create table AD_IMM_idx (
code_IMM_GR VARCHAR,
ROWID_AD_IMM_GR Int,
GEOM_GR POINT);

insert into AD_IMM_idx select ad_batcode, rowId, geom from t_adresse where ad_itypeim='I';

alter table AD_IMM_idx
ADD ROWID_ND_IMM_GR Int;

update AD_IMM_idx set ROWID_ND_IMM_GR = (select rowid from t_noeud where substr(nd_codeext,8,5) = substr(code_IMM_GR,8,5));

alter table AD_IMM_idx
ADD CDEXT_ND_IMM_GR Int;
update AD_IMM_idx set CDEXT_ND_IMM_GR = (select ND_CODEEXT from t_noeud where substr(nd_codeext,8,5) = substr(code_IMM_GR,8,5));

update AD_IMM_idx set GEOM_GR = (select GEOM_OR from tmp_IMM_idx where substr(code_BPE_IMM_OR,8,5)=substr(code_IMM_GR,8,5));

alter table AD_IMM_idx
ADD ND_CODE_IMM_GR VARCHAR;
update AD_IMM_idx set ND_CODE_IMM_GR = (select nd_code from t_noeud where AD_IMM_idx.CDEXT_ND_IMM_GR = nd_codeext);

alter table AD_IMM_idx 
ADD TXT_GEOM_GR VARCHAR;
update AD_IMM_idx set TXT_GEOM_GR = astext(geom_GR);

delete from AD_IMM_idx where GEOM_GR is Null;

/*update t_adresse_geom et t_noeud_geom*/

UPDATE t_adresse
SET
      geom = (SELECT pointfromwkb(asbinary(AD_IMM_idx.GEOM_GR),2154) 
                            FROM AD_IMM_idx
                            WHERE AD_IMM_idx.ROWID_AD_IMM_GR = t_adresse.rowid )
    
WHERE
    EXISTS (
        SELECT *
        FROM AD_IMM_idx
        WHERE AD_IMM_idx.ROWID_AD_IMM_GR = t_adresse.rowid
    );

UPDATE t_noeud
SET
      geom = (SELECT pointfromwkb(asbinary(AD_IMM_idx.GEOM_GR),2154) 
                            FROM AD_IMM_idx
                            WHERE AD_IMM_idx.ROWID_ND_IMM_GR = t_noeud.rowid )
    
WHERE
    EXISTS (
        SELECT *
        FROM AD_IMM_idx
        WHERE AD_IMM_idx.ROWID_ND_IMM_GR = t_noeud.rowid
    );

/* Update t_cheminement pour NDCODE manquant poour IMB*/

create table tmp_CHEM (
tmp_CM_CODE VARCHAR,
tmp_CM_CODEEXT VARCHAR,
tmp_CM_NDCODE1 VARCHAR,
tmp_CM_NDCODE2 VARCHAR,
tmp_CM_GEOM LINESTRING );

insert into tmp_CHEM select cm_code, cm_codeext, cm_ndcode1, cm_ndcode2, geom from t_cheminement;

alter table tmp_CHEM 
ADD EXTREM_GEOM_CHEM VARCHAR;
update tmp_CHEM set EXTREM_GEOM_CHEM = astext(EndPoint(tmp_CM_GEOM));

alter table tmp_CHEM 
ADD ORIGIN_GEOM_CHEM VARCHAR;
update tmp_CHEM set ORIGIN_GEOM_CHEM = astext(StartPoint(tmp_CM_GEOM));

update tmp_CHEM set tmp_CM_NDCODE2 = (select ND_CODE_IMM_GR from AD_IMM_idx where tmp_CHEM.EXTREM_GEOM_CHEM = TXT_GEOM_GR) where tmp_CM_NDCODE2='';
update tmp_CHEM set tmp_CM_NDCODE1 = (select ND_CODE_IMM_GR from AD_IMM_idx where tmp_CHEM.ORIGIN_GEOM_CHEM = TXT_GEOM_GR) where tmp_CM_NDCODE1='';

update t_cheminement set cm_ndcode1= (select tmp_CM_NDCODE1 from tmp_CHEM where t_cheminement.cm_code = tmp_CM_CODE) where cm_ndcode1='';
update t_cheminement set cm_ndcode2= (select tmp_CM_NDCODE2 from tmp_CHEM where t_cheminement.cm_code = tmp_CM_CODE) where cm_ndcode2='';

/*effacement des tables temporaires*/
drop table if exists tmp_IMM_idx;
drop table if exists AD_IMM_idx;
drop table if exists tmp_CHEM;

PRAGMA foreign_keys = true;
/*FIN SCRIPT MKO*/

--Reecriture du script du pt_proptyp à partir de TEMP_INFRA_POINT 11/06/2020 (AUDE)	
update t_ptech set pt_proptyp='LOC' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where contrat in('BLO','LOCATION'));
update t_ptech set pt_proptyp='OCC' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where contrat = 'OCCUPATION');
update t_ptech set pt_proptyp='CST' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where contrat = 'CONSTRUCTION');		
update t_ptech set pt_etat = (case
	when pt_avct = 'E' then 'NC'
	when pt_avct = 'C' then 'NC'
	end); -- pt_avct = NC par défaut en APS, passe à OK par défaut en APD/DOE pour les ptech appartenant à la DSP (pt_avct=C)

end transaction;

begin transaction; --SUPPRIMER LES cableline AYANT UNE LONGUEUR EGALE A 0: cables intrasites
	delete from t_cableline where cl_long=0;
end transaction;
