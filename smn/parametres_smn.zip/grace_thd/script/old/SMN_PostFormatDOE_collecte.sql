﻿begin transaction;

/*t_adresse*/
update t_adresse set ad_nat=null;
update t_adresse set ad_isole=null;
update t_adresse set ad_nbprhab=null;
update t_adresse set ad_nbprpro=null;
update t_adresse set ad_nblhab=null;
update t_adresse set ad_nblpro=null;
update t_adresse set ad_racc=null;
update t_adresse set ad_batcode=null;
update t_adresse set ad_typzone=null;
update t_adresse set ad_ietat='DE';
update t_adresse set ad_numero=null where ad_numero=0;
update t_adresse set ad_rep=null where ad_numero is null;

/* t_ltech */
update t_ltech set lt_codeext=(select replace(st_codeext,'HT-TEC','HT-LT') || '-01' from t_sitetech where st_code = lt_st_code) ;
update t_ltech set lt_etiquet=lt_codeext;
update t_ltech set lt_proptyp = 'CST';
update t_ltech set lt_elec =null; 
update t_ltech set lt_clim =null;
update t_ltech set lt_occp =null; 
update t_ltech set lt_statut ='REC';
update t_ltech set lt_etat='OK';
update t_ltech set lt_prop='OR340000000392';
update t_ltech set lt_gest='OR340000000400';

insert into t_ltech_patch201 (lt_code) select lt_code from t_ltech where lt_code not in ( select lt_code from t_ltech_patch201 );

/*t_baie*/
update t_baie set ba_proptyp='CST'; 
update t_baie set ba_statut = 'REC';
update t_baie set ba_etat= 'OK';
update t_baie set ba_type ='BAIE'; --réactivation le 14/06/2021 -activation effective le 30/06/2021
update t_baie set ba_nb_u =42;--réactivation le 14/06/2021 -activation effective le 30/06/2021
update t_baie set ba_codeext= 'HT-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code)|| '-' || substr('0' || ba_etiquet,-2);
update t_baie set ba_etiquet = ba_codeext;
update t_baie set ba_prop='OR340000000392';
update t_baie set ba_gest='OR340000000400';
update t_baie set ba_user='OR340000000400';
update t_baie set ba_rf_code='RF340000000002';--réactivation le 14/06/2021 -activation effective le 30/06/2021

/*t_ebp*/

update t_ebp set bp_nb_pas = null; 
update t_ebp set bp_ca_nb=null; 
update t_ebp set bp_statut='REC';
/*prise en compte des bpe dans chambres Orange: le 10/06/2020
update t_ebp set bp_avct='E' where bp_pt_code in (select pt_code from t_ptech where pt_avct='E');
update t_ebp set bp_avct='C' where bp_pt_code in (select pt_code from t_ptech where pt_avct='C');*/
update t_ebp set bp_avct='E' where bp_codeext in (select code_bpe from IMPORT_BPE where etat_avt='EXISTANT');
update t_ebp set bp_etat='OK' where bp_avct='C';
update t_ebp set bp_prop='OR340000000395' where bp_avct='E';
update t_ebp set bp_gest='OR340000000395' where bp_avct='E';
update t_ebp set bp_prop='OR340000000392' where bp_avct='C';
update t_ebp set bp_gest='OR340000000400' where bp_avct='C';
update t_ebp set bp_typephy=null where bp_avct='E';
--update t_ebp set bp_rf_code=null where bp_avct='E';
update t_ebp set bp_codeext=null where bp_avct='E';
update t_ebp set bp_etat='NC' where bp_avct='E'; -- demande d'ajout le 14/06/2021 -activation effective le 30/06/2021
update t_ebp set bp_etiquet = bp_codeext where bp_avct='C';
update t_ebp set bp_datemes = DATE('NOW') where bp_avct='C';
update t_ebp set bp_datemes = null where bp_avct='E';
/*Aude le 22/09/2021: mise à jour du bp_typephy comme demandé par Covage pour la collecte*/
update t_ebp set bp_typephy = (case
	when bp_rf_code = 'RF340000000124' then 'B024'
	when bp_rf_code = 'RF340000000161' then 'B048'
	when bp_rf_code = 'RF340000000115' then 'B012'
	when bp_rf_code = 'RF340000000164' then 'B012'
	when bp_rf_code = 'RF340000000165' then 'B012'
	when bp_rf_code = 'RF340000000125' then 'B072'
	when bp_rf_code = 'RF340000000126' then 'B144'
	when bp_rf_code = 'RF340000000128' then 'B288'
	when bp_rf_code = 'RF340000000117' then 'B288'
	when bp_rf_code = 'RF340000000155' then 'AUTR'
	when bp_rf_code = 'RF340000000118' then 'B576'
	when bp_rf_code = 'RF340000000154' then 'AUTR'
	when bp_rf_code = 'RF340000000119' then 'B720'
	when bp_rf_code = 'RF340000000153' then 'AUTR'
	when bp_rf_code = 'RF340000000139' then 'B048'
	when bp_rf_code = 'RF340000000150' then 'AUTR'
	when bp_rf_code = 'RF340000000162' then 'B144'
	when bp_rf_code = 'RF340000000139' then 'B048'
	when bp_rf_code = 'RF340000000150' then 'AUTR'
	when bp_rf_code = 'RF340000000152' then 'B144'
	when bp_rf_code = 'RF340000000163' then 'AUTR'
	when bp_rf_code = 'RF340000000127' then 'AUTR'
	when bp_rf_code = 'RF340000000129' then 'AUTR'
	when bp_rf_code = 'RF340000000149' then 'AUTR'
	when bp_rf_code = 'RF340000000167' then 'AUTR' 
	when bp_rf_code = 'RF340000000168' then 'AUTR' 
end); 
update t_ebp set bp_rf_code=null where bp_avct='E';
/*t_cassette*/
--delete from t_cassette_patch201 where cs_ti_code not in (select ti_code from t_tiroir);--supprime le cs_ti_code pour les tiroirs non existants 
update t_cassette set cs_face =null;
update t_cassette set cs_type=null;
--update t_cassette set cs_bp_code=null where cs_bp_code not in (select bp_code from t_ebp);

/*t_fibre*/
update t_fibre set fo_nincab = null;
update t_fibre set fo_type = 'G657';
update t_fibre set fo_color = null;
update t_fibre set fo_reper = null;


/*t_cable*/
/*jointure grace a IMPORT_CABLE du 09/06/2020*/
update t_cable set cb_fo_disp=(select fibres_r from IMPORT_CABLES where code_cb=cb_codeext);
update t_cable set cb_fo_util=(select fibres_u from IMPORT_CABLES where code_cb=cb_codeext);
update t_cable set cb_lgreel=(select cb_lgreel from IMPORT_CABLES where code_cb=cb_codeext);
--
update t_cable set cb_etiquet = cb_codeext;
update t_cable set cb_proptyp= 'CST';
update t_cable set cb_etat='OK';
update t_cable set cb_r2_code=null;
update t_cable set cb_r3_code=null;
update t_cable set cb_statut='REC';
update t_cable set cb_avct ='E';
update t_cable set cb_typelog='CO';
update t_cable set cb_comment=null;
--cables IRU ==> 2FO --modification le 14/09/2021: utilisation de la table IMPORT_CABLES pour identifier les câbles IRU
/*update t_cable set cb_codeext=null where cb_capafo=2;
update t_cable set cb_etiquet=null where cb_capafo=2;
update t_cable set cb_avct=null where cb_capafo=2;
update t_cable set cb_etat=null where cb_capafo=2;
update t_cable set cb_prop='OR340000000395' where cb_capafo=2;
update t_cable set cb_gest='OR340000000395' where cb_capafo=2;
update t_cable set cb_proptyp='IRU' where cb_capafo=2;
update t_cable set cb_rf_code=null where cb_capafo=2;
update t_cable set cb_datemes = DATE('NOW') where cb_capafo<>2;
update t_cable set cb_fo_util=null where cb_capafo=2;
update t_cable set cb_fo_disp=null where cb_capafo=2;
update t_cable set cb_modulo=null where cb_capafo=2;
update t_cable set cb_capafo=null where cb_capafo=2;*/
--cables IRU ==> RIP EXISTANT
update t_cable set cb_etiquet=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_avct=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_etat=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_prop='OR340000000395' where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_gest='OR340000000395' where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_proptyp='IRU' where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_rf_code=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_datemes = DATE('NOW') where cb_codeext not in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');;
update t_cable set cb_fo_util=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_fo_disp=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_modulo=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_capafo=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');
update t_cable set cb_codeext=null where cb_codeext in (select code_cb from IMPORT_CABLES where proprio = 'RIP EXISTANT');

update t_fibre set fo_type=null where fo_cb_code in (select cb_code from t_cable where cb_codeext is null); --modif le 14/09/2021 suite à modif des câbles

update t_cable set cb_rf_code='RF340000000144' where (cb_capafo=72 and cb_modulo=12);
--update t_cable set cb_rf_code='RF34000000000144' where (cb_capafo=48 and cb_modulo=12);

/*t_cableline*/
update t_cableline set cl_long=null;

/*t_conduite*/
update t_conduite set cd_r4_code=null;
update t_conduite set cd_avct=(select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);
update t_conduite set cd_statut='REC';
update t_conduite set cd_prop = 'OR340000000392' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='C';
update t_conduite set cd_prop=null where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E'; 
update t_conduite set cd_etat = 'OK' where cd_statut='REC';
update t_conduite set cd_datemes = DATE('NOW') where cd_statut = 'REC' and cd_datemes is null;
update t_conduite set cd_nbcable=null;
update t_conduite set cd_type = 'NC' where cd_avct= 'E';
update t_conduite set cd_r2_code=null;
update t_conduite set cd_user=null;
update t_conduite set cd_avct=null where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E'; 
update t_conduite set cd_datemes=null where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E';
update t_conduite set cd_long=cast(replace(cast(cd_long as varchar),',','.') as varchar); 
update t_conduite set cd_gest=null;--le 10/06/2020
update t_conduite set cd_user='OR340000000400' where cd_proptyp='CST'; --le 10/06/2020

/*t_cheminement*/
update t_cheminement set cm_r4_code=null;
update t_cheminement set cm_geolmod = (case 
when cm_avct = 'C' and cm_typ_imp = '7' THEN 'DETC'
when cm_avct = 'C' and cm_typ_imp = '0' THEN 'DETC'
else null
end);
update t_cheminement set cm_datemes= DATE('NOW') where cm_avct ='C' and cm_statut = 'REC' and cm_datemes is null;
update t_cheminement set cm_datemes= (substr(cm_datemes,1,4)||'-'||substr(cm_datemes,6,2)||'-'||substr(cm_datemes,9,2)) where cm_datemes <>'';
update t_cheminement set cm_etat='OK' where (cm_avct = 'C' and cm_typ_imp = '7' and cm_statut='REC'); 
update t_cheminement set cm_etat=null where cm_avct = 'E'; 
update t_cheminement set cm_fildtec= 1 where cm_avct = 'C' and cm_typ_imp = '7'; 
update t_cheminement set cm_dtclass='A' where cm_avct = 'C' and cm_typ_imp = '7';
update t_cheminement set cm_geolqlt=0.4 where cm_avct = 'C' and cm_typ_imp = '7';
--update t_cheminement set cm_mod_pos='TRA' where cm_mod_pos='TRADITIONNEL';
update t_cheminement set cm_r2_code=null;
--update t_cheminement set cm_geolmod = null where cm_avct='E';
/*problèmatique: lorsuq'il s'agit de conduite Orange, on ne peut pas tout passer à null; le 09/06/2020
update t_cheminement set cm_datemes=null where cm_avct='E';
update t_cheminement set cm_codeext=null where cm_avct='E';
update t_cheminement set cm_long=null where cm_avct='E';
update t_cheminement set cm_typ_imp=null where cm_avct='E';
update t_cheminement set cm_typelog=null where cm_avct='E';
--update t_cheminement set cm_typelog='CO' where cm_avct='E';
update t_cheminement set cm_etat=null where cm_avct='E';
update t_cheminement set cm_avct=null where cm_avct='E'; 

IMAGINER un cm_comment à IRU pour retrouver les cheminements correspondants */
update t_cheminement set cm_datemes=null where cm_comment='IRU';
update t_cheminement set cm_codeext=null where cm_comment='IRU';
update t_cheminement set cm_long=null where cm_comment='IRU';
update t_cheminement set cm_typ_imp=null where cm_comment='IRU';
update t_cheminement set cm_typelog=null where cm_comment='IRU';
update t_cheminement set cm_etat=null where cm_comment='IRU';
update t_cheminement set cm_avct=null where cm_comment='IRU';
update t_cheminement set cm_comment=null where cm_comment='IRU';


/* t_noeud */
update t_noeud set nd_dtclass='A' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C'); 
update t_noeud set nd_geolqlt=0.4 where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C'); 
update t_noeud set nd_geolmod='DETC' where nd_code in (select pt_nd_code from t_ptech where pt_avct='C' and pt_typephy='C'); 
update t_noeud set nd_coderat=null;
update t_noeud set nd_r2_code=null;
update t_noeud set nd_type_ep=null;

/*t_position*/
update t_position set ps_comment =null;

/*t_ptech*/
--update t_ptech set pt_gest_do='A REMPLIR' where pt_avct='C' and pt_gest_do is null;
update t_ptech set pt_detec = 1 where pt_avct='C' and pt_typephy='C'; 
update t_ptech set pt_occp='1.1' where pt_avct='C' and pt_typephy='C';
update t_ptech set pt_secu='1' where pt_avct='C' and pt_typephy='C';
update t_ptech set pt_rf_code = null; 
update t_ptech set pt_etiquet=pt_codeext where pt_avct='C';
update t_ptech set pt_statut='REC';
update t_ptech set pt_etat='OK';
--update t_ptech set pt_datemes = DATE('NOW') where pt_avct='C' and pt_datemes is null;
/*jointure TEMP_INFRA_POINT le 09/06/2020 */
update t_ptech set pt_prop='OR340000000002' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio='ORANGE');
update t_ptech set pt_gest='OR340000000002' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where gestion='ORANGE');
update t_ptech set pt_prop='OR340000000395' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio='RIP EXISTANT');
update t_ptech set pt_gest='OR340000000395' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where gestion='RIP EXISTANT');
update t_ptech set pt_prop='OR340000000392' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where proprio='DELEGANT');
update t_ptech set pt_gest='OR340000000400' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where gestion='DSP');
--update t_ptech set pt_prop='OR34000000000395' where pt_avct='E';
--update t_ptech set pt_gest='OR34000000000395' where pt_avct='E';
--update t_ptech set pt_typelog='R';
update t_ptech set pt_typelog='T' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where nb_boites=0);
update t_ptech set pt_typelog='R' where pt_codeext in (select code_ptech from TEMP_INFRA_POINTS where nb_boites>1);

with a as 
(select cm_ndcode1 as code, cm_datemes from t_cheminement where cm_datemes is not null),
b as
(select cm_ndcode2 as code, cm_datemes from t_cheminement where cm_datemes is not null),
c as
(select * from a UNION select * from b)
update t_ptech set pt_datemes = (select min(cm_datemes) from c where code in (select nd_code from t_noeud where nd_code = pt_nd_code)) where pt_avct='C' ; --demande d'ajout le 14/06/2021 -activation effective le 30/06/2021


/*t_tiroir*/
--delete from t_tiroir where ti_ba_code='' or ti_ba_code=null;--supprimer les tiroirs qui ne correspondent pas à une baie
update t_tiroir set ti_codeext= 'HT-TIR-' || (select substr(ba_codeext,8,8) from t_baie where ti_ba_code = ba_code)||'-'||SUBSTR('00' || ti_etiquet,-2);
update t_tiroir set ti_etiquet= ti_codeext;
update t_tiroir set ti_prop= 'OR340000000392';
update t_tiroir set ti_etat = 'OK';
update t_tiroir set ti_rf_code='RF340000000156'; --demande de retablissement le 30/06/2021 --deux 0 en moins le 21/07/2021
--update t_tiroir set ti_rf_code='RF340000000005'; --demande d'ajout le 14/06/2021
update t_tiroir set ti_taille=1; --demande de retablissement le 30/06/2021
--update t_tiroir set ti_taille=3; -- demande d'ajout le 14/06/2021


/* t_sitetech */
update t_sitetech set st_proptyp='CST';
update t_sitetech set st_statut = 'REC';
update t_sitetech set st_avct=null;
update t_sitetech set st_etat='OK';

/*t_position*/
update t_position set ps_type = 'SFU' where ps_fonct = 'EP';
update t_position set ps_type = 'CSA' where ps_fonct = 'CO';

delete from t_ebp where bp_typelog in ('NRO','SRO'); --retirer les points ebp des NRO/SRO

update t_cassette set cs_bp_code=null where cs_bp_code not in (select bp_code from t_ebp);---vider les bp_code des cassettes dans les NRO et SRO
update t_cassette set cs_nb_pas=24 where cs_bp_code is null;
update t_cassette set cs_nb_pas=null where cs_bp_code in (select bp_code from t_ebp where bp_avct='E');

update t_fibre set fo_code_ext=null;

end transaction;