﻿begin transaction;

/*
PRAGMA foreign_keys = OFF;
delete from t_tiroir where instr(lower(ti_comment),'optionnel')>0 and ti_code not in(select ps_ti_code from t_position where (ps_type is not null and ps_type<>''));
delete from t_cassette where cs_code in (select cs_code from t_cassette_patch201 where cs_ti_code not in(select ti_code from t_tiroir));
delete from t_position where (ps_type is not null and ps_type<>'') and ps_cs_code not in (select cs_code from t_cassette);
PRAGMA foreign_keys = ON;
*/

/*t_adresse*/
update t_adresse set ad_typzone=3; --ad_typzone =3 par défaut APD/DOE


/*t_ptech*/
update t_ptech set pt_rf_code = null; --champ à ne pas remplir (MCD)
/*Aude la 02/11/2020 pour les facades qui sont des éléments existants privés*/--> en attente validation devis Covage
--update t_ptech set pt_prop='OR340000000394' where pt_typephy='F';
--update t_ptech set pt_gest='OR340000000394' where pt_typephy='F';

/*t_ebp*/
update t_ebp set bp_rf_code='RF340000000149' where bp_typelog='PTO';--rf_code de la pto
update t_ebp set bp_statut ='AVP' where bp_typelog='PTO'; 



/*t_ltech*/

update t_ltech set lt_codeext=replace(lt_codeext,'BPI','LT');--lt_etiquet=lt_codeext en attente régle étiquettage
update t_ltech set lt_etat='NC'; --lt_etat= NC par défaut, rien n'est encore posé
update t_ltech set lt_prop= (select st_prop from t_sitetech where lt_st_code=st_code);--même propriétaire que sitetech
update t_ltech set lt_gest= (select st_gest from t_sitetech where lt_st_code=st_code);--même gestionnaire que sitetech
--update t_ltech set lt_codeext=(select replace(st_codeext,'HT-TEC','HT-LT') || '-0'|| (select count(*)+1 from t_ltech where lt_st_code=st_code and lt_codeext<>'') from t_sitetech where st_code = lt_st_code) where lt_prop='OR34000000000392'  ;--compte le nombre de Ltech sur le sitetech
update t_ltech set lt_codeext=(select replace(st_codeext,'HT-TEC','HT-LT') || '-01' from t_sitetech where st_code = lt_st_code) where lt_prop='OR340000000392'; --transformation du code_org le 29/06/2020 (Aude)
update t_ltech set lt_statut = (select bp_statut from t_ebp where bp_lt_code = lt_code) where lt_gest='OR340000000394';--même statut que l'EBP où est le ltech
update t_ltech set lt_statut ='PRO' where lt_gest='OR340000000400'; --statut à PRO pour les SRO et NRO
update t_ltech set lt_etiquet=lt_codeext where lt_gest='OR340000000400'; --étiquette = codeext pour NRO et SRO

/*t_sitetech*/
update t_sitetech set st_statut = (select lt_statut from t_ltech where lt_st_code = st_code ); --même statut que le ltech qui le porte
update t_sitetech set st_codeext=substr(replace(st_codeext, 'BPI', 'TEC'),1,12);

/*t_cheminement*/
--update t_cheminement set cm_statut='PRO';--doit etre issus de DE; en attendant PRO par défaut en APD

/*t_cond_chem*/
--update t_cond_chem set dm_creadat = DATE('NOW') ; --formatage de la date

/*t_conduite*/
update t_conduite set cd_r4_code=null;--MCD: à ne pas remplir
update t_conduite set cd_avct=(select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même avancement que le cheminement la comportant
update t_conduite set cd_statut=(select cm_statut from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code);--même statut que le cheminement
update t_conduite set cd_prop = 'OR340000000392' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='C';--proriétaire=departement pour tout ce qui est à construire
update t_conduite set cd_prop = 'OR340000000002' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=7 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=0);--ORANGE pour les conduites de type 7 existantes ou pour l'aérien ORANGE
update t_conduite set cd_prop = 'OR340000000001' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=1;--ENEDIS pour l'aérien ERDF
update t_conduite set cd_prop = 'OR340000000394' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--PRIVE pour les facades et le cheminement immeuble
update t_conduite set cd_proptyp='OCC' where (select cm_avct from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)='E' and 
	((select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=2 or
	(select cm_typ_imp from t_cheminement,t_cond_chem where dm_cd_code=cd_code and dm_cm_code=cm_code)=3);--OCC pour les facades et le cheminement immeuble		
	--update t_conduite set cd_gest=null;
--update t_conduite set cd_type = 'NC' where cd_avct= 'E';--cd_type nécessaire uniquement pour le GC à créer
update t_conduite set cd_nbcable=null;--vider la colonne cd_nbcable non demandée
update t_conduite set cd_long=cast(replace(cast(cd_long as varchar),',','.') as varchar);--formatage du champ longueur
--update t_conduite set cd_creadat = DATE('NOW'); --formatage de la date

/*zsro*/
--update t_zsro set zs_etatpm='EC'; --zs_etatpm passe à la valeur EC par défaut en APD

/*t_znro*/
update t_znro set zn_nroref =null;--vide la colonne nroref non demandée
update t_znro set zn_etat ='DP'; --zn_etat = DP pour APD
--update t_znro set zn_etatlpm = 'EC';--MCD: pas demandé
update t_znro set zn_etatlpm = null;

/*t_baie*/
--les deux requetes qui suivent se retrouvent en DOE
update t_baie set ba_codeext= 'HT-ARM-' || (select substr(lt_codeext,7,5) from t_ltech where ba_lt_code = lt_code)|| '-' || substr('0' || ba_etiquet,-2);--increment du lt_codeext avec le prefixe HT-ARM- et le suffixe de l'étiquette de la baie02
update t_baie set ba_etiquet = ba_codeext;--par défaut l'étiquette de la baie est le codeext de la baie
update t_baie set ba_statut = (select lt_statut from t_ltech where ba_lt_code = lt_code); --même staut que le local technique
update t_baie set ba_prop=(select st_prop from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code);--même propriétaire que le site technique
update t_baie set ba_gest=(select st_gest from t_sitetech inner join t_ltech on lt_st_code=st_code where ba_lt_code=lt_code); --même gestionnaire que le site technique

update t_baie set  ba_rf_code = (select case 
when zs_nblogmt <= 460 then  'RF340000000003'
when zs_nblogmt > 460 then  'RF340000000004'
when zs_nblogmt=0 then null
end
from t_zsro 
join t_sitetech on  zs_nd_code= st_nd_code
join t_ltech on st_code = lt_st_code
join t_baie on  ba_lt_code = lt_code
where st_typelog='SRO');

update t_baie set  ba_rf_code = 'RF340000000001' where ba_lt_code in ( select lt_code from t_ltech, t_sitetech where lt_st_code=st_code and st_typelog='NRO');


/*t_tiroir*/
delete from t_tiroir where ti_ba_code='' or ti_ba_code=null;--supprimer les tiroirs qui ne correspondent pas à une baie
update t_tiroir set ti_codeext= 'HT-TIR-' || (select substr(ba_codeext,8,8) from t_baie where ti_ba_code = ba_code)||'-'||substr('0' || ti_etiquet,-2);--tiroir prend l'increment de la baie + numéro du tiroir
update t_tiroir set ti_etiquet= ti_codeext;--etiquette du tiroir = codeext du tiroir en attente régles étiquettage 
update t_tiroir set ti_prop= (select ba_prop from t_baie where ti_ba_code = ba_code);--propriétaire du tiroir = propriétaire de la baie

/*t_cassette*/
--update t_cassette set cs_nb_pas=12;--A VERIFIER: 12 positions quelque soit la cassette
update t_cassette set cs_face=null; --vide la colonne cs_face non demandée
update t_cassette_patch201 set cs_ti_code=null where cs_ti_code not in (select ti_code from t_tiroir);--vide la colonne cs_ti_code pour les tiroirs qui n'en sont pas
update t_cassette set cs_nb_pas=6 where cs_bp_code in (select bp_code from t_ebp where bp_rf_code in ('RF340000000167','RF340000000168')); --ajout le 29/07/2021 pour les immeubles préfibrés

--update t_cassette set cs_bp_code=null where cs_code in (select cs_code from t_cassette_patch201 where cs_ti_code not null);--vider les bp_code des cassettes dans les NRO et SRO

--update t_suf set sf_comment =
--	(select TYPE_DEPL from IMPORT_BAL where NOE_NUM= (select ad_batcode from t_adresse where sf_ad_code=ad_code));


/*t_cable*/
update t_cable set cb_rf_code='RF340000000148' where cb_typelog='RA'; --re code du câbles de raccordement
update t_cable set cb_etat='NC'; --état à NC par défaut en APD
--update t_cable set cb_codeext=null where cb_typelog='RA'; --nettoyage des cb_codeext pour la livraison - pas de maintien des codes Grace
/*jointure grace a IMPORT_CABLE du 11/06/2020*/
update t_cable set cb_fo_disp=(select fibres_r from IMPORT_CABLES where code_cb=cb_codeext);
update t_cable set cb_fo_util=(select fibres_u from IMPORT_CABLES where code_cb=cb_codeext);

update t_cable set cb_rf_code = 'RF340000000166' where cb_codeext in (select code_cb from IMPORT_CABLES where commentair = 'PRE_FIBRE'); --Ajouté le 29/07/2021 pour les immeubles préfibrés

/*Aude le 02/11/2020: mise à jour du bp_typephy comme demandé par Covage*/
update t_ebp set bp_typephy = (case
	when bp_rf_code = 'RF340000000124' then 'B024'
	when bp_rf_code = 'RF340000000161' then 'B048'
	when bp_rf_code = 'RF340000000115' then 'B012'
	when bp_rf_code = 'RF340000000164' then 'B012'
	when bp_rf_code = 'RF340000000165' then 'B012'
	when bp_rf_code = 'RF340000000125' then 'B072'
	when bp_rf_code = 'RF340000000126' then 'B144'
	when bp_rf_code = 'RF340000000128' then 'B288'
	when bp_rf_code = 'RF340000000117' then 'B288'
	when bp_rf_code = 'RF340000000155' then 'AUTR'
	when bp_rf_code = 'RF340000000118' then 'B576'
	when bp_rf_code = 'RF340000000154' then 'AUTR'
	when bp_rf_code = 'RF340000000119' then 'B720'
	when bp_rf_code = 'RF340000000153' then 'AUTR'
	when bp_rf_code = 'RF340000000139' then 'B048'
	when bp_rf_code = 'RF340000000150' then 'AUTR'
	when bp_rf_code = 'RF340000000162' then 'B144'
	when bp_rf_code = 'RF340000000139' then 'B048'
	when bp_rf_code = 'RF340000000150' then 'AUTR'
	when bp_rf_code = 'RF340000000152' then 'B144'
	when bp_rf_code = 'RF340000000163' then 'AUTR'
	when bp_rf_code = 'RF340000000127' then 'AUTR'
	when bp_rf_code = 'RF340000000129' then 'AUTR'
	when bp_rf_code = 'RF340000000149' then 'AUTR'
	when bp_rf_code = 'RF340000000167' then 'AUTR' 
	when bp_rf_code = 'RF340000000168' then 'AUTR'
	when bp_rf_code = 'RF340000000169' then 'AUTR' --modif anais 110722
end);


end transaction;

begin transaction;
/*t_ebp*/

delete from t_ebp where bp_typelog in ('NRO','SRO'); --retirer les points ebp des NRO/SRO
update t_cable_patch201 set cb_bp1=null where cb_bp1 not in (select bp_code from t_ebp);
update t_cable_patch201 set cb_bp2=null where cb_bp2 not in (select bp_code from t_ebp);


update t_cassette set cs_bp_code=null where cs_bp_code not in (select bp_code from t_ebp);---vider les bp_code des cassettes dans les NRO et SRO
update t_cassette set cs_nb_pas=24 where cs_bp_code is null; --cassette de 24 pour les cassettes des tiroirs

end transaction;	

/*Si ils demandent à ce qu'on retire les conduites autres que celles créées*/
/*begin transaction;
delete from t_conduite where cd_prop != 'OR34000000000395'; -- on ne garde que les conduites crées par HERAULT THD
delete from t_cond_chem where dm_cd_code not in (select cd_code from t_conduite);--reitrer les cond_chem qui n'appartiennet pas à des cheminement à créer
delete from t_cab_cond where cc_cd_code not in (select cd_code from t_conduite); --retirer les cab_cond qui n'appartiennet pas à des cheminement à créer
end transaction;
*/

