--ALTER TABLE import_bal ADD noe_codext VARCHAR(255);
--update import_bal set noe_codext=code_st;

update noeuds set street=(select adr_voie from import_bal where id=lri_key) where noe_type='LRI';
update noeuds set adrnum=(select cast(adr_num as INTEGER) from import_bal where id=lri_key) where noe_type='LRI';
update noeuds set street=(select adresse from temp_infra_points where id=inf_key) where type='PDT';
update noeuds set street=(select adresse from temp_infra_points where id=inf_key) where type in ('BPE','PBO','BPI');
update noeuds set numnoe="HT-PT-"||substr((select noe_codext from temp_infra_points where id=inf_key),8,5) where type='PDT';
update noeuds  set inf_mat=(select inf_mat from noeuds as noe2 where noe2.inf_mat not like'' and noe2.inf_mat is not null and noe2.inf_key = noeuds.inf_key);
update noeuds set pose=(select pose from noeuds as noe2 where noe2.pose not like '' and noe2.pose is not null and noe2.inf_key = noeuds.inf_key);
update noeuds set type='PBO' where NOE_CODEXT=(select code_bpe from IMPORT_BPE where type_fonc ='BPI' and statut != 'REC');
update noeuds set type='BPE' where NOE_CODEXT=(select code_bpe from IMPORT_BPE where type_fonc ='BPI' and statut = 'REC');
--update noeuds set type='DERIVATION' where type='BPI' and statut = 'REC';
update temp_infra_points set NOE_CODEXT=code_ptech where type_ptech ='IMM';
update cables set CAB_CAPA=1 where CAB_TYPE ='RAC';
update cables set CAB_MODULO=1 where CAB_TYPE ='RAC';
update NOEUDS set adrNum=0 where pose in ('SHE','ADR');
update NOEUDS set equipment='BPE/O-T1-5_BRANCH_144-144_12x12' where equipment='BPE/O_T1,5_BRANCH_144-144_12x12' or equipment='BPE/O-T1,5-BRANCH_144-144_12x12';
